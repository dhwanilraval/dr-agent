# Disaster Recovery Compliance Agent System

This project implements a complex Disaster Recovery compliance agent system using AG2 (AutoGen 2) to analyze and evaluate disaster recovery plans for business processes and applications.

## Architecture Overview

The system is built as an agentic system with specialized agents that perform different functions and collaborate to provide comprehensive disaster recovery compliance analysis. The agents are orchestrated using AG2's GroupChat pattern.

### Components

1. **REST API Entrypoint**: Accepts business process and application codes as input and initiates the agentic workflow.
2. **Process Dependency Agent (Agent 1)**: Finds underlying dependencies and application codes that the submitted appcodes rely on using FlowIQ APIs.
3. **DR Plans Fetcher Agent (Agent 2)**: Fetches disaster recovery plans from a Postgres database table.
4. **Description Analysis Agent (Agent 3)**: Analyzes each plan's description against standard plans stored in PGVector Collection.
5. **Tasks Analysis Agent (Agent 4)**: Analyzes each plan's recovery tasks against standard plans stored in PGVector Collection.
6. **Device Reconciliation Agent (Agent 5)**: Matches devices in the plan with devices that actually belong to the application.
7. **IIPM Analysis Agent (Agent 6)**: Fetches required details for all supporting appcodes for the business process and dependent appcodes.
8. **DR Plan Analysis Reasoning Agent**: Analyzes inputs from all agents to judge the overall quality of disaster recovery readiness, identify risks, and evaluate RTO/RPO metrics.
9. **Elasticsearch Logging**: Records all agentic interactions for evidence and auditing purposes.
10. **Real-time Response**: Provides real-time structured output using AG2's WebRTC capabilities.

## Data Flow

1. User submits business process and application codes via the REST API.
2. The Process Dependency Agent identifies all dependencies.
3. The DR Plans Fetcher Agent retrieves relevant disaster recovery plans.
4. The Description Analysis Agent, Tasks Analysis Agent, Device Reconciliation Agent, and IIPM Analysis Agent process the plans and application data in parallel.
5. All agents provide their outputs to the DR Plan Analysis Reasoning Agent.
6. The Reasoning Agent produces a comprehensive analysis of disaster recovery readiness.
7. Results are returned to the user in real-time and logged to Elasticsearch.

## Implementation Details

- The system uses AG2's Agent protocol for communication between agents.
- Agents are implemented as specialized instances of ConversableAgent or AssistantAgent.
- The GroupChat pattern is used to orchestrate the agents.
- External APIs (FlowIQ, IIPM) are mocked for development and testing.
- Postgres and PGVector databases are mocked for development and testing.
