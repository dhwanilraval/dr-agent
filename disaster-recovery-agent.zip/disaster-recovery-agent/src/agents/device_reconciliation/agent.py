"""
Device Reconciliation Agent for the Disaster Recovery Compliance Agent System.

This agent is responsible for matching devices in the plan with devices that actually
belong to the application.
"""

import logging
from typing import List, Dict, Any, Optional, Set

from autogen import AssistantAgent

from src.mock_apis.postgres.api import mock_postgres_api
from src.models.data_models import DisasterRecoveryPlan, Device
from src.config.config import AGENT_CONFIG, LLM_CONFIG

logger = logging.getLogger(__name__)

class DeviceReconciliationAgent:
    """
    Agent responsible for matching devices in the plan with actual devices.
    
    This agent uses the Postgres API to get actual devices for applications and
    matches them with devices in the disaster recovery plans.
    """
    
    def __init__(self):
        """Initialize the Device Reconciliation Agent."""
        self.config = AGENT_CONFIG["device_reconciliation_agent"]
        self.postgres_api = mock_postgres_api
        
        try:
            self.agent = AssistantAgent(
                name=self.config["name"],
                system_message=self._create_system_message(),
                llm_config=LLM_CONFIG
            )
        except Exception as e:
            logger.warning(f"Failed to initialize AssistantAgent: {str(e)}")
            self.agent = type('MockAgent', (), {
                'name': self.config["name"],
                'system_message': self._create_system_message(),
                'generate_reply': lambda message: {
                    "content": f"Mock reply from {self.config['name']}",
                    "role": "assistant"
                }
            })()
        
        logger.info(f"Initialized {self.config['name']}")
    
    def _create_system_message(self) -> str:
        """
        Create the system message for the agent.
        
        Returns:
            The system message string.
        """
        return f"""
        You are the {self.config['name']}, responsible for matching devices in disaster recovery
        plans with devices that actually belong to the application.
        
        {self.config['description']}
        
        You have access to the Postgres API to get actual devices for applications and
        match them with devices in the disaster recovery plans.
        
        When given a list of disaster recovery plans, you should:
        1. Get the actual devices for each application
        2. Match devices in the plan with actual devices
        3. Identify devices in the plan that don't exist in the actual inventory
        4. Identify actual devices that are missing from the plan
        
        Your output should include:
        - A summary of the device reconciliation for each plan
        - Lists of matched devices, missing devices, and extra devices
        - Recommendations for improving device coverage in the plans
        """
    
    def reconcile_devices(self, plans: List[DisasterRecoveryPlan]) -> Dict[str, Any]:
        """
        Reconcile devices in plans with actual devices.
        
        Args:
            plans: The list of disaster recovery plans to reconcile devices for.
            
        Returns:
            A dictionary containing the reconciliation results.
        """
        try:
            logger.info(f"Reconciling devices for {len(plans)} plans")
            
            app_codes = [plan.app_code for plan in plans]
            actual_devices_by_app = self.postgres_api.get_actual_devices_for_apps(app_codes)
            
            plan_analyses = {}
            total_matched = 0
            total_missing = 0
            total_extra = 0
            
            for plan in plans:
                app_code = plan.app_code
                plan_devices = plan.devices
                actual_devices = actual_devices_by_app.get(app_code, [])
                
                logger.info(f"Reconciling devices for plan {plan.id} ({app_code})")
                logger.info(f"Plan has {len(plan_devices)} devices, actual inventory has {len(actual_devices)} devices")
                
                plan_device_ids = {device.id for device in plan_devices}
                actual_device_ids = {device.id for device in actual_devices}
                
                matched_device_ids = plan_device_ids.intersection(actual_device_ids)
                missing_device_ids = actual_device_ids - plan_device_ids
                extra_device_ids = plan_device_ids - actual_device_ids
                
                matched_devices = [device for device in plan_devices if device.id in matched_device_ids]
                missing_devices = [device for device in actual_devices if device.id in missing_device_ids]
                extra_devices = [device for device in plan_devices if device.id in extra_device_ids]
                
                total_matched += len(matched_devices)
                total_missing += len(missing_devices)
                total_extra += len(extra_devices)
                
                if len(actual_devices) > 0:
                    coverage_percentage = (len(matched_devices) / len(actual_devices)) * 100
                else:
                    coverage_percentage = 0
                
                recommendations = self._generate_recommendations(
                    matched_devices, missing_devices, extra_devices, coverage_percentage
                )
                
                plan_analyses[plan.id] = {
                    "plan_id": plan.id,
                    "app_code": app_code,
                    "plan_name": plan.name,
                    "plan_device_count": len(plan_devices),
                    "actual_device_count": len(actual_devices),
                    "matched_device_count": len(matched_devices),
                    "missing_device_count": len(missing_devices),
                    "extra_device_count": len(extra_devices),
                    "coverage_percentage": coverage_percentage,
                    "matched_devices": [self._device_to_dict(device) for device in matched_devices],
                    "missing_devices": [self._device_to_dict(device) for device in missing_devices],
                    "extra_devices": [self._device_to_dict(device) for device in extra_devices],
                    "recommendations": recommendations
                }
                
                logger.info(f"Device reconciliation for plan {plan.id}: "
                           f"matched={len(matched_devices)}, "
                           f"missing={len(missing_devices)}, "
                           f"extra={len(extra_devices)}, "
                           f"coverage={coverage_percentage:.2f}%")
            
            plan_count = len(plans)
            if plan_count > 0:
                avg_coverage = sum(pa["coverage_percentage"] for pa in plan_analyses.values()) / plan_count
            else:
                avg_coverage = 0
            
            result = {
                "status": "success",
                "data": {
                    "plan_count": plan_count,
                    "total_matched_devices": total_matched,
                    "total_missing_devices": total_missing,
                    "total_extra_devices": total_extra,
                    "avg_coverage_percentage": avg_coverage,
                    "plan_analyses": plan_analyses
                }
            }
            
            logger.info(f"Reconciled devices for {plan_count} plans with average coverage {avg_coverage:.2f}%")
            
            return result
        
        except Exception as e:
            logger.exception(f"Error reconciling devices for {len(plans)} plans")
            raise
    
    def _device_to_dict(self, device: Device) -> Dict[str, Any]:
        """
        Convert a Device object to a dictionary.
        
        Args:
            device: The Device object to convert.
            
        Returns:
            A dictionary representation of the Device.
        """
        return {
            "id": device.id,
            "name": device.name,
            "type": device.type,
            "description": device.description,
            "app_code": device.app_code
        }
    
    def _generate_recommendations(
        self, 
        matched_devices: List[Device], 
        missing_devices: List[Device], 
        extra_devices: List[Device],
        coverage_percentage: float
    ) -> List[str]:
        """
        Generate recommendations based on device reconciliation results.
        
        Args:
            matched_devices: The list of matched devices.
            missing_devices: The list of missing devices.
            extra_devices: The list of extra devices.
            coverage_percentage: The coverage percentage.
            
        Returns:
            A list of recommendations.
        """
        recommendations = []
        
        if coverage_percentage < 50:
            recommendations.append("Critical: Device coverage in the DR plan is below 50%. "
                                  "Update the plan to include all critical devices.")
        elif coverage_percentage < 80:
            recommendations.append("Warning: Device coverage in the DR plan is below 80%. "
                                  "Consider updating the plan to include more devices.")
        else:
            recommendations.append("Good: Device coverage in the DR plan is above 80%.")
        
        if missing_devices:
            missing_types = {device.type for device in missing_devices}
            for device_type in missing_types:
                count = sum(1 for device in missing_devices if device.type == device_type)
                recommendations.append(f"Add {count} missing {device_type} devices to the DR plan.")
        
        if extra_devices:
            extra_types = {device.type for device in extra_devices}
            for device_type in extra_types:
                count = sum(1 for device in extra_devices if device.type == device_type)
                recommendations.append(f"Remove or update {count} {device_type} devices in the DR plan that don't exist in the actual inventory.")
        
        return recommendations
    
    def process_message(self, message: Dict[str, Any]) -> Dict[str, Any]:
        """
        Process a message from another agent.
        
        Args:
            message: The message to process.
            
        Returns:
            A dictionary containing the response.
        """
        try:
            plans = []
            
            if "plans_data" in message and "data" in message["plans_data"]:
                data = message["plans_data"]["data"]
                if "plans" in data:
                    for plan_data in data["plans"]:
                        try:
                            from datetime import datetime
                            plan_data["created_at"] = datetime.fromisoformat(plan_data["created_at"])
                            plan_data["updated_at"] = datetime.fromisoformat(plan_data["updated_at"])
                            
                            plan = DisasterRecoveryPlan(**plan_data)
                            plans.append(plan)
                        except Exception as e:
                            logger.warning(f"Error converting plan data to DisasterRecoveryPlan: {str(e)}")
            
            if not plans:
                return {
                    "status": "error",
                    "message": "No plans provided"
                }
            
            reconciliation_result = self.reconcile_devices(plans)
            
            response = {
                "status": "success",
                "message": f"Reconciled devices for {reconciliation_result['data']['plan_count']} plans",
                "data": reconciliation_result['data']
            }
            
            return response
        
        except Exception as e:
            logger.exception(f"Error processing message: {message}")
            
            return {
                "status": "error",
                "message": f"Error processing message: {str(e)}"
            }
    
    def generate_reply(self, message: Dict[str, Any]) -> Dict[str, Any]:
        """
        Generate a reply to a message using the AG2 agent.
        
        Args:
            message: The message to reply to.
            
        Returns:
            A dictionary containing the reply.
        """
        reconciliation_result = self.process_message(message)
        
        formatted_message = self._format_message_for_agent(reconciliation_result)
        
        reply = self.agent.generate_reply(formatted_message)
        
        if isinstance(reply, dict):
            reply["device_reconciliation_data"] = reconciliation_result
        else:
            reply = {
                "content": reply,
                "device_reconciliation_data": reconciliation_result
            }
        
        return reply
    
    def _format_message_for_agent(self, reconciliation_result: Dict[str, Any]) -> Dict[str, Any]:
        """
        Format a reconciliation result as a message for the AG2 agent.
        
        Args:
            reconciliation_result: The reconciliation result to format.
            
        Returns:
            A dictionary containing the formatted message.
        """
        if reconciliation_result["status"] == "error":
            return {
                "content": f"Error: {reconciliation_result['message']}"
            }
        
        data = reconciliation_result["data"]
        plan_count = data["plan_count"]
        total_matched = data["total_matched_devices"]
        total_missing = data["total_missing_devices"]
        total_extra = data["total_extra_devices"]
        avg_coverage = data["avg_coverage_percentage"]
        plan_analyses = data["plan_analyses"]
        
        message = f"""
        I have reconciled devices in {plan_count} disaster recovery plans with actual devices.
        
        Overall Statistics:
        - Total matched devices: {total_matched}
        - Total missing devices (in actual inventory but not in plans): {total_missing}
        - Total extra devices (in plans but not in actual inventory): {total_extra}
        - Average device coverage: {avg_coverage:.2f}%
        
        Here is a summary of the device reconciliation for each plan:
        """
        
        for plan_id, analysis in plan_analyses.items():
            app_code = analysis["app_code"]
            plan_name = analysis["plan_name"]
            plan_device_count = analysis["plan_device_count"]
            actual_device_count = analysis["actual_device_count"]
            matched_device_count = analysis["matched_device_count"]
            missing_device_count = analysis["missing_device_count"]
            extra_device_count = analysis["extra_device_count"]
            coverage_percentage = analysis["coverage_percentage"]
            recommendations = analysis["recommendations"]
            
            message += f"\n\nPlan {plan_id} ({app_code}): {plan_name}"
            message += f"\nDevice Counts:"
            message += f"\n- Devices in plan: {plan_device_count}"
            message += f"\n- Devices in actual inventory: {actual_device_count}"
            message += f"\n- Matched devices: {matched_device_count}"
            message += f"\n- Missing devices (in actual inventory but not in plan): {missing_device_count}"
            message += f"\n- Extra devices (in plan but not in actual inventory): {extra_device_count}"
            message += f"\n- Device coverage: {coverage_percentage:.2f}%"
            
            if recommendations:
                message += f"\n\nRecommendations ({len(recommendations)}):"
                for i, recommendation in enumerate(recommendations, 1):
                    message += f"\n{i}. {recommendation}"
            else:
                message += "\n\nNo recommendations."
        
        message += "\n\nThe complete reconciliation details are available in the structured data."
        
        return {
            "content": message,
            "role": "assistant"
        }

device_reconciliation_agent = DeviceReconciliationAgent()
