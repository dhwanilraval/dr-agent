"""
IIPM Analysis Agent for the Disaster Recovery Compliance Agent System.

This agent is responsible for fetching required details for all supporting appcodes
for business process as well as dependent appcodes.
"""

import logging
from typing import List, Dict, Any, Optional, Set

from autogen import AssistantAgent

from src.mock_apis.iipm.api import mock_iipm_api
from src.config.config import AGENT_CONFIG, LLM_CONFIG

logger = logging.getLogger(__name__)

class IIPMAnalysisAgent:
    """
    Agent responsible for fetching application details from IIPM.
    
    This agent uses the IIPM API to fetch required details for all supporting
    appcodes for business process as well as dependent appcodes.
    """
    
    def __init__(self):
        """Initialize the IIPM Analysis Agent."""
        self.config = AGENT_CONFIG["iipm_analysis_agent"]
        self.iipm_api = mock_iipm_api
        
        try:
            self.agent = AssistantAgent(
                name=self.config["name"],
                system_message=self._create_system_message(),
                llm_config=LLM_CONFIG
            )
        except Exception as e:
            logger.warning(f"Failed to initialize AssistantAgent: {str(e)}")
            self.agent = type('MockAgent', (), {
                'name': self.config["name"],
                'system_message': self._create_system_message(),
                'generate_reply': lambda message: {
                    "content": f"Mock reply from {self.config['name']}",
                    "role": "assistant"
                }
            })()
        
        logger.info(f"Initialized {self.config['name']}")
    
    def _create_system_message(self) -> str:
        """
        Create the system message for the agent.
        
        Returns:
            The system message string.
        """
        return f"""
        You are the {self.config['name']}, responsible for fetching required details
        for all supporting appcodes for business process as well as dependent appcodes.
        
        {self.config['description']}
        
        You have access to the IIPM API to fetch application details, including:
        - Recovery Time Objective (RTO)
        - Recovery Point Objective (RPO)
        - Business Criticality
        - Application Owner
        - Support Team
        - Last DR Test Date and Result
        - Dependencies
        
        When given a list of application codes, you should:
        1. Fetch details for each application
        2. Identify dependencies between applications
        3. Analyze RTO and RPO requirements
        4. Identify potential risks based on business criticality and DR test results
        
        Your output should include:
        - Detailed information for each application
        - Analysis of dependencies and their impact on DR
        - Identification of applications with critical RTO/RPO requirements
        - Recommendations for improving DR readiness
        """
    
    def analyze_applications(self, app_codes: List[str]) -> Dict[str, Any]:
        """
        Analyze applications using the IIPM API.
        
        Args:
            app_codes: The list of application codes to analyze.
            
        Returns:
            A dictionary containing the analysis results.
        """
        try:
            logger.info(f"Analyzing {len(app_codes)} applications")
            
            app_details = self.iipm_api.get_app_details_batch(app_codes)
            
            all_dependencies = set()
            for app_code in app_codes:
                dependencies = self.iipm_api.get_dependencies(app_code)
                all_dependencies.update(dependencies)
            
            all_dependencies = all_dependencies - set(app_codes)
            
            dependency_details = self.iipm_api.get_app_details_batch(list(all_dependencies))
            
            all_app_details = {**app_details, **dependency_details}
            
            rto_analysis = self._analyze_rto(all_app_details)
            rpo_analysis = self._analyze_rpo(all_app_details)
            
            criticality_analysis = self._analyze_business_criticality(all_app_details)
            
            dr_test_analysis = self._analyze_dr_tests(all_app_details)
            
            recommendations = self._generate_recommendations(
                all_app_details, rto_analysis, rpo_analysis, criticality_analysis, dr_test_analysis
            )
            
            result = {
                "status": "success",
                "data": {
                    "app_count": len(app_codes),
                    "dependency_count": len(all_dependencies),
                    "total_app_count": len(all_app_details),
                    "app_details": all_app_details,
                    "rto_analysis": rto_analysis,
                    "rpo_analysis": rpo_analysis,
                    "criticality_analysis": criticality_analysis,
                    "dr_test_analysis": dr_test_analysis,
                    "recommendations": recommendations
                }
            }
            
            logger.info(f"Analyzed {len(app_codes)} applications with {len(all_dependencies)} dependencies")
            
            return result
        
        except Exception as e:
            logger.exception(f"Error analyzing {len(app_codes)} applications")
            raise
    
    def _analyze_rto(self, app_details: Dict[str, Dict[str, Any]]) -> Dict[str, Any]:
        """
        Analyze Recovery Time Objective (RTO) requirements.
        
        Args:
            app_details: Dictionary mapping application codes to their details.
            
        Returns:
            A dictionary containing the RTO analysis results.
        """
        rto_categories = {
            "critical": [],    # <= 60 minutes
            "high": [],        # <= 240 minutes
            "medium": [],      # <= 480 minutes
            "low": []          # > 480 minutes
        }
        
        for app_code, details in app_details.items():
            rto = details.get("recovery_time_objective", float("inf"))
            
            if rto <= 60:
                rto_categories["critical"].append(app_code)
            elif rto <= 240:
                rto_categories["high"].append(app_code)
            elif rto <= 480:
                rto_categories["medium"].append(app_code)
            else:
                rto_categories["low"].append(app_code)
        
        min_rto = float("inf")
        min_rto_app = None
        
        for app_code, details in app_details.items():
            rto = details.get("recovery_time_objective", float("inf"))
            if rto < min_rto:
                min_rto = rto
                min_rto_app = app_code
        
        return {
            "categories": rto_categories,
            "min_rto": min_rto if min_rto != float("inf") else None,
            "min_rto_app": min_rto_app
        }
    
    def _analyze_rpo(self, app_details: Dict[str, Dict[str, Any]]) -> Dict[str, Any]:
        """
        Analyze Recovery Point Objective (RPO) requirements.
        
        Args:
            app_details: Dictionary mapping application codes to their details.
            
        Returns:
            A dictionary containing the RPO analysis results.
        """
        rpo_categories = {
            "critical": [],    # <= 15 minutes
            "high": [],        # <= 60 minutes
            "medium": [],      # <= 240 minutes
            "low": []          # > 240 minutes
        }
        
        for app_code, details in app_details.items():
            rpo = details.get("recovery_point_objective", float("inf"))
            
            if rpo <= 15:
                rpo_categories["critical"].append(app_code)
            elif rpo <= 60:
                rpo_categories["high"].append(app_code)
            elif rpo <= 240:
                rpo_categories["medium"].append(app_code)
            else:
                rpo_categories["low"].append(app_code)
        
        min_rpo = float("inf")
        min_rpo_app = None
        
        for app_code, details in app_details.items():
            rpo = details.get("recovery_point_objective", float("inf"))
            if rpo < min_rpo:
                min_rpo = rpo
                min_rpo_app = app_code
        
        return {
            "categories": rpo_categories,
            "min_rpo": min_rpo if min_rpo != float("inf") else None,
            "min_rpo_app": min_rpo_app
        }
    
    def _analyze_business_criticality(self, app_details: Dict[str, Dict[str, Any]]) -> Dict[str, Any]:
        """
        Analyze business criticality.
        
        Args:
            app_details: Dictionary mapping application codes to their details.
            
        Returns:
            A dictionary containing the business criticality analysis results.
        """
        criticality_categories = {
            "Critical": [],
            "High": [],
            "Medium": [],
            "Low": []
        }
        
        for app_code, details in app_details.items():
            criticality = details.get("business_criticality")
            if criticality in criticality_categories:
                criticality_categories[criticality].append(app_code)
        
        return {
            "categories": criticality_categories
        }
    
    def _analyze_dr_tests(self, app_details: Dict[str, Dict[str, Any]]) -> Dict[str, Any]:
        """
        Analyze DR test results.
        
        Args:
            app_details: Dictionary mapping application codes to their details.
            
        Returns:
            A dictionary containing the DR test analysis results.
        """
        test_categories = {
            "passed": [],
            "failed": [],
            "partial": [],
            "not_tested": []
        }
        
        for app_code, details in app_details.items():
            dr_test_result = details.get("dr_test_result")
            
            if dr_test_result == "Passed":
                test_categories["passed"].append(app_code)
            elif dr_test_result == "Failed":
                test_categories["failed"].append(app_code)
            elif dr_test_result == "Partial Success":
                test_categories["partial"].append(app_code)
            else:
                test_categories["not_tested"].append(app_code)
        
        return {
            "categories": test_categories
        }
    
    def _generate_recommendations(
        self,
        app_details: Dict[str, Dict[str, Any]],
        rto_analysis: Dict[str, Any],
        rpo_analysis: Dict[str, Any],
        criticality_analysis: Dict[str, Any],
        dr_test_analysis: Dict[str, Any]
    ) -> List[str]:
        """
        Generate recommendations based on application analysis.
        
        Args:
            app_details: Dictionary mapping application codes to their details.
            rto_analysis: RTO analysis results.
            rpo_analysis: RPO analysis results.
            criticality_analysis: Business criticality analysis results.
            dr_test_analysis: DR test analysis results.
            
        Returns:
            A list of recommendations.
        """
        recommendations = []
        
        critical_apps = criticality_analysis["categories"]["Critical"]
        not_tested_apps = dr_test_analysis["categories"]["not_tested"]
        critical_not_tested = [app for app in critical_apps if app in not_tested_apps]
        
        if critical_not_tested:
            recommendations.append(
                f"Critical: {len(critical_not_tested)} critical applications have not been tested for DR. "
                f"Schedule DR tests for: {', '.join(critical_not_tested[:5])}"
                f"{' and others' if len(critical_not_tested) > 5 else ''}."
            )
        
        failed_apps = dr_test_analysis["categories"]["failed"]
        critical_failed = [app for app in critical_apps if app in failed_apps]
        
        if critical_failed:
            recommendations.append(
                f"Critical: {len(critical_failed)} critical applications failed their last DR test. "
                f"Address DR issues for: {', '.join(critical_failed[:5])}"
                f"{' and others' if len(critical_failed) > 5 else ''}."
            )
        
        for app_code, details in app_details.items():
            app_rto = details.get("recovery_time_objective", float("inf"))
            dependencies = details.get("dependencies", [])
            
            for dep_app_code in dependencies:
                if dep_app_code in app_details:
                    dep_rto = app_details[dep_app_code].get("recovery_time_objective", float("inf"))
                    
                    if dep_rto > app_rto:
                        recommendations.append(
                            f"Warning: Application {app_code} has RTO of {app_rto} minutes but depends on "
                            f"{dep_app_code} with longer RTO of {dep_rto} minutes. Consider aligning RTOs."
                        )
        
        no_support_team = []
        for app_code, details in app_details.items():
            if not details.get("support_team"):
                no_support_team.append(app_code)
        
        if no_support_team:
            recommendations.append(
                f"Warning: {len(no_support_team)} applications have no assigned support team. "
                f"Assign support teams to: {', '.join(no_support_team[:5])}"
                f"{' and others' if len(no_support_team) > 5 else ''}."
            )
        
        critical_rto_apps = rto_analysis["categories"]["critical"]
        non_24x7_support = []
        
        for app_code in critical_rto_apps:
            if app_code in app_details:
                support_hours = app_details[app_code].get("support_hours", "")
                if support_hours != "24x7":
                    non_24x7_support.append(app_code)
        
        if non_24x7_support:
            recommendations.append(
                f"Warning: {len(non_24x7_support)} applications with critical RTO do not have 24x7 support. "
                f"Consider upgrading support for: {', '.join(non_24x7_support[:5])}"
                f"{' and others' if len(non_24x7_support) > 5 else ''}."
            )
        
        return recommendations
    
    def process_message(self, message: Dict[str, Any]) -> Dict[str, Any]:
        """
        Process a message from another agent.
        
        Args:
            message: The message to process.
            
        Returns:
            A dictionary containing the response.
        """
        try:
            app_codes = []
            
            if "process_dependency_data" in message and "data" in message["process_dependency_data"]:
                data = message["process_dependency_data"]["data"]
                if "app_codes" in data:
                    app_codes.extend(data["app_codes"])
                if "dependent_app_codes" in data:
                    app_codes.extend(data["dependent_app_codes"])
            
            if "plans_data" in message and "data" in message["plans_data"]:
                data = message["plans_data"]["data"]
                if "plans" in data:
                    for plan in data["plans"]:
                        if "app_code" in plan:
                            app_codes.append(plan["app_code"])
            
            app_codes = list(set(app_codes))
            
            if not app_codes:
                return {
                    "status": "error",
                    "message": "No application codes provided"
                }
            
            analysis_result = self.analyze_applications(app_codes)
            
            response = {
                "status": "success",
                "message": f"Analyzed {analysis_result['data']['app_count']} applications with {analysis_result['data']['dependency_count']} dependencies",
                "data": analysis_result['data']
            }
            
            return response
        
        except Exception as e:
            logger.exception(f"Error processing message: {message}")
            
            return {
                "status": "error",
                "message": f"Error processing message: {str(e)}"
            }
    
    def generate_reply(self, message: Dict[str, Any]) -> Dict[str, Any]:
        """
        Generate a reply to a message using the AG2 agent.
        
        Args:
            message: The message to reply to.
            
        Returns:
            A dictionary containing the reply.
        """
        analysis_result = self.process_message(message)
        
        formatted_message = self._format_message_for_agent(analysis_result)
        
        reply = self.agent.generate_reply(formatted_message)
        
        if isinstance(reply, dict):
            reply["iipm_analysis_data"] = analysis_result
        else:
            reply = {
                "content": reply,
                "iipm_analysis_data": analysis_result
            }
        
        return reply
    
    def _format_message_for_agent(self, analysis_result: Dict[str, Any]) -> Dict[str, Any]:
        """
        Format an analysis result as a message for the AG2 agent.
        
        Args:
            analysis_result: The analysis result to format.
            
        Returns:
            A dictionary containing the formatted message.
        """
        if analysis_result["status"] == "error":
            return {
                "content": f"Error: {analysis_result['message']}"
            }
        
        data = analysis_result["data"]
        app_count = data["app_count"]
        dependency_count = data["dependency_count"]
        total_app_count = data["total_app_count"]
        app_details = data["app_details"]
        rto_analysis = data["rto_analysis"]
        rpo_analysis = data["rpo_analysis"]
        criticality_analysis = data["criticality_analysis"]
        dr_test_analysis = data["dr_test_analysis"]
        recommendations = data["recommendations"]
        
        message = f"""
        I have analyzed {app_count} applications and their {dependency_count} dependencies using the IIPM API.
        
        Overall Statistics:
        - Primary applications: {app_count}
        - Dependencies: {dependency_count}
        - Total applications analyzed: {total_app_count}
        
        RTO Analysis:
        - Critical RTO (≤ 60 min): {len(rto_analysis["categories"]["critical"])} applications
        - High RTO (≤ 240 min): {len(rto_analysis["categories"]["high"])} applications
        - Medium RTO (≤ 480 min): {len(rto_analysis["categories"]["medium"])} applications
        - Low RTO (> 480 min): {len(rto_analysis["categories"]["low"])} applications
        - Minimum RTO: {rto_analysis["min_rto"]} minutes (Application: {rto_analysis["min_rto_app"]})
        
        RPO Analysis:
        - Critical RPO (≤ 15 min): {len(rpo_analysis["categories"]["critical"])} applications
        - High RPO (≤ 60 min): {len(rpo_analysis["categories"]["high"])} applications
        - Medium RPO (≤ 240 min): {len(rpo_analysis["categories"]["medium"])} applications
        - Low RPO (> 240 min): {len(rpo_analysis["categories"]["low"])} applications
        - Minimum RPO: {rpo_analysis["min_rpo"]} minutes (Application: {rpo_analysis["min_rpo_app"]})
        
        Business Criticality:
        - Critical: {len(criticality_analysis["categories"]["Critical"])} applications
        - High: {len(criticality_analysis["categories"]["High"])} applications
        - Medium: {len(criticality_analysis["categories"]["Medium"])} applications
        - Low: {len(criticality_analysis["categories"]["Low"])} applications
        
        DR Test Results:
        - Passed: {len(dr_test_analysis["categories"]["passed"])} applications
        - Failed: {len(dr_test_analysis["categories"]["failed"])} applications
        - Partial Success: {len(dr_test_analysis["categories"]["partial"])} applications
        - Not Tested: {len(dr_test_analysis["categories"]["not_tested"])} applications
        """
        
        if recommendations:
            message += f"\n\nRecommendations ({len(recommendations)}):"
            for i, recommendation in enumerate(recommendations, 1):
                message += f"\n{i}. {recommendation}"
        else:
            message += "\n\nNo recommendations."
        
        message += "\n\nThe complete analysis details are available in the structured data."
        
        return {
            "content": message,
            "role": "assistant"
        }

iipm_analysis_agent = IIPMAnalysisAgent()
