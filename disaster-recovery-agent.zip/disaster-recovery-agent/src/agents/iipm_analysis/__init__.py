"""
IIPM Analysis Agent package.

This package provides the IIPM Analysis Agent for the Disaster Recovery Compliance Agent System.
"""

from src.agents.iipm_analysis.agent import IIPMAnalysisAgent, iipm_analysis_agent

__all__ = ["IIPMAnalysisAgent", "iipm_analysis_agent"]
