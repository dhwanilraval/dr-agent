"""
Reasoning Agent for the Disaster Recovery Compliance Agent System.

This agent is responsible for analyzing the outputs from all previous agents
and making judgments about the overall quality of disaster recovery readiness,
risks, and RTO/RPO expectations.
"""

import logging
from typing import List, Dict, Any, Optional, Set
import json

from autogen import AssistantAgent

from src.config.config import AGENT_CONFIG, LLM_CONFIG

logger = logging.getLogger(__name__)

class ReasoningAgent:
    """
    Agent responsible for analyzing DR readiness and making judgments.
    
    This agent analyzes outputs from all previous agents and makes judgments about
    the overall quality of disaster recovery readiness, risks, and RTO/RPO expectations.
    """
    
    def __init__(self):
        """Initialize the Reasoning Agent."""
        self.config = AGENT_CONFIG["reasoning_agent"]
        
        try:
            self.agent = AssistantAgent(
                name=self.config["name"],
                system_message=self._create_system_message(),
                llm_config=LLM_CONFIG
            )
        except Exception as e:
            logger.warning(f"Failed to initialize AssistantAgent: {str(e)}")
            agent_name = self.config["name"]
            self.agent = type('MockAgent', (), {
                'name': agent_name,
                'system_message': self._create_system_message(),
                'generate_reply': lambda self, message: {
                    "content": f"Mock reply from {agent_name}",
                    "role": "assistant"
                }
            })()
        
        logger.info(f"Initialized {self.config['name']}")
    
    def _create_system_message(self) -> str:
        """
        Create the system message for the agent.
        
        Returns:
            The system message string.
        """
        return f"""
        You are the {self.config['name']}, responsible for analyzing the outputs from all previous agents
        and making judgments about the overall quality of disaster recovery readiness.
        
        {self.config['description']}
        
        You receive inputs from the following agents:
        1. Process Dependency Agent - Provides information about application dependencies
        2. DR Plans Fetcher Agent - Provides disaster recovery plans
        3. Description Analysis Agent - Provides analysis of plan descriptions against standards
        4. Tasks Analysis Agent - Provides analysis of recovery tasks against standards
        5. Device Reconciliation Agent - Provides analysis of devices in plans vs. actual devices
        6. IIPM Analysis Agent - Provides application details including RTO/RPO requirements
        
        Based on these inputs, you should:
        1. Judge the overall quality of disaster recovery readiness for the business process
        2. Identify risks associated with DR for the business process
        3. Compare expected RTO/RPO with actual RTO/RPO from dependent applications
        4. Highlight if dependent applications will be able to achieve the RTO/RPO of the overall business process
        5. Provide recommendations for improving DR readiness
        
        Your output should include:
        - Overall DR readiness score (0-100%)
        - Risk assessment (Critical, High, Medium, Low)
        - RTO/RPO analysis
        - Key findings and recommendations
        """
    
    def analyze_dr_readiness(self, message: Dict[str, Any]) -> Dict[str, Any]:
        """
        Analyze disaster recovery readiness based on inputs from all agents.
        
        Args:
            message: The message containing inputs from all agents.
            
        Returns:
            A dictionary containing the analysis results.
        """
        try:
            logger.info("Analyzing disaster recovery readiness")
            
            process_dependency_data = message.get("process_dependency_data", {}).get("data", {})
            plans_data = message.get("plans_data", {}).get("data", {})
            description_analysis_data = message.get("description_analysis_data", {}).get("data", {})
            tasks_analysis_data = message.get("tasks_analysis_data", {}).get("data", {})
            device_reconciliation_data = message.get("device_reconciliation_data", {}).get("data", {})
            iipm_analysis_data = message.get("iipm_analysis_data", {}).get("data", {})
            
            if not process_dependency_data:
                logger.warning("Missing process dependency data")
            
            if not plans_data:
                logger.warning("Missing plans data")
            
            if not description_analysis_data:
                logger.warning("Missing description analysis data")
            
            if not tasks_analysis_data:
                logger.warning("Missing tasks analysis data")
            
            if not device_reconciliation_data:
                logger.warning("Missing device reconciliation data")
            
            if not iipm_analysis_data:
                logger.warning("Missing IIPM analysis data")
            
            app_codes = process_dependency_data.get("app_codes", [])
            dependent_app_codes = process_dependency_data.get("dependent_app_codes", [])
            
            plans = plans_data.get("plans", [])
            
            dr_readiness_score = self._calculate_dr_readiness_score(
                description_analysis_data,
                tasks_analysis_data,
                device_reconciliation_data,
                iipm_analysis_data
            )
            
            risk_assessment = self._assess_risks(
                description_analysis_data,
                tasks_analysis_data,
                device_reconciliation_data,
                iipm_analysis_data
            )
            
            rto_rpo_analysis = self._analyze_rto_rpo(
                app_codes,
                dependent_app_codes,
                plans,
                iipm_analysis_data
            )
            
            findings_recommendations = self._generate_findings_recommendations(
                dr_readiness_score,
                risk_assessment,
                rto_rpo_analysis,
                description_analysis_data,
                tasks_analysis_data,
                device_reconciliation_data,
                iipm_analysis_data
            )
            
            result = {
                "status": "success",
                "data": {
                    "dr_readiness_score": dr_readiness_score,
                    "risk_assessment": risk_assessment,
                    "rto_rpo_analysis": rto_rpo_analysis,
                    "findings_recommendations": findings_recommendations
                }
            }
            
            logger.info(f"Completed DR readiness analysis with score: {dr_readiness_score['overall_score']}%")
            
            return result
        
        except Exception as e:
            logger.exception("Error analyzing disaster recovery readiness")
            
            return {
                "status": "error",
                "message": f"Error analyzing disaster recovery readiness: {str(e)}"
            }
    
    def _calculate_dr_readiness_score(
        self,
        description_analysis_data: Dict[str, Any],
        tasks_analysis_data: Dict[str, Any],
        device_reconciliation_data: Dict[str, Any],
        iipm_analysis_data: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Calculate the DR readiness score based on inputs from all agents.
        
        Args:
            description_analysis_data: Data from the Description Analysis Agent.
            tasks_analysis_data: Data from the Tasks Analysis Agent.
            device_reconciliation_data: Data from the Device Reconciliation Agent.
            iipm_analysis_data: Data from the IIPM Analysis Agent.
            
        Returns:
            A dictionary containing the DR readiness score.
        """
        description_score = 0
        tasks_score = 0
        device_score = 0
        testing_score = 0
        
        if description_analysis_data:
            plan_analyses = description_analysis_data.get("plan_analyses", {})
            if plan_analyses:
                total_compliance = sum(analysis.get("compliance_percentage", 0) for analysis in plan_analyses.values())
                description_score = (total_compliance / len(plan_analyses)) * 0.25
        
        if tasks_analysis_data:
            plan_analyses = tasks_analysis_data.get("plan_analyses", {})
            if plan_analyses:
                total_compliance = sum(analysis.get("compliance_percentage", 0) for analysis in plan_analyses.values())
                tasks_score = (total_compliance / len(plan_analyses)) * 0.25
        
        if device_reconciliation_data:
            avg_coverage = device_reconciliation_data.get("avg_coverage_percentage", 0)
            device_score = avg_coverage * 0.25
        
        if iipm_analysis_data:
            dr_test_analysis = iipm_analysis_data.get("dr_test_analysis", {})
            if dr_test_analysis:
                categories = dr_test_analysis.get("categories", {})
                total_apps = sum(len(apps) for apps in categories.values())
                if total_apps > 0:
                    passed_apps = len(categories.get("passed", []))
                    partial_apps = len(categories.get("partial", []))
                    testing_score = ((passed_apps + (partial_apps * 0.5)) / total_apps) * 25
        
        overall_score = description_score + tasks_score + device_score + testing_score
        
        return {
            "overall_score": round(overall_score, 2),
            "description_score": round(description_score, 2),
            "tasks_score": round(tasks_score, 2),
            "device_score": round(device_score, 2),
            "testing_score": round(testing_score, 2)
        }
    
    def _assess_risks(
        self,
        description_analysis_data: Dict[str, Any],
        tasks_analysis_data: Dict[str, Any],
        device_reconciliation_data: Dict[str, Any],
        iipm_analysis_data: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Assess risks based on inputs from all agents.
        
        Args:
            description_analysis_data: Data from the Description Analysis Agent.
            tasks_analysis_data: Data from the Tasks Analysis Agent.
            device_reconciliation_data: Data from the Device Reconciliation Agent.
            iipm_analysis_data: Data from the IIPM Analysis Agent.
            
        Returns:
            A dictionary containing the risk assessment.
        """
        risks = []
        
        if description_analysis_data:
            plan_analyses = description_analysis_data.get("plan_analyses", {})
            for plan_id, analysis in plan_analyses.items():
                compliance = analysis.get("compliance_percentage", 0)
                if compliance < 50:
                    risks.append({
                        "level": "Critical",
                        "category": "Plan Description",
                        "description": f"Plan {plan_id} has very low description compliance ({compliance}%)",
                        "impact": "May lead to confusion during DR execution",
                        "mitigation": "Review and update plan description according to standards"
                    })
                elif compliance < 75:
                    risks.append({
                        "level": "High",
                        "category": "Plan Description",
                        "description": f"Plan {plan_id} has low description compliance ({compliance}%)",
                        "impact": "May lead to misunderstandings during DR execution",
                        "mitigation": "Review and update plan description according to standards"
                    })
        
        if tasks_analysis_data:
            plan_analyses = tasks_analysis_data.get("plan_analyses", {})
            for plan_id, analysis in plan_analyses.items():
                compliance = analysis.get("compliance_percentage", 0)
                if compliance < 50:
                    risks.append({
                        "level": "Critical",
                        "category": "Recovery Tasks",
                        "description": f"Plan {plan_id} has very low task compliance ({compliance}%)",
                        "impact": "May lead to failed recovery during DR event",
                        "mitigation": "Review and update recovery tasks according to standards"
                    })
                elif compliance < 75:
                    risks.append({
                        "level": "High",
                        "category": "Recovery Tasks",
                        "description": f"Plan {plan_id} has low task compliance ({compliance}%)",
                        "impact": "May lead to delayed recovery during DR event",
                        "mitigation": "Review and update recovery tasks according to standards"
                    })
        
        if device_reconciliation_data:
            plan_analyses = device_reconciliation_data.get("plan_analyses", {})
            for plan_id, analysis in plan_analyses.items():
                coverage = analysis.get("coverage_percentage", 0)
                if coverage < 50:
                    risks.append({
                        "level": "Critical",
                        "category": "Device Coverage",
                        "description": f"Plan {plan_id} has very low device coverage ({coverage}%)",
                        "impact": "Critical devices may be missed during recovery",
                        "mitigation": "Update plan to include all actual devices"
                    })
                elif coverage < 75:
                    risks.append({
                        "level": "High",
                        "category": "Device Coverage",
                        "description": f"Plan {plan_id} has low device coverage ({coverage}%)",
                        "impact": "Some devices may be missed during recovery",
                        "mitigation": "Update plan to include all actual devices"
                    })
        
        if iipm_analysis_data:
            dr_test_analysis = iipm_analysis_data.get("dr_test_analysis", {})
            categories = dr_test_analysis.get("categories", {})
            
            critical_apps = iipm_analysis_data.get("criticality_analysis", {}).get("categories", {}).get("Critical", [])
            failed_apps = categories.get("failed", [])
            not_tested_apps = categories.get("not_tested", [])
            
            critical_failed = [app for app in critical_apps if app in failed_apps]
            critical_not_tested = [app for app in critical_apps if app in not_tested_apps]
            
            if critical_failed:
                risks.append({
                    "level": "Critical",
                    "category": "DR Testing",
                    "description": f"{len(critical_failed)} critical applications failed their last DR test",
                    "impact": "Critical applications may not recover successfully",
                    "mitigation": "Address DR issues and retest critical applications"
                })
            
            if critical_not_tested:
                risks.append({
                    "level": "Critical",
                    "category": "DR Testing",
                    "description": f"{len(critical_not_tested)} critical applications have not been tested for DR",
                    "impact": "Unknown recovery capability for critical applications",
                    "mitigation": "Schedule DR tests for critical applications"
                })
        
        risk_counts = {
            "Critical": len([r for r in risks if r["level"] == "Critical"]),
            "High": len([r for r in risks if r["level"] == "High"]),
            "Medium": len([r for r in risks if r["level"] == "Medium"]),
            "Low": len([r for r in risks if r["level"] == "Low"])
        }
        
        overall_risk = "Low"
        if risk_counts["Critical"] > 0:
            overall_risk = "Critical"
        elif risk_counts["High"] > 0:
            overall_risk = "High"
        elif risk_counts["Medium"] > 0:
            overall_risk = "Medium"
        
        return {
            "overall_risk": overall_risk,
            "risk_counts": risk_counts,
            "risks": risks
        }
    
    def _analyze_rto_rpo(
        self,
        app_codes: List[str],
        dependent_app_codes: List[str],
        plans: List[Dict[str, Any]],
        iipm_analysis_data: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Analyze RTO/RPO based on inputs from all agents.
        
        Args:
            app_codes: List of primary application codes.
            dependent_app_codes: List of dependent application codes.
            plans: List of disaster recovery plans.
            iipm_analysis_data: Data from the IIPM Analysis Agent.
            
        Returns:
            A dictionary containing the RTO/RPO analysis.
        """
        result = {
            "primary_apps": {},
            "dependent_apps": {},
            "rto_conflicts": [],
            "rpo_conflicts": [],
            "overall_achievable_rto": None,
            "overall_achievable_rpo": None
        }
        
        app_details = iipm_analysis_data.get("app_details", {})
        
        for app_code in app_codes:
            if app_code in app_details:
                details = app_details[app_code]
                result["primary_apps"][app_code] = {
                    "name": details.get("name", ""),
                    "rto": details.get("recovery_time_objective"),
                    "rpo": details.get("recovery_point_objective"),
                    "business_criticality": details.get("business_criticality")
                }
        
        for app_code in dependent_app_codes:
            if app_code in app_details:
                details = app_details[app_code]
                result["dependent_apps"][app_code] = {
                    "name": details.get("name", ""),
                    "rto": details.get("recovery_time_objective"),
                    "rpo": details.get("recovery_point_objective"),
                    "business_criticality": details.get("business_criticality")
                }
        
        for primary_app, primary_details in result["primary_apps"].items():
            primary_rto = primary_details.get("rto")
            primary_rpo = primary_details.get("rpo")
            
            if primary_rto is not None:
                for dep_app, dep_details in result["dependent_apps"].items():
                    dep_rto = dep_details.get("rto")
                    if dep_rto is not None and dep_rto > primary_rto:
                        result["rto_conflicts"].append({
                            "primary_app": primary_app,
                            "primary_rto": primary_rto,
                            "dependent_app": dep_app,
                            "dependent_rto": dep_rto,
                            "difference": dep_rto - primary_rto
                        })
            
            if primary_rpo is not None:
                for dep_app, dep_details in result["dependent_apps"].items():
                    dep_rpo = dep_details.get("rpo")
                    if dep_rpo is not None and dep_rpo > primary_rpo:
                        result["rpo_conflicts"].append({
                            "primary_app": primary_app,
                            "primary_rpo": primary_rpo,
                            "dependent_app": dep_app,
                            "dependent_rpo": dep_rpo,
                            "difference": dep_rpo - primary_rpo
                        })
        
        all_rtos = []
        all_rpos = []
        
        for app_details in result["primary_apps"].values():
            if app_details.get("rto") is not None:
                all_rtos.append(app_details["rto"])
            if app_details.get("rpo") is not None:
                all_rpos.append(app_details["rpo"])
        
        for app_details in result["dependent_apps"].values():
            if app_details.get("rto") is not None:
                all_rtos.append(app_details["rto"])
            if app_details.get("rpo") is not None:
                all_rpos.append(app_details["rpo"])
        
        if all_rtos:
            result["overall_achievable_rto"] = max(all_rtos)
        
        if all_rpos:
            result["overall_achievable_rpo"] = max(all_rpos)
        
        return result
    
    def _generate_findings_recommendations(
        self,
        dr_readiness_score: Dict[str, Any],
        risk_assessment: Dict[str, Any],
        rto_rpo_analysis: Dict[str, Any],
        description_analysis_data: Dict[str, Any],
        tasks_analysis_data: Dict[str, Any],
        device_reconciliation_data: Dict[str, Any],
        iipm_analysis_data: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Generate findings and recommendations based on analysis results.
        
        Args:
            dr_readiness_score: DR readiness score.
            risk_assessment: Risk assessment.
            rto_rpo_analysis: RTO/RPO analysis.
            description_analysis_data: Data from the Description Analysis Agent.
            tasks_analysis_data: Data from the Tasks Analysis Agent.
            device_reconciliation_data: Data from the Device Reconciliation Agent.
            iipm_analysis_data: Data from the IIPM Analysis Agent.
            
        Returns:
            A dictionary containing findings and recommendations.
        """
        findings = []
        recommendations = []
        
        overall_score = dr_readiness_score.get("overall_score", 0)
        if overall_score < 50:
            findings.append({
                "category": "Overall DR Readiness",
                "severity": "Critical",
                "description": f"Overall DR readiness score is very low ({overall_score}%)"
            })
        elif overall_score < 75:
            findings.append({
                "category": "Overall DR Readiness",
                "severity": "High",
                "description": f"Overall DR readiness score is below target ({overall_score}%)"
            })
        else:
            findings.append({
                "category": "Overall DR Readiness",
                "severity": "Info",
                "description": f"Overall DR readiness score is good ({overall_score}%)"
            })
        
        component_scores = {
            "Plan Descriptions": dr_readiness_score.get("description_score", 0),
            "Recovery Tasks": dr_readiness_score.get("tasks_score", 0),
            "Device Coverage": dr_readiness_score.get("device_score", 0),
            "DR Testing": dr_readiness_score.get("testing_score", 0)
        }
        
        for component, score in component_scores.items():
            if score < 12.5:  # Less than 50% of the 25% weight
                findings.append({
                    "category": component,
                    "severity": "Critical",
                    "description": f"{component} score is very low ({score}%)"
                })
            elif score < 18.75:  # Less than 75% of the 25% weight
                findings.append({
                    "category": component,
                    "severity": "High",
                    "description": f"{component} score is below target ({score}%)"
                })
        
        critical_risks = [r for r in risk_assessment.get("risks", []) if r["level"] == "Critical"]
        high_risks = [r for r in risk_assessment.get("risks", []) if r["level"] == "High"]
        
        if critical_risks:
            findings.append({
                "category": "Risk Assessment",
                "severity": "Critical",
                "description": f"Found {len(critical_risks)} critical risks"
            })
        
        if high_risks:
            findings.append({
                "category": "Risk Assessment",
                "severity": "High",
                "description": f"Found {len(high_risks)} high risks"
            })
        
        rto_conflicts = rto_rpo_analysis.get("rto_conflicts", [])
        rpo_conflicts = rto_rpo_analysis.get("rpo_conflicts", [])
        
        if rto_conflicts:
            findings.append({
                "category": "RTO Conflicts",
                "severity": "Critical" if len(rto_conflicts) > 2 else "High",
                "description": f"Found {len(rto_conflicts)} RTO conflicts between primary and dependent applications"
            })
        
        if rpo_conflicts:
            findings.append({
                "category": "RPO Conflicts",
                "severity": "Critical" if len(rpo_conflicts) > 2 else "High",
                "description": f"Found {len(rpo_conflicts)} RPO conflicts between primary and dependent applications"
            })
        
        
        if dr_readiness_score.get("description_score", 0) < 18.75:  # Less than 75% of the 25% weight
            recommendations.append({
                "category": "Plan Descriptions",
                "priority": "High",
                "description": "Improve disaster recovery plan descriptions to align with standards",
                "details": "Review and update plan descriptions to include all required sections and details according to the standard DR plan template"
            })
        
        if dr_readiness_score.get("tasks_score", 0) < 18.75:  # Less than 75% of the 25% weight
            recommendations.append({
                "category": "Recovery Tasks",
                "priority": "High",
                "description": "Enhance recovery tasks to align with standards",
                "details": "Review and update recovery tasks to include all required steps, dependencies, and responsible teams according to the standard DR plan template"
            })
        
        if dr_readiness_score.get("device_score", 0) < 18.75:  # Less than 75% of the 25% weight
            recommendations.append({
                "category": "Device Coverage",
                "priority": "High",
                "description": "Update DR plans to include all actual devices",
                "details": "Reconcile devices in DR plans with actual devices to ensure complete coverage during recovery"
            })
        
        if dr_readiness_score.get("testing_score", 0) < 18.75:  # Less than 75% of the 25% weight
            recommendations.append({
                "category": "DR Testing",
                "priority": "Critical",
                "description": "Conduct DR tests for untested applications",
                "details": "Schedule and execute DR tests for all applications, especially critical ones that have not been tested or have failed previous tests"
            })
        
        if rto_conflicts:
            recommendations.append({
                "category": "RTO Alignment",
                "priority": "Critical",
                "description": "Align RTO values between primary and dependent applications",
                "details": "Review and adjust RTO values for dependent applications to ensure they can meet the RTO requirements of primary applications"
            })
        
        if rpo_conflicts:
            recommendations.append({
                "category": "RPO Alignment",
                "priority": "Critical",
                "description": "Align RPO values between primary and dependent applications",
                "details": "Review and adjust RPO values for dependent applications to ensure they can meet the RPO requirements of primary applications"
            })
        
        if iipm_analysis_data and "recommendations" in iipm_analysis_data:
            for i, rec in enumerate(iipm_analysis_data["recommendations"]):
                if "Critical" in rec:
                    priority = "Critical"
                elif "Warning" in rec:
                    priority = "High"
                else:
                    priority = "Medium"
                
                recommendations.append({
                    "category": "Application Management",
                    "priority": priority,
                    "description": rec,
                    "details": rec
                })
        
        return {
            "findings": findings,
            "recommendations": recommendations
        }
    
    def process_message(self, message: Dict[str, Any]) -> Dict[str, Any]:
        """
        Process a message from another agent.
        
        Args:
            message: The message to process.
            
        Returns:
            A dictionary containing the response.
        """
        try:
            required_inputs = [
                "process_dependency_data",
                "plans_data",
                "description_analysis_data",
                "tasks_analysis_data",
                "device_reconciliation_data",
                "iipm_analysis_data"
            ]
            
            has_inputs = False
            for input_key in required_inputs:
                if input_key in message and "data" in message[input_key]:
                    has_inputs = True
                    break
            
            if not has_inputs:
                return {
                    "status": "error",
                    "message": "No agent inputs provided"
                }
            
            analysis_result = self.analyze_dr_readiness(message)
            
            if analysis_result["status"] == "error":
                return analysis_result
            
            response = {
                "status": "success",
                "message": "Analyzed disaster recovery readiness",
                "data": analysis_result["data"]
            }
            
            return response
        
        except Exception as e:
            logger.exception(f"Error processing message")
            
            return {
                "status": "error",
                "message": f"Error processing message: {str(e)}"
            }
    
    def generate_reply(self, message: Dict[str, Any]) -> Dict[str, Any]:
        """
        Generate a reply to a message using the AG2 agent.
        
        Args:
            message: The message to reply to.
            
        Returns:
            A dictionary containing the reply.
        """
        analysis_result = self.process_message(message)
        
        formatted_message = self._format_message_for_agent(analysis_result)
        
        reply = self.agent.generate_reply(formatted_message)
        
        if isinstance(reply, dict):
            reply["reasoning_data"] = analysis_result
        else:
            reply = {
                "content": reply,
                "reasoning_data": analysis_result
            }
        
        return reply
    
    def _format_message_for_agent(self, analysis_result: Dict[str, Any]) -> Dict[str, Any]:
        """
        Format an analysis result as a message for the AG2 agent.
        
        Args:
            analysis_result: The analysis result to format.
            
        Returns:
            A dictionary containing the formatted message.
        """
        if analysis_result["status"] == "error":
            return {
                "content": f"Error: {analysis_result['message']}"
            }
        
        data = analysis_result["data"]
        dr_readiness_score = data["dr_readiness_score"]
        risk_assessment = data["risk_assessment"]
        rto_rpo_analysis = data["rto_rpo_analysis"]
        findings_recommendations = data["findings_recommendations"]
        
        message = f"""
        
        - DR Readiness Score: {dr_readiness_score['overall_score']}%
        - Risk Level: {risk_assessment['overall_risk']}
        
        - Plan Descriptions: {dr_readiness_score['description_score']}%
        - Recovery Tasks: {dr_readiness_score['tasks_score']}%
        - Device Coverage: {dr_readiness_score['device_score']}%
        - DR Testing: {dr_readiness_score['testing_score']}%
        
        - Critical Risks: {risk_assessment['risk_counts']['Critical']}
        - High Risks: {risk_assessment['risk_counts']['High']}
        - Medium Risks: {risk_assessment['risk_counts']['Medium']}
        - Low Risks: {risk_assessment['risk_counts']['Low']}
        
        - RTO Conflicts: {len(rto_rpo_analysis['rto_conflicts'])}
        - RPO Conflicts: {len(rto_rpo_analysis['rpo_conflicts'])}
        - Overall Achievable RTO: {rto_rpo_analysis['overall_achievable_rto']} minutes
        - Overall Achievable RPO: {rto_rpo_analysis['overall_achievable_rpo']} minutes
        
        """
        
        for i, finding in enumerate(findings_recommendations["findings"], 1):
            message += f"\n{i}. [{finding['severity']}] {finding['category']}: {finding['description']}"
        
        message += "\n\n## Recommendations\n"
        
        for i, recommendation in enumerate(findings_recommendations["recommendations"], 1):
            message += f"\n{i}. [{recommendation['priority']}] {recommendation['category']}: {recommendation['description']}"
        
        message += "\n\nThe complete analysis details are available in the structured data."
        
        return {
            "content": message,
            "role": "assistant"
        }

reasoning_agent = ReasoningAgent()
