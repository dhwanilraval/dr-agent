"""
Tasks Analysis Agent for the Disaster Recovery Compliance Agent System.

This agent is responsible for analyzing each plan's recovery tasks against standard plans
stored in PGVector Collection.
"""

import logging
from typing import List, Dict, Any, Optional

from autogen import AssistantAgent

from src.mock_apis.pgvector.api import mock_pgvector_api
from src.models.data_models import DisasterRecoveryPlan, RecoveryTask, StandardPlan
from src.config.config import AGENT_CONFIG, LLM_CONFIG

logger = logging.getLogger(__name__)

class TasksAnalysisAgent:
    """
    Agent responsible for analyzing plan recovery tasks against standard plans.
    
    This agent uses the PGVector API to access standard disaster recovery plans and
    analyze each plan's recovery tasks against the standard plan.
    """
    
    def __init__(self):
        """Initialize the Tasks Analysis Agent."""
        self.config = AGENT_CONFIG["tasks_analysis_agent"]
        self.pgvector_api = mock_pgvector_api
        
        try:
            self.agent = AssistantAgent(
                name=self.config["name"],
                system_message=self._create_system_message(),
                llm_config=LLM_CONFIG
            )
        except Exception:
            logger.exception("Failed to initialize AssistantAgent")
            self.agent = type('MockAgent', (), {
                'name': self.config["name"],
                'system_message': self._create_system_message(),
                'generate_reply': lambda message: {
                    "content": f"Mock reply from {self.config['name']}",
                    "role": "assistant"
                }
            })()
        
        logger.info(f"Initialized {self.config['name']}")
    
    def _create_system_message(self) -> str:
        """
        Create the system message for the agent.
        
        Returns:
            The system message string.
        """
        return f"""
        You are the {self.config['name']}, responsible for analyzing each plan's recovery tasks
        against standard plans stored in PGVector Collection.
        
        {self.config['description']}
        
        You have access to the PGVector API to access standard disaster recovery plans and
        analyze each plan's recovery tasks against the standard plan.
        
        When given a list of disaster recovery plans, you should:
        1. Analyze each plan's recovery tasks against the standard plan
        2. Identify gaps and areas for improvement in the tasks
        3. Provide a detailed summary, list of gaps, and recommended improvements for each plan
        
        Your output should include:
        - A detailed summary of the analysis for each plan's recovery tasks
        - Identified gaps in each plan's recovery tasks
        - Recommended improvements for each plan's recovery tasks
        - Compliance scores for each plan against the standard
        - Task-specific analysis for critical tasks
        """
    
    def analyze_tasks(self, plans: List[DisasterRecoveryPlan]) -> Dict[str, Any]:
        """
        Analyze recovery tasks of disaster recovery plans against standard plans.
        
        Args:
            plans: The list of disaster recovery plans to analyze.
            
        Returns:
            A dictionary containing the analysis results.
        """
        try:
            logger.info(f"Analyzing recovery tasks for {len(plans)} plans")
            
            standard_plan = self.pgvector_api.get_standard_plan_by_type("tasks")
            
            if not standard_plan:
                logger.warning("Standard plan for tasks not found")
                return {
                    "status": "error",
                    "data": {
                        "message": "Standard plan for tasks not found"
                    }
                }
            
            plan_analyses = {}
            for plan in plans:
                logger.info(f"Analyzing recovery tasks for plan {plan.id} ({plan.app_code})")
                
                tasks_dict = []
                for task in plan.tasks:
                    task_dict = {
                        "id": task.id,
                        "name": task.name,
                        "description": task.description,
                        "sequence": task.sequence,
                        "estimated_duration": task.estimated_duration,
                        "responsible_team": task.responsible_team,
                        "dependencies": task.dependencies
                    }
                    tasks_dict.append(task_dict)
                
                analysis = self.pgvector_api.analyze_plan_tasks(tasks_dict)
                
                if analysis["status"] == "success":
                    plan_analyses[plan.id] = {
                        "plan_id": plan.id,
                        "app_code": plan.app_code,
                        "plan_name": plan.name,
                        "task_count": len(plan.tasks),
                        "overall_compliance_score": analysis["overall_compliance_score"],
                        "task_compliance_score": analysis["task_compliance_score"],
                        "section_compliance_score": analysis["section_compliance_score"],
                        "summary": analysis["summary"],
                        "gaps": analysis["gaps"],
                        "improvements": analysis["improvements"],
                        "section_analyses": analysis["section_analyses"],
                        "task_analyses": analysis["task_analyses"]
                    }
                else:
                    logger.warning(f"Error analyzing tasks for plan {plan.id}: {analysis['message']}")
                    plan_analyses[plan.id] = {
                        "plan_id": plan.id,
                        "app_code": plan.app_code,
                        "plan_name": plan.name,
                        "task_count": len(plan.tasks),
                        "status": "error",
                        "message": analysis["message"]
                    }
            
            plan_count = len(plans)
            analyzed_count = sum(1 for pa in plan_analyses.values() if "overall_compliance_score" in pa)
            error_count = plan_count - analyzed_count
            
            if analyzed_count > 0:
                avg_compliance_score = sum(pa["overall_compliance_score"] for pa in plan_analyses.values() if "overall_compliance_score" in pa) / analyzed_count
            else:
                avg_compliance_score = 0.0
            
            result = {
                "status": "success",
                "data": {
                    "standard_plan_id": standard_plan.id,
                    "standard_plan_name": standard_plan.name,
                    "plan_count": plan_count,
                    "analyzed_count": analyzed_count,
                    "error_count": error_count,
                    "avg_compliance_score": avg_compliance_score,
                    "plan_analyses": plan_analyses
                }
            }
            
            logger.info(f"Analyzed tasks for {analyzed_count} plans with average compliance score {avg_compliance_score:.2f}")
            
            return result
        
        except Exception:
            logger.exception(f"Error analyzing tasks for {len(plans)} plans")
            raise
    
    def process_message(self, message: Dict[str, Any]) -> Dict[str, Any]:
        """
        Process a message from another agent.
        
        Args:
            message: The message to process.
            
        Returns:
            A dictionary containing the response.
        """
        try:
            plans = []
            
            if "plans_data" in message and "data" in message["plans_data"]:
                data = message["plans_data"]["data"]
                if "plans" in data:
                    for plan_data in data["plans"]:
                        try:
                            from datetime import datetime
                            plan_data["created_at"] = datetime.fromisoformat(plan_data["created_at"])
                            plan_data["updated_at"] = datetime.fromisoformat(plan_data["updated_at"])
                            
                            plan = DisasterRecoveryPlan(**plan_data)
                            plans.append(plan)
                        except Exception:
                            logger.exception(f"Error converting plan data to DisasterRecoveryPlan")
            
            if not plans:
                return {
                    "status": "error",
                    "message": "No plans provided"
                }
            
            analysis_result = self.analyze_tasks(plans)
            
            response = {
                "status": "success",
                "message": f"Analyzed recovery tasks for {analysis_result['data']['analyzed_count']} plans",
                "data": analysis_result['data']
            }
            
            return response
        
        except Exception:
            logger.exception(f"Error processing message")
            
            return {
                "status": "error",
                "message": f"Error processing message"
            }
    
    def generate_reply(self, message: Dict[str, Any]) -> Dict[str, Any]:
        """
        Generate a reply to a message using the AG2 agent.
        
        Args:
            message: The message to reply to.
            
        Returns:
            A dictionary containing the reply.
        """
        analysis_result = self.process_message(message)
        
        formatted_message = self._format_message_for_agent(analysis_result)
        
        reply = self.agent.generate_reply(formatted_message)
        
        if isinstance(reply, dict):
            reply["tasks_analysis_data"] = analysis_result
        else:
            reply = {
                "content": reply,
                "tasks_analysis_data": analysis_result
            }
        
        return reply
    
    def _format_message_for_agent(self, analysis_result: Dict[str, Any]) -> Dict[str, Any]:
        """
        Format an analysis result as a message for the AG2 agent.
        
        Args:
            analysis_result: The analysis result to format.
            
        Returns:
            A dictionary containing the formatted message.
        """
        if analysis_result["status"] == "error":
            return {
                "content": f"Error: {analysis_result['message']}"
            }
        
        data = analysis_result["data"]
        standard_plan_name = data["standard_plan_name"]
        plan_count = data["plan_count"]
        analyzed_count = data["analyzed_count"]
        error_count = data["error_count"]
        avg_compliance_score = data["avg_compliance_score"]
        plan_analyses = data["plan_analyses"]
        
        message = f"""
        I have analyzed the recovery tasks of {analyzed_count} disaster recovery plans against the standard plan "{standard_plan_name}".
        
        Overall Statistics:
        - Total plans: {plan_count}
        - Successfully analyzed: {analyzed_count}
        - Failed to analyze: {error_count}
        - Average compliance score: {avg_compliance_score:.2f}
        
        Here is a detailed summary of the analysis for each plan's recovery tasks:
        """
        
        for plan_id, analysis in plan_analyses.items():
            if "status" in analysis and analysis["status"] == "error":
                message += f"\n\nPlan {analysis['plan_id']} ({analysis['app_code']}): {analysis['plan_name']}"
                message += f"\nError: {analysis['message']}"
                continue
            
            app_code = analysis["app_code"]
            plan_name = analysis["plan_name"]
            task_count = analysis["task_count"]
            overall_compliance_score = analysis["overall_compliance_score"]
            task_compliance_score = analysis["task_compliance_score"]
            section_compliance_score = analysis["section_compliance_score"]
            summary = analysis["summary"]
            gaps = analysis["gaps"]
            improvements = analysis["improvements"]
            task_analyses = analysis["task_analyses"]
            
            message += f"\n\nPlan {plan_id} ({app_code}): {plan_name}"
            message += f"\nTask Count: {task_count}"
            message += f"\nOverall Compliance Score: {overall_compliance_score:.2f}"
            message += f"\nTask-level Compliance Score: {task_compliance_score:.2f}"
            message += f"\nSection-level Compliance Score: {section_compliance_score:.2f}"
            message += f"\n\nSummary: {summary}"
            
            if gaps:
                message += f"\n\nGaps ({len(gaps)}):"
                for i, gap in enumerate(gaps[:5], 1):  # Show only the first 5 gaps
                    message += f"\n{i}. {gap}"
                if len(gaps) > 5:
                    message += f"\n... and {len(gaps) - 5} more gaps"
            else:
                message += "\n\nNo gaps identified."
            
            if improvements:
                message += f"\n\nRecommended Improvements ({len(improvements)}):"
                for i, improvement in enumerate(improvements[:5], 1):  # Show only the first 5 improvements
                    message += f"\n{i}. {improvement}"
                if len(improvements) > 5:
                    message += f"\n... and {len(improvements) - 5} more improvements"
            else:
                message += "\n\nNo improvements recommended."
            
            if task_analyses:
                message += f"\n\nTask-specific Analysis (showing {min(3, len(task_analyses))} of {len(task_analyses)} tasks):"
                for i, task_analysis in enumerate(task_analyses[:3], 1):  # Show only the first 3 task analyses
                    task_id = task_analysis["task_id"]
                    task_name = task_analysis["task_name"]
                    task_compliance_score = task_analysis["compliance_score"]
                    task_gaps = task_analysis["gaps"]
                    task_improvements = task_analysis["improvements"]
                    
                    message += f"\n\nTask {i}: {task_name} (ID: {task_id})"
                    message += f"\nCompliance Score: {task_compliance_score:.2f}"
                    
                    if task_gaps:
                        message += f"\nGaps ({len(task_gaps)}):"
                        for j, gap in enumerate(task_gaps[:2], 1):  # Show only the first 2 gaps
                            message += f"\n  {j}. {gap}"
                        if len(task_gaps) > 2:
                            message += f"\n  ... and {len(task_gaps) - 2} more gaps"
                    
                    if task_improvements:
                        message += f"\nImprovements ({len(task_improvements)}):"
                        for j, improvement in enumerate(task_improvements[:2], 1):  # Show only the first 2 improvements
                            message += f"\n  {j}. {improvement}"
                        if len(task_improvements) > 2:
                            message += f"\n  ... and {len(task_improvements) - 2} more improvements"
        
        message += "\n\nThe complete analysis details are available in the structured data."
        
        return {
            "content": message,
            "role": "assistant"
        }

tasks_analysis_agent = TasksAnalysisAgent()
