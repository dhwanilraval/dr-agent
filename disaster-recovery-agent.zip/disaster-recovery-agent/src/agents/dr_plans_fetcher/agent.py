"""
DR Plans Fetcher Agent for the Disaster Recovery Compliance Agent System.

This agent is responsible for fetching disaster recovery plans from a Postgres database table.
"""

import logging
import os
import json
from typing import List, Dict, Any, Optional

from autogen import AssistantAgent

from src.mock_apis.postgres.api import mock_postgres_api
from src.models.data_models import DisasterRecoveryPlan
from src.config.config import AGENT_CONFIG, LLM_CONFIG

logger = logging.getLogger(__name__)

class DRPlansFetcherAgent:
    """
    Agent responsible for fetching disaster recovery plans from a Postgres database.
    
    This agent uses the Postgres API to fetch disaster recovery plans for a list of
    application codes and passes the results to the next agent in the workflow.
    """
    
    def __init__(self):
        """Initialize the DR Plans Fetcher Agent."""
        self.config = AGENT_CONFIG["dr_plans_fetcher_agent"]
        self.postgres_api = mock_postgres_api
        
        try:
            self.agent = AssistantAgent(
                name=self.config["name"],
                system_message=self._create_system_message(),
                llm_config=LLM_CONFIG
            )
        except Exception as e:
            logger.warning(f"Failed to initialize AssistantAgent: {str(e)}")
            self.agent = type('MockAgent', (), {
                'name': self.config["name"],
                'system_message': self._create_system_message(),
                'generate_reply': lambda message: {
                    "content": f"Mock reply from {self.config['name']}",
                    "role": "assistant"
                }
            })()
        
        logger.info(f"Initialized {self.config['name']}")
    
    def _create_system_message(self) -> str:
        """
        Create the system message for the agent.
        
        Returns:
            The system message string.
        """
        return f"""
        You are the {self.config['name']}, responsible for fetching disaster recovery plans
        from a Postgres database table.
        
        {self.config['description']}
        
        You have access to the Postgres API to fetch disaster recovery plans for a list of
        application codes.
        
        When given a list of application codes, you should:
        1. Fetch disaster recovery plans for each application code
        2. Compile a complete list of all plans and their details
        3. Format the results in a structured way for the next agent
        
        Your output should include:
        - The application codes for which plans were fetched
        - All disaster recovery plans and their details
        - The recovery tasks for each plan
        - The devices for each plan
        """
    
    def fetch_plans(self, app_codes: List[str]) -> Dict[str, Any]:
        """
        Fetch disaster recovery plans for a list of application codes.
        
        Args:
            app_codes: The list of application codes to fetch plans for.
            
        Returns:
            A dictionary containing the plans and related information.
        """
        try:
            logger.info(f"Fetching plans for app codes: {app_codes}")
            
            plans = self.postgres_api.get_plans_for_app_codes(app_codes)
            
            serialized_plans = []
            for plan in plans:
                serialized_plan = plan.model_dump()
                serialized_plan["created_at"] = plan.created_at.isoformat()
                serialized_plan["updated_at"] = plan.updated_at.isoformat()
                serialized_plans.append(serialized_plan)
            
            result = {
                "app_codes": app_codes,
                "plans": serialized_plans,
                "plan_count": len(serialized_plans)
            }
            
            logger.info(f"Fetched {len(serialized_plans)} plans for {len(app_codes)} app codes")
            
            return result
        
        except Exception as e:
            logger.exception(f"Error fetching plans for app codes: {app_codes}")
            raise
    
    def process_message(self, message: Dict[str, Any]) -> Dict[str, Any]:
        """
        Process a message from another agent.
        
        Args:
            message: The message to process.
            
        Returns:
            A dictionary containing the response.
        """
        try:
            app_codes = []
            
            if "app_codes" in message:
                app_codes = message["app_codes"]
            
            elif "dependencies_data" in message and "data" in message["dependencies_data"]:
                data = message["dependencies_data"]["data"]
                if "all_app_codes" in data:
                    app_codes = data["all_app_codes"]
            
            if not app_codes:
                return {
                    "status": "error",
                    "message": "No application codes provided"
                }
            
            plans_result = self.fetch_plans(app_codes)
            
            response = {
                "status": "success",
                "message": f"Fetched {plans_result['plan_count']} plans for {len(app_codes)} application codes",
                "data": plans_result
            }
            
            return response
        
        except Exception as e:
            logger.exception(f"Error processing message: {message}")
            
            return {
                "status": "error",
                "message": f"Error processing message: {str(e)}"
            }
    
    def generate_reply(self, message: Dict[str, Any]) -> Dict[str, Any]:
        """
        Generate a reply to a message using the AG2 agent.
        
        Args:
            message: The message to reply to.
            
        Returns:
            A dictionary containing the reply.
        """
        plans_result = self.process_message(message)
        
        formatted_message = self._format_message_for_agent(plans_result)
        
        reply = self.agent.generate_reply(formatted_message)
        
        if isinstance(reply, dict):
            reply["plans_data"] = plans_result
        else:
            reply = {
                "content": reply,
                "plans_data": plans_result
            }
        
        return reply
    
    def _format_message_for_agent(self, plans_result: Dict[str, Any]) -> Dict[str, Any]:
        """
        Format a plans result as a message for the AG2 agent.
        
        Args:
            plans_result: The plans result to format.
            
        Returns:
            A dictionary containing the formatted message.
        """
        if plans_result["status"] == "error":
            return {
                "content": f"Error: {plans_result['message']}"
            }
        
        data = plans_result["data"]
        app_codes = data["app_codes"]
        plans = data["plans"]
        plan_count = data["plan_count"]
        
        message = f"""
        I have fetched disaster recovery plans for the following application codes:
        {', '.join(app_codes)}
        
        I found a total of {plan_count} plans.
        
        Here is a summary of the plans:
        """
        
        for plan in plans:
            app_code = plan["app_code"]
            name = plan["name"]
            description = plan["description"]
            version = plan["version"]
            rto = plan["recovery_time_objective"]
            rpo = plan["recovery_point_objective"]
            task_count = len(plan["tasks"])
            device_count = len(plan["devices"])
            
            message += f"\n- Plan for {app_code}: {name} (v{version})"
            message += f"\n  RTO: {rto} minutes, RPO: {rpo} minutes"
            message += f"\n  {task_count} recovery tasks, {device_count} devices"
            message += f"\n  Description: {description[:100]}..."
        
        message += "\n\nThe complete plan details are available in the structured data."
        
        return {
            "content": message,
            "role": "assistant"
        }

dr_plans_fetcher_agent = DRPlansFetcherAgent()
