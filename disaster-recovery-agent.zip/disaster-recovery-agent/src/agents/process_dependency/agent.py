"""
Process Dependency Agent for the Disaster Recovery Compliance Agent System.

This agent is responsible for finding underlying dependencies and application codes
that the submitted app codes rely on using the FlowIQ API.
"""

import logging
import os
from typing import List, Dict, Any, Optional

from autogen import AssistantAgent

from src.mock_apis.flowiq.api import mock_flowiq_api
from src.models.data_models import AppCode, Dependency
from src.config.config import AGENT_CONFIG, LLM_CONFIG

logger = logging.getLogger(__name__)

class ProcessDependencyAgent:
    """
    Agent responsible for finding dependencies between application codes.
    
    This agent uses the FlowIQ API to find dependencies between application codes
    and passes the results to the next agent in the workflow.
    """
    
    def __init__(self):
        """Initialize the Process Dependency Agent."""
        self.config = AGENT_CONFIG["process_dependency_agent"]
        self.flowiq_api = mock_flowiq_api
        
        # Create the AG2 agent with proper configuration
        try:
            self.agent = AssistantAgent(
                name=self.config["name"],
                system_message=self._create_system_message(),
                llm_config=LLM_CONFIG
            )
        except Exception as e:
            logger.warning(f"Failed to initialize AssistantAgent: {str(e)}")
            self.agent = type('MockAgent', (), {
                'name': self.config["name"],
                'system_message': self._create_system_message(),
                'generate_reply': lambda message: {
                    "content": f"Mock reply from {self.config['name']}",
                    "role": "assistant"
                }
            })()
        
        logger.info(f"Initialized {self.config['name']}")
    
    def _create_system_message(self) -> str:
        """
        Create the system message for the agent.
        
        Returns:
            The system message string.
        """
        return f"""
        You are the {self.config['name']}, responsible for finding underlying dependencies and application codes
        that the submitted app codes rely on.
        
        {self.config['description']}
        
        You have access to the FlowIQ API to find dependencies between application codes.
        
        When given a list of application codes, you should:
        1. Find all dependencies for each application code
        2. Recursively find dependencies of dependencies
        3. Compile a complete list of all application codes and their dependencies
        4. Format the results in a structured way for the next agent
        
        Your output should include:
        - The original application codes
        - All dependent application codes discovered
        - The dependency relationships between application codes
        """
    
    def find_dependencies(self, app_codes: List[str]) -> Dict[str, Any]:
        """
        Find dependencies for a list of application codes.
        
        Args:
            app_codes: The list of application codes to find dependencies for.
            
        Returns:
            A dictionary containing the dependencies and related information.
        """
        try:
            logger.info(f"Finding dependencies for app codes: {app_codes}")
            
            dependencies = self.flowiq_api.get_all_dependencies(app_codes, recursive=True)
            
            all_app_codes = set(app_codes)
            for dependency in dependencies:
                all_app_codes.add(dependency.source_app_code)
                all_app_codes.add(dependency.target_app_code)
            
            app_code_details = {}
            for code in all_app_codes:
                app_code = self.flowiq_api.get_app_code(code)
                if app_code:
                    app_code_details[code] = app_code.model_dump()
            
            result = {
                "original_app_codes": app_codes,
                "all_app_codes": list(all_app_codes),
                "dependencies": [dependency.model_dump() for dependency in dependencies],
                "app_code_details": app_code_details
            }
            
            logger.info(f"Found {len(dependencies)} dependencies for {len(app_codes)} app codes")
            
            return result
        
        except Exception as e:
            logger.exception(f"Error finding dependencies for app codes: {app_codes}")
            raise
    
    def process_message(self, message: Dict[str, Any]) -> Dict[str, Any]:
        """
        Process a message from another agent.
        
        Args:
            message: The message to process.
            
        Returns:
            A dictionary containing the response.
        """
        try:
            app_codes = message.get("app_codes", [])
            
            if not app_codes:
                return {
                    "status": "error",
                    "message": "No application codes provided"
                }
            
            dependencies_result = self.find_dependencies(app_codes)
            
            response = {
                "status": "success",
                "message": f"Found dependencies for {len(app_codes)} application codes",
                "data": dependencies_result
            }
            
            return response
        
        except Exception as e:
            logger.exception(f"Error processing message: {message}")
            
            return {
                "status": "error",
                "message": f"Error processing message: {str(e)}"
            }
    
    def generate_reply(self, message: Dict[str, Any]) -> Dict[str, Any]:
        """
        Generate a reply to a message using the AG2 agent.
        
        Args:
            message: The message to reply to.
            
        Returns:
            A dictionary containing the reply.
        """
        dependencies_result = self.process_message(message)
        
        formatted_message = self._format_message_for_agent(dependencies_result)
        
        reply = self.agent.generate_reply(formatted_message)
        
        if isinstance(reply, dict):
            reply["dependencies_data"] = dependencies_result
        else:
            reply = {
                "content": reply,
                "dependencies_data": dependencies_result
            }
        
        return reply
    
    def _format_message_for_agent(self, dependencies_result: Dict[str, Any]) -> Dict[str, Any]:
        """
        Format a dependencies result as a message for the AG2 agent.
        
        Args:
            dependencies_result: The dependencies result to format.
            
        Returns:
            A dictionary containing the formatted message.
        """
        if dependencies_result["status"] == "error":
            return {
                "content": f"Error: {dependencies_result['message']}"
            }
        
        data = dependencies_result["data"]
        original_app_codes = data["original_app_codes"]
        all_app_codes = data["all_app_codes"]
        dependencies = data["dependencies"]
        app_code_details = data["app_code_details"]
        
        message = f"""
        I have analyzed the dependencies for the following application codes:
        {', '.join(original_app_codes)}
        
        I found a total of {len(dependencies)} dependencies involving {len(all_app_codes)} application codes.
        
        Here is a summary of the dependencies:
        """
        
        for dependency in dependencies:
            source = dependency["source_app_code"]
            target = dependency["target_app_code"]
            dep_type = dependency["dependency_type"]
            description = dependency.get("description", "No description")
            
            source_name = app_code_details.get(source, {}).get("name", source)
            target_name = app_code_details.get(target, {}).get("name", target)
            
            message += f"\n- {source} ({source_name}) depends on {target} ({target_name}) via {dep_type}: {description}"
        
        message += "\n\nApplication Code Details:"
        for code, details in app_code_details.items():
            name = details.get("name", "No name")
            description = details.get("description", "No description")
            
            message += f"\n- {code}: {name} - {description}"
        
        return {
            "content": message,
            "role": "assistant"
        }

process_dependency_agent = ProcessDependencyAgent()
