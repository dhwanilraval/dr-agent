"""
Process Dependency Agent package.

This package provides the Process Dependency Agent for the Disaster Recovery Compliance Agent System.
"""

from src.agents.process_dependency.agent import ProcessDependencyAgent, process_dependency_agent

__all__ = ["ProcessDependencyAgent", "process_dependency_agent"]
