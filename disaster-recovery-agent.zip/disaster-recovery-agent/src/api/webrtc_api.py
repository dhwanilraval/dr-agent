"""
WebRTC API module for the Disaster Recovery Compliance Agent System.

This module defines the WebRTC API endpoints for real-time communication
with users during disaster recovery analysis.
"""

import logging
from typing import Dict, Any, Optional

from fastapi import APIRouter, HTTPException, WebSocket, WebSocketDisconnect, Depends
from pydantic import BaseModel

from src.utils.webrtc_utils import webrtc_manager
from src.utils.logging_utils import setup_elasticsearch_logging

logger = logging.getLogger(__name__)

class WebRTCConnectionRequest(BaseModel):
    """Request model for creating a WebRTC connection."""
    request_id: str

class WebRTCConnectionResponse(BaseModel):
    """Response model for a WebRTC connection."""
    connection_id: str
    status: str
    ice_servers: Optional[list] = None

def create_webrtc_router():
    """
    Create and configure the WebRTC API router.
    
    Returns:
        The configured FastAPI router.
    """
    router = APIRouter(prefix="/api/webrtc", tags=["webrtc"])
    
    @router.post("/connection", response_model=WebRTCConnectionResponse)
    async def create_connection(request: WebRTCConnectionRequest):
        """
        Create a new WebRTC connection.
        
        Args:
            request: The WebRTCConnectionRequest containing the request ID.
            
        Returns:
            A WebRTCConnectionResponse with the connection details.
        """
        try:
            connection = webrtc_manager.create_connection(request.request_id)
            
            if connection["status"] == "disabled":
                raise HTTPException(status_code=503, detail="WebRTC is disabled")
            
            return WebRTCConnectionResponse(
                connection_id=connection["id"],
                status=connection["status"],
                ice_servers=connection["ice_servers"]
            )
        
        except Exception as e:
            logger.exception("Error creating WebRTC connection")
            raise HTTPException(status_code=500, detail=str(e))
    
    @router.websocket("/ws/{connection_id}")
    async def websocket_endpoint(websocket: WebSocket, connection_id: str):
        """
        WebSocket endpoint for WebRTC signaling.
        
        Args:
            websocket: The WebSocket connection.
            connection_id: The ID of the WebRTC connection.
        """
        try:
            await websocket.accept()
            
            if connection_id not in webrtc_manager.connections:
                await websocket.close(code=4004, reason="Connection not found")
                return
            
            async def send_update(data):
                await websocket.send_json(data)
            
            webrtc_manager.register_update_handler(connection_id, send_update)
            
            while True:
                data = await websocket.receive_json()
                
                if "type" in data:
                    if data["type"] == "ice-candidate":
                        logger.debug(f"Received ICE candidate for connection {connection_id}")
                    
                    elif data["type"] == "offer":
                        logger.debug(f"Received SDP offer for connection {connection_id}")
                    
                    elif data["type"] == "answer":
                        logger.debug(f"Received SDP answer for connection {connection_id}")
                    
                    elif data["type"] == "close":
                        logger.info(f"Received close request for connection {connection_id}")
                        webrtc_manager.close_connection(connection_id)
                        await websocket.close()
                        break
                
                await websocket.send_json({"type": "ack", "id": data.get("id")})
        
        except WebSocketDisconnect:
            logger.info(f"WebSocket disconnected for connection {connection_id}")
        
        except Exception as e:
            logger.exception(f"Error in WebSocket endpoint for connection {connection_id}")
            try:
                await websocket.close(code=1011, reason=str(e))
            except:
                pass
    
    @router.post("/send/{connection_id}")
    async def send_update(connection_id: str, data: Dict[str, Any]):
        """
        Send an update to a WebRTC connection.
        
        Args:
            connection_id: The ID of the connection to send the update to.
            data: The data to send.
            
        Returns:
            A dictionary indicating whether the update was sent successfully.
        """
        try:
            success = webrtc_manager.send_update(connection_id, data)
            
            if not success:
                raise HTTPException(status_code=404, detail="Connection not found or WebRTC disabled")
            
            return {"success": True}
        
        except Exception as e:
            logger.exception("Error sending WebRTC update")
            raise HTTPException(status_code=500, detail=str(e))
    
    @router.delete("/connection/{connection_id}")
    async def close_connection(connection_id: str):
        """
        Close a WebRTC connection.
        
        Args:
            connection_id: The ID of the connection to close.
            
        Returns:
            A dictionary indicating whether the connection was closed successfully.
        """
        try:
            success = webrtc_manager.close_connection(connection_id)
            
            if not success:
                raise HTTPException(status_code=404, detail="Connection not found or WebRTC disabled")
            
            return {"success": True}
        
        except Exception as e:
            logger.exception("Error closing WebRTC connection")
            raise HTTPException(status_code=500, detail=str(e))
    
    return router
