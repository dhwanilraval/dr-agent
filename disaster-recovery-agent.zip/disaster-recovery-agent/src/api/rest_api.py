"""
REST API module for the Disaster Recovery Compliance Agent System.

This module defines the REST API entrypoint for the system, which accepts
business process and application codes as input and initiates the agentic workflow.
"""

import logging
from typing import List, Dict, Any, Optional

from fastapi import FastAPI, HTTPException, Depends, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from src.config.config import API_CONFIG
from src.utils.logging_utils import log_agent_interaction

logger = logging.getLogger(__name__)

class BusinessProcessRequest(BaseModel):
    """Request model for business process analysis."""
    business_process: str
    app_codes: List[str]

class BusinessProcessResponse(BaseModel):
    """Response model for business process analysis."""
    request_id: str
    status: str
    results: Optional[Dict[str, Any]] = None

ongoing_analyses = {}

def create_api_app(disaster_recovery_system):
    """
    Create and configure the FastAPI application.
    
    Args:
        disaster_recovery_system: The DisasterRecoveryAgentSystem instance.
        
    Returns:
        The configured FastAPI application.
    """
    app = FastAPI(
        title="Disaster Recovery Compliance Agent API",
        description="API for analyzing disaster recovery compliance of business processes and applications.",
        version="1.0.0",
    )
    
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )
    
    from src.api.webrtc_api import create_webrtc_router
    webrtc_router = create_webrtc_router()
    app.include_router(webrtc_router)
    
    @app.get("/health")
    async def health_check():
        """Health check endpoint."""
        return {"status": "healthy"}
    
    @app.post("/api/analyze", response_model=BusinessProcessResponse)
    async def analyze_business_process(
        request: BusinessProcessRequest,
        background_tasks: BackgroundTasks
    ):
        """
        Analyze a business process and its application codes for disaster recovery compliance.
        
        Args:
            request: The BusinessProcessRequest containing the business process and app codes.
            background_tasks: FastAPI BackgroundTasks for running the analysis asynchronously.
            
        Returns:
            A BusinessProcessResponse with the request ID and status.
        """
        try:
            import uuid
            request_id = str(uuid.uuid4())
            
            ongoing_analyses[request_id] = {
                "status": "processing",
                "request": request.dict(),
                "results": None
            }
            
            background_tasks.add_task(
                run_analysis,
                disaster_recovery_system,
                request_id,
                request.business_process,
                request.app_codes
            )
            
            return BusinessProcessResponse(
                request_id=request_id,
                status="processing"
            )
        
        except Exception as e:
            logger.exception("Error processing analysis request")
            raise HTTPException(status_code=500, detail=str(e))
    
    @app.get("/api/analyze/{request_id}", response_model=BusinessProcessResponse)
    async def get_analysis_results(request_id: str):
        """
        Get the results of a business process analysis.
        
        Args:
            request_id: The ID of the analysis request.
            
        Returns:
            A BusinessProcessResponse with the status and results (if available).
        """
        if request_id not in ongoing_analyses:
            raise HTTPException(status_code=404, detail="Analysis request not found")
        
        analysis = ongoing_analyses[request_id]
        
        return BusinessProcessResponse(
            request_id=request_id,
            status=analysis["status"],
            results=analysis["results"]
        )
    
    @app.get("/api/analyze")
    async def list_analyses():
        """
        List all ongoing and completed analyses.
        
        Returns:
            A dictionary of analysis request IDs and their statuses.
        """
        return {
            request_id: {
                "status": analysis["status"],
                "business_process": analysis["request"]["business_process"],
                "app_codes": analysis["request"]["app_codes"]
            }
            for request_id, analysis in ongoing_analyses.items()
        }
    
    return app

async def run_analysis(
    disaster_recovery_system,
    request_id: str,
    business_process: str,
    app_codes: List[str]
):
    """
    Run the business process analysis in the background.
    
    Args:
        disaster_recovery_system: The DisasterRecoveryAgentSystem instance.
        request_id: The ID of the analysis request.
        business_process: The name or identifier of the business process.
        app_codes: A list of application codes associated with the business process.
    """
    try:
        from src.utils.webrtc_utils import webrtc_manager
        
        ongoing_analyses[request_id]["status"] = "processing"
        
        webrtc_manager.send_update(request_id, {
            "type": "status_update",
            "status": "processing",
            "message": f"Starting analysis for business process: {business_process} with app codes: {', '.join(app_codes)}"
        })
        
        log_agent_interaction(
            agent_name="api",
            message=f"API request received for business process: {business_process}",
            request_id=request_id,
            workflow_step="api_request",
            agent_data={
                "business_process": business_process,
                "app_codes": app_codes
            }
        )
        
        results = disaster_recovery_system.analyze_business_process(
            business_process=business_process,
            app_codes=app_codes,
            request_id=request_id
        )
        
        ongoing_analyses[request_id]["status"] = "completed"
        ongoing_analyses[request_id]["results"] = results
        
        webrtc_manager.send_update(request_id, {
            "type": "status_update",
            "status": "completed",
            "message": "Analysis completed successfully",
            "results": {
                "overall_quality": results.get("overall_quality"),
                "dr_readiness_score": results.get("dr_readiness_score"),
                "risk_level": results.get("risk_level"),
                "risks_count": len(results.get("risks", [])),
                "recommendations_count": len(results.get("recommendations", []))
            }
        })
        
        log_agent_interaction(
            agent_name="api",
            message=f"API response sent for request {request_id}",
            request_id=request_id,
            workflow_step="api_response",
            agent_data={
                "overall_quality": results.get("overall_quality"),
                "dr_readiness_score": results.get("dr_readiness_score"),
                "risk_level": results.get("risk_level"),
                "risks_count": len(results.get("risks", [])),
                "recommendations_count": len(results.get("recommendations", []))
            }
        )
        
        logger.info(f"Analysis completed for request {request_id}")
    
    except Exception as e:
        ongoing_analyses[request_id]["status"] = "failed"
        ongoing_analyses[request_id]["error"] = str(e)
        
        webrtc_manager.send_update(request_id, {
            "type": "status_update",
            "status": "failed",
            "message": f"Analysis failed: {str(e)}"
        })
        
        logger.exception(f"Analysis failed for request {request_id}")
