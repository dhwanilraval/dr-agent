"""
Architecture module for the Disaster Recovery Compliance Agent System.

This module defines the overall architecture of the system, including:
- Agent creation and configuration
- GroupChat orchestration
- Data flow between agents
- REST API entrypoint
- Elasticsearch logging
- Real-time response capabilities
"""

import logging
from typing import Dict, List, Any, Optional

import autogen
from autogen import Agent, UserProxyAgent, AssistantAgent, GroupChat, GroupChatManager

from src.config.config import AGENT_CONFIG, LLM_CONFIG
from src.utils.logging_utils import setup_elasticsearch_logging, log_agent_interaction
from src.api.rest_api import create_api_app

logger = logging.getLogger(__name__)

class DisasterRecoveryAgentSystem:
    """
    Main class for the Disaster Recovery Compliance Agent System.
    
    This class is responsible for creating and orchestrating the agents,
    setting up the REST API entrypoint, and managing the overall workflow.
    """
    
    def __init__(self):
        """Initialize the Disaster Recovery Agent System."""
        self.agents = {}
        self.group_chat = None
        self.group_chat_manager = None
        self.api_app = None
        
        setup_elasticsearch_logging()
        
        self._create_agents()
        
        self._setup_group_chat()
        
        self.api_app = create_api_app(self)
    
    def _create_agents(self):
        """Create all the specialized agents for the system."""
        self.agents["process_dependency_agent"] = AssistantAgent(
            name=AGENT_CONFIG["process_dependency_agent"]["name"],
            system_message=AGENT_CONFIG["process_dependency_agent"]["description"],
            llm_config=LLM_CONFIG
        )
        
        self.agents["dr_plans_fetcher_agent"] = AssistantAgent(
            name=AGENT_CONFIG["dr_plans_fetcher_agent"]["name"],
            system_message=AGENT_CONFIG["dr_plans_fetcher_agent"]["description"],
            llm_config=LLM_CONFIG
        )
        
        self.agents["description_analysis_agent"] = AssistantAgent(
            name=AGENT_CONFIG["description_analysis_agent"]["name"],
            system_message=AGENT_CONFIG["description_analysis_agent"]["description"],
            llm_config=LLM_CONFIG
        )
        
        self.agents["tasks_analysis_agent"] = AssistantAgent(
            name=AGENT_CONFIG["tasks_analysis_agent"]["name"],
            system_message=AGENT_CONFIG["tasks_analysis_agent"]["description"],
            llm_config=LLM_CONFIG
        )
        
        self.agents["device_reconciliation_agent"] = AssistantAgent(
            name=AGENT_CONFIG["device_reconciliation_agent"]["name"],
            system_message=AGENT_CONFIG["device_reconciliation_agent"]["description"],
            llm_config=LLM_CONFIG
        )
        
        self.agents["iipm_analysis_agent"] = AssistantAgent(
            name=AGENT_CONFIG["iipm_analysis_agent"]["name"],
            system_message=AGENT_CONFIG["iipm_analysis_agent"]["description"],
            llm_config=LLM_CONFIG
        )
        
        self.agents["reasoning_agent"] = AssistantAgent(
            name=AGENT_CONFIG["reasoning_agent"]["name"],
            system_message=AGENT_CONFIG["reasoning_agent"]["description"],
            llm_config=LLM_CONFIG
        )
        
        self.agents["user_proxy"] = UserProxyAgent(
            name="User Proxy",
            human_input_mode="NEVER",
            max_consecutive_auto_reply=0
        )
    
    def _setup_group_chat(self):
        """Setup the GroupChat for agent orchestration."""
        agent_list = [
            self.agents["user_proxy"],
            self.agents["process_dependency_agent"],
            self.agents["dr_plans_fetcher_agent"],
            self.agents["description_analysis_agent"],
            self.agents["tasks_analysis_agent"],
            self.agents["device_reconciliation_agent"],
            self.agents["iipm_analysis_agent"],
            self.agents["reasoning_agent"]
        ]
        
        self.group_chat = GroupChat(
            agents=agent_list,
            messages=[],
            max_round=50
        )
        
        self.group_chat_manager = GroupChatManager(
            groupchat=self.group_chat,
            llm_config=LLM_CONFIG
        )
    
    def analyze_business_process(self, business_process: str, app_codes: List[str], request_id: Optional[str] = None) -> Dict[str, Any]:
        """
        Analyze a business process and its application codes for disaster recovery compliance.
        
        Args:
            business_process: The name or identifier of the business process.
            app_codes: A list of application codes associated with the business process.
            request_id: Optional request ID for correlation in logs.
            
        Returns:
            A dictionary containing the analysis results.
        """
        logger.info(f"Starting analysis for business process: {business_process} with app codes: {app_codes}")
        
        if request_id is None:
            import uuid
            request_id = str(uuid.uuid4())
        
        log_agent_interaction(
            agent_name="system",
            message=f"Starting analysis for business process: {business_process}",
            request_id=request_id,
            workflow_step="start_analysis",
            agent_data={
                "business_process": business_process,
                "app_codes": app_codes
            }
        )
        
        initial_message = f"""
        Please analyze the disaster recovery compliance for the following business process and application codes:
        
        Business Process: {business_process}
        Application Codes: {', '.join(app_codes)}
        
        Follow these steps:
        1. Process Dependency Agent: Find all dependencies for the provided app codes.
        2. DR Plans Fetcher Agent: Fetch all relevant disaster recovery plans.
        3. Description Analysis Agent: Analyze each plan's description against standard plans.
        4. Tasks Analysis Agent: Analyze each plan's recovery tasks against standard plans.
        5. Device Reconciliation Agent: Match devices in the plan with actual devices.
        6. IIPM Analysis Agent: Fetch details for all supporting and dependent app codes.
        7. DR Plan Analysis Reasoning Agent: Provide a comprehensive analysis of disaster recovery readiness.
        """
        
        log_agent_interaction(
            agent_name="user_proxy",
            message="Sending initial message to group chat",
            request_id=request_id,
            workflow_step="initial_message",
            agent_message={"content": initial_message}
        )
        
        def on_message(message, sender, receiver):
            log_agent_interaction(
                agent_name=sender.name if hasattr(sender, "name") else str(sender),
                message=f"Message from {sender} to {receiver}",
                request_id=request_id,
                workflow_step="agent_interaction",
                agent_message={"content": message}
            )
            return False  # Continue processing the message
        
        for agent_name, agent in self.agents.items():
            if hasattr(agent, "register_reply_hook"):
                agent.register_reply_hook(on_message)
        
        chat_result = self.group_chat_manager.run(
            message=initial_message,
            sender=self.agents["user_proxy"]
        )
        
        log_agent_interaction(
            agent_name="system",
            message="Group chat completed",
            request_id=request_id,
            workflow_step="group_chat_completed",
            agent_data={"chat_result": str(chat_result)[:1000]}  # Truncate if too long
        )
        
        return self._process_chat_results(chat_result)
    
    def _process_chat_results(self, chat_result: Any, request_id: Optional[str] = None) -> Dict[str, Any]:
        """
        Process the results from the GroupChat.
        
        Args:
            chat_result: The raw results from the GroupChat.
            request_id: Optional request ID for correlation in logs.
            
        Returns:
            A structured dictionary containing the processed results.
        """
        log_agent_interaction(
            agent_name="system",
            message="Processing chat results",
            request_id=request_id,
            workflow_step="process_chat_results"
        )
        
        final_message = None
        reasoning_data = None
        
        for idx, message in enumerate(self.group_chat.messages):
            sender = message.get("sender", "unknown")
            content = message.get("content", "")
            
            log_agent_interaction(
                agent_name=sender,
                message=f"Message {idx+1} in group chat",
                request_id=request_id,
                workflow_step="group_chat_message",
                agent_message={"content": content[:1000]}  # Truncate if too long
            )
        
        for message in reversed(self.group_chat.messages):
            if message.get("sender") == self.agents["reasoning_agent"].name:
                final_message = message.get("content")
                if hasattr(message, "reasoning_data"):
                    reasoning_data = message.reasoning_data
                elif isinstance(message, dict) and "reasoning_data" in message:
                    reasoning_data = message["reasoning_data"]
                break
        
        if reasoning_data and reasoning_data.get("status") == "success" and "data" in reasoning_data:
            data = reasoning_data["data"]
            dr_readiness_score = data.get("dr_readiness_score", {})
            risk_assessment = data.get("risk_assessment", {})
            rto_rpo_analysis = data.get("rto_rpo_analysis", {})
            findings_recommendations = data.get("findings_recommendations", {})
            
            overall_score = dr_readiness_score.get("overall_score", 0)
            if overall_score >= 80:
                overall_quality = "High"
            elif overall_score >= 60:
                overall_quality = "Medium"
            else:
                overall_quality = "Low"
            
            risks = []
            for risk in risk_assessment.get("risks", []):
                risks.append(f"[{risk.get('level', 'Unknown')}] {risk.get('category', 'Unknown')}: {risk.get('description', 'Unknown')}")
            
            rto_rpo_result = {
                "expected": {
                    "rto": None,
                    "rpo": None
                },
                "actual": {
                    "rto": None,
                    "rpo": None
                },
                "met": False
            }
            
            primary_apps = rto_rpo_analysis.get("primary_apps", {})
            if primary_apps:
                min_rto = min([app.get("rto", float("inf")) for app in primary_apps.values() if app.get("rto") is not None], default=None)
                min_rpo = min([app.get("rpo", float("inf")) for app in primary_apps.values() if app.get("rpo") is not None], default=None)
                
                if min_rto is not None:
                    rto_rpo_result["expected"]["rto"] = f"{min_rto} minutes"
                
                if min_rpo is not None:
                    rto_rpo_result["expected"]["rpo"] = f"{min_rpo} minutes"
            
            if rto_rpo_analysis.get("overall_achievable_rto") is not None:
                rto_rpo_result["actual"]["rto"] = f"{rto_rpo_analysis['overall_achievable_rto']} minutes"
            
            if rto_rpo_analysis.get("overall_achievable_rpo") is not None:
                rto_rpo_result["actual"]["rpo"] = f"{rto_rpo_analysis['overall_achievable_rpo']} minutes"
            
            if (rto_rpo_analysis.get("overall_achievable_rto") is not None and 
                rto_rpo_analysis.get("overall_achievable_rto") <= min_rto and
                rto_rpo_analysis.get("overall_achievable_rpo") is not None and
                rto_rpo_analysis.get("overall_achievable_rpo") <= min_rpo):
                rto_rpo_result["met"] = True
            
            recommendations = []
            for recommendation in findings_recommendations.get("recommendations", []):
                recommendations.append(f"[{recommendation.get('priority', 'Unknown')}] {recommendation.get('category', 'Unknown')}: {recommendation.get('description', 'Unknown')}")
            
            structured_results = {
                "overall_quality": overall_quality,
                "dr_readiness_score": overall_score,
                "risk_level": risk_assessment.get("overall_risk", "Unknown"),
                "risks": risks,
                "rto_rpo_analysis": rto_rpo_result,
                "recommendations": recommendations,
                "detailed_analysis": final_message,
                "component_scores": {
                    "plan_descriptions": dr_readiness_score.get("description_score", 0),
                    "recovery_tasks": dr_readiness_score.get("tasks_score", 0),
                    "device_coverage": dr_readiness_score.get("device_score", 0),
                    "dr_testing": dr_readiness_score.get("testing_score", 0)
                }
            }
        else:
            structured_results = {
                "overall_quality": "Unknown",
                "dr_readiness_score": 0,
                "risk_level": "Unknown",
                "risks": ["Unable to determine risks due to missing reasoning data"],
                "rto_rpo_analysis": {
                    "expected": {"rto": None, "rpo": None},
                    "actual": {"rto": None, "rpo": None},
                    "met": False
                },
                "recommendations": ["Unable to determine recommendations due to missing reasoning data"],
                "detailed_analysis": final_message,
                "component_scores": {
                    "plan_descriptions": 0,
                    "recovery_tasks": 0,
                    "device_coverage": 0,
                    "dr_testing": 0
                }
            }
        
        log_agent_interaction(
            agent_name="system",
            message="Analysis completed",
            request_id=request_id,
            workflow_step="analysis_completed",
            agent_data={
                "overall_quality": structured_results.get("overall_quality"),
                "dr_readiness_score": structured_results.get("dr_readiness_score"),
                "risk_level": structured_results.get("risk_level"),
                "risks_count": len(structured_results.get("risks", [])),
                "recommendations_count": len(structured_results.get("recommendations", []))
            }
        )
        
        return structured_results

disaster_recovery_system = DisasterRecoveryAgentSystem()
