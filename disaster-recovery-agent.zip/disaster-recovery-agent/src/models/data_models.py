"""
Data models for the Disaster Recovery Compliance Agent System.

This module defines the data models used throughout the system.
"""

from typing import List, Dict, Any, Optional
from pydantic import BaseModel, Field
from datetime import datetime

class AppCode(BaseModel):
    """Model for an application code."""
    code: str
    name: Optional[str] = None
    description: Optional[str] = None

class Dependency(BaseModel):
    """Model for a dependency between application codes."""
    source_app_code: str
    target_app_code: str
    dependency_type: str
    description: Optional[str] = None

class Device(BaseModel):
    """Model for a device."""
    id: str
    name: str
    type: str
    description: Optional[str] = None
    app_code: Optional[str] = None

class RecoveryTask(BaseModel):
    """Model for a recovery task in a disaster recovery plan."""
    id: str
    name: str
    description: str
    sequence: int
    estimated_duration: int  # in minutes
    responsible_team: str
    dependencies: List[str] = []  # IDs of tasks that must be completed before this one

class DisasterRecoveryPlan(BaseModel):
    """Model for a disaster recovery plan."""
    id: str
    app_code: str
    name: str
    description: str
    version: str
    created_at: datetime
    updated_at: datetime
    recovery_time_objective: int  # in minutes
    recovery_point_objective: int  # in minutes
    tasks: List[RecoveryTask] = []
    devices: List[Device] = []

class StandardSection(BaseModel):
    """Model for a section in a standard disaster recovery plan."""
    id: str
    name: str
    description: str
    requirements: List[str] = []
    best_practices: List[str] = []

class StandardPlan(BaseModel):
    """Model for a standard disaster recovery plan."""
    id: str
    name: str
    type: str  # e.g., "description", "tasks"
    sections: List[StandardSection] = []

class AppCodeDetails(BaseModel):
    """Model for detailed information about an application code."""
    code: str
    name: str
    description: Optional[str] = None
    business_criticality: str
    recovery_time_objective: int  # in minutes
    recovery_point_objective: int  # in minutes
    owner: str
    support_team: str

class AnalysisResult(BaseModel):
    """Model for the result of a disaster recovery compliance analysis."""
    business_process: str
    app_codes: List[str]
    dependencies: List[Dependency] = []
    plans: List[DisasterRecoveryPlan] = []
    app_code_details: Dict[str, AppCodeDetails] = {}
    description_analysis: Dict[str, Any] = {}
    tasks_analysis: Dict[str, Any] = {}
    device_reconciliation: Dict[str, Any] = {}
    overall_quality: str
    risks: List[str] = []
    rto_rpo_analysis: Dict[str, Any] = {}
    recommendations: List[str] = []
    created_at: datetime = Field(default_factory=datetime.utcnow)
