"""
Logging utilities for the Disaster Recovery Compliance Agent System.

This module provides functions for setting up logging to Elasticsearch
for evidence and auditing purposes.
"""

import logging
import json
from datetime import datetime
from typing import Dict, Any, Optional

from src.config.config import ELASTICSEARCH_CONFIG

logger = logging.getLogger(__name__)

class ElasticsearchHandler(logging.Handler):
    """
    Custom logging handler that sends logs to Elasticsearch.
    
    This handler formats log records as JSON and sends them to Elasticsearch
    for evidence and auditing purposes.
    """
    
    def __init__(self):
        """Initialize the Elasticsearch handler."""
        super().__init__()
        self.es_config = ELASTICSEARCH_CONFIG
        
        self.es_client = MockElasticsearchClient(
            host=self.es_config["host"],
            port=self.es_config["port"],
            username=self.es_config["username"],
            password=self.es_config["password"]
        )
    
    def emit(self, record):
        """
        Emit a log record to Elasticsearch.
        
        Args:
            record: The log record to emit.
        """
        try:
            log_entry = self.format_log_entry(record)
            
            self.es_client.index(
                index=self.es_config["index"],
                document=log_entry
            )
        
        except Exception:
            self.handleError(record)
    
    def format_log_entry(self, record) -> Dict[str, Any]:
        """
        Format a log record as a JSON document for Elasticsearch.
        
        Args:
            record: The log record to format.
            
        Returns:
            A dictionary representing the formatted log entry.
        """
        if isinstance(record.msg, dict):
            message = record.msg
        else:
            message = record.getMessage()
        
        log_entry = {
            "timestamp": datetime.utcnow().isoformat(),
            "level": record.levelname,
            "logger": record.name,
            "message": message,
            "module": record.module,
            "function": record.funcName,
            "line": record.lineno,
            "process": record.process,
            "thread": record.thread
        }
        
        if hasattr(record, 'agent_data'):
            log_entry["agent_data"] = record.agent_data
        
        if hasattr(record, 'request_id'):
            log_entry["request_id"] = record.request_id
            
        if hasattr(record, 'workflow_step'):
            log_entry["workflow_step"] = record.workflow_step
            
        if hasattr(record, 'agent_message'):
            log_entry["agent_message"] = record.agent_message
        
        if record.exc_info:
            log_entry["exception"] = {
                "type": record.exc_info[0].__name__,
                "message": str(record.exc_info[1]),
                "traceback": logging.Formatter().formatException(record.exc_info)
            }
        
        return log_entry

class MockElasticsearchClient:
    """
    Mock Elasticsearch client for development and testing.
    
    This class provides a mock implementation of an Elasticsearch client
    that logs to the console instead of sending to an actual Elasticsearch instance.
    """
    
    def __init__(self, host: str, port: int, username: str, password: str):
        """
        Initialize the mock Elasticsearch client.
        
        Args:
            host: The Elasticsearch host.
            port: The Elasticsearch port.
            username: The Elasticsearch username.
            password: The Elasticsearch password.
        """
        self.host = host
        self.port = port
        self.username = username
        self.password = password
        
        logger.info(f"Initialized mock Elasticsearch client for {host}:{port}")
    
    def index(self, index: str, document: Dict[str, Any]) -> Dict[str, Any]:
        """
        Index a document in Elasticsearch.
        
        Args:
            index: The name of the index.
            document: The document to index.
            
        Returns:
            A dictionary representing the indexing response.
        """
        logger.debug(f"[MOCK ES] Indexing document to {index}: {json.dumps(document)}")
        
        return {
            "result": "created",
            "_index": index,
            "_id": "mock_id",
            "_version": 1
        }

def setup_elasticsearch_logging():
    """
    Setup logging to Elasticsearch for evidence and auditing purposes.
    """
    es_handler = ElasticsearchHandler()
    es_handler.setLevel(logging.INFO)
    
    root_logger = logging.getLogger()
    root_logger.addHandler(es_handler)
    
    logger.info("Elasticsearch logging setup complete")
    
def log_agent_interaction(agent_name: str, message: str, request_id: Optional[str] = None, 
                         workflow_step: Optional[str] = None, agent_data: Optional[Dict[str, Any]] = None,
                         agent_message: Optional[Dict[str, Any]] = None):
    """
    Log an agent interaction to Elasticsearch.
    
    Args:
        agent_name: The name of the agent.
        message: The log message.
        request_id: Optional request ID for correlation.
        workflow_step: Optional workflow step identifier.
        agent_data: Optional additional agent-specific data.
        agent_message: Optional agent message content.
    """
    agent_logger = logging.getLogger(f"agent.{agent_name}")
    
    record = agent_logger.makeRecord(
        name=agent_logger.name,
        level=logging.INFO,
        fn="",
        lno=0,
        msg=message,
        args=(),
        exc_info=None,
        extra={
            'agent_data': agent_data or {},
            'request_id': request_id,
            'workflow_step': workflow_step,
            'agent_message': agent_message or {}
        }
    )
    
    for handler in agent_logger.handlers + logging.getLogger().handlers:
        if handler.level <= record.levelno:
            handler.handle(record)
