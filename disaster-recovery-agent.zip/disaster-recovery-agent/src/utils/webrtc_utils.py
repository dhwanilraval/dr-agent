"""
WebRTC utilities for the Disaster Recovery Compliance Agent System.

This module provides functions for setting up real-time communication
using WebRTC for providing real-time responses to users.
"""

import logging
import json
from typing import Dict, Any, Optional, Callable

from src.config.config import WEBRTC_CONFIG

logger = logging.getLogger(__name__)

class WebRTCManager:
    """
    Manager for WebRTC communication.
    
    This class provides functionality for setting up and managing
    WebRTC connections for real-time communication with users.
    """
    
    def __init__(self):
        """Initialize the WebRTC manager."""
        self.config = WEBRTC_CONFIG
        self.connections = {}
        
        logger.info("Initialized WebRTC manager")
    
    def create_connection(self, connection_id: str) -> Dict[str, Any]:
        """
        Create a new WebRTC connection.
        
        Args:
            connection_id: A unique identifier for the connection.
            
        Returns:
            A dictionary containing the connection details.
        """
        if not self.config["enabled"]:
            logger.warning("WebRTC is disabled in configuration")
            return {"status": "disabled"}
        
        connection = {
            "id": connection_id,
            "status": "created",
            "ice_servers": self.config["ice_servers"]
        }
        
        self.connections[connection_id] = connection
        
        logger.info(f"Created WebRTC connection: {connection_id}")
        
        return connection
    
    def send_update(self, connection_id: str, data: Dict[str, Any]) -> bool:
        """
        Send an update to a WebRTC connection.
        
        Args:
            connection_id: The ID of the connection to send the update to.
            data: The data to send.
            
        Returns:
            True if the update was sent successfully, False otherwise.
        """
        if not self.config["enabled"]:
            logger.warning("WebRTC is disabled in configuration")
            return False
        
        if connection_id not in self.connections:
            logger.warning(f"WebRTC connection not found: {connection_id}")
            return False
        
        logger.debug(f"[MOCK WEBRTC] Sending update to {connection_id}: {json.dumps(data)}")
        
        return True
    
    def register_update_handler(self, connection_id: str, handler: Callable[[Dict[str, Any]], None]) -> bool:
        """
        Register a handler for updates from a WebRTC connection.
        
        Args:
            connection_id: The ID of the connection to register the handler for.
            handler: A function that will be called with updates from the connection.
            
        Returns:
            True if the handler was registered successfully, False otherwise.
        """
        if not self.config["enabled"]:
            logger.warning("WebRTC is disabled in configuration")
            return False
        
        if connection_id not in self.connections:
            logger.warning(f"WebRTC connection not found: {connection_id}")
            return False
        
        self.connections[connection_id]["handler"] = handler
        
        logger.info(f"Registered update handler for WebRTC connection: {connection_id}")
        
        return True
    
    def close_connection(self, connection_id: str) -> bool:
        """
        Close a WebRTC connection.
        
        Args:
            connection_id: The ID of the connection to close.
            
        Returns:
            True if the connection was closed successfully, False otherwise.
        """
        if not self.config["enabled"]:
            logger.warning("WebRTC is disabled in configuration")
            return False
        
        if connection_id not in self.connections:
            logger.warning(f"WebRTC connection not found: {connection_id}")
            return False
        
        del self.connections[connection_id]
        
        logger.info(f"Closed WebRTC connection: {connection_id}")
        
        return True

webrtc_manager = WebRTCManager()
