"""
Mock IIPM API for the Disaster Recovery Compliance Agent System.

This module provides a mock implementation of the IIPM (IT Infrastructure and Portfolio Management)
API for fetching application details.
"""

import logging
import random
from typing import List, Dict, Any, Optional

logger = logging.getLogger(__name__)

class MockIIPMAPI:
    """
    Mock implementation of the IIPM API.
    
    This class provides methods for fetching application details from a mock
    IIPM system.
    """
    
    def __init__(self):
        """Initialize the mock IIPM API with sample data."""
        self.app_details = self._generate_mock_app_details()
        logger.info(f"Initialized MockIIPMAPI with {len(self.app_details)} mock application details")
    
    def _generate_mock_app_details(self) -> Dict[str, Dict[str, Any]]:
        """
        Generate mock application details.
        
        Returns:
            A dictionary mapping application codes to their details.
        """
        app_details = {}
        
        business_criticality_levels = ["Critical", "High", "Medium", "Low"]
        
        for i in range(1, 21):
            app_code = f"APP{i:03d}"
            
            rto = random.choice([15, 30, 60, 120, 240, 480, 1440])
            
            rpo = random.choice([5, 15, 30, 60, 240, 1440])
            
            business_criticality = random.choice(business_criticality_levels)
            
            owners = [
                "John Smith", "Jane Doe", "Michael Johnson", "Emily Williams",
                "Robert Brown", "Sarah Davis", "David Miller", "Jennifer Wilson"
            ]
            owner = random.choice(owners)
            
            app_types = [
                "Web Application", "Database", "Middleware", "API Service",
                "Batch Processing", "Data Warehouse", "Mobile Application", "Legacy System"
            ]
            app_type = random.choice(app_types)
            
            tech_stacks = [
                "Java/Spring", "Python/Django", "Node.js/Express", ".NET/C#",
                "PHP/Laravel", "Ruby on Rails", "COBOL/Mainframe", "Oracle/PL-SQL"
            ]
            tech_stack = random.choice(tech_stacks)
            
            environments = [
                "On-premises", "AWS Cloud", "Azure Cloud", "Google Cloud",
                "Hybrid Cloud", "Private Cloud", "Mainframe", "Containerized"
            ]
            environment = random.choice(environments)
            
            data_classifications = [
                "Public", "Internal", "Confidential", "Restricted"
            ]
            data_classification = random.choice(data_classifications)
            
            support_teams = [
                "IT Operations", "Database Team", "Network Team", "Application Team",
                "Infrastructure Team", "Cloud Team", "Security Team", "DevOps Team"
            ]
            support_team = random.choice(support_teams)
            
            support_hours_options = [
                "24x7", "8x5", "16x5", "16x7"
            ]
            support_hours = random.choice(support_hours_options)
            
            last_dr_test_date = None
            if random.random() < 0.7:  # 70% chance of having a DR test
                year = random.randint(2022, 2024)
                month = random.randint(1, 12)
                day = random.randint(1, 28)
                last_dr_test_date = f"{year}-{month:02d}-{day:02d}"
            
            dr_test_result = None
            if last_dr_test_date:
                dr_test_results = ["Passed", "Failed", "Partial Success"]
                dr_test_result = random.choice(dr_test_results)
            
            dependencies = []
            for j in range(1, 21):
                if j != i and random.random() < 0.2:  # 20% chance of dependency
                    dependencies.append(f"APP{j:03d}")
            
            app_details[app_code] = {
                "app_code": app_code,
                "name": f"Application {i}",
                "description": f"This is a mock application {i} for testing purposes.",
                "recovery_time_objective": rto,
                "recovery_point_objective": rpo,
                "business_criticality": business_criticality,
                "owner": owner,
                "type": app_type,
                "tech_stack": tech_stack,
                "environment": environment,
                "data_classification": data_classification,
                "support_team": support_team,
                "support_hours": support_hours,
                "last_dr_test_date": last_dr_test_date,
                "dr_test_result": dr_test_result,
                "dependencies": dependencies
            }
        
        return app_details
    
    def get_app_details(self, app_code: str) -> Optional[Dict[str, Any]]:
        """
        Get details for a specific application.
        
        Args:
            app_code: The application code to get details for.
            
        Returns:
            A dictionary containing the application details, or None if not found.
        """
        logger.info(f"Getting details for app code: {app_code}")
        
        if app_code in self.app_details:
            return self.app_details[app_code]
        
        logger.warning(f"App code {app_code} not found")
        
        return None
    
    def get_app_details_batch(self, app_codes: List[str]) -> Dict[str, Dict[str, Any]]:
        """
        Get details for multiple applications.
        
        Args:
            app_codes: The list of application codes to get details for.
            
        Returns:
            A dictionary mapping application codes to their details.
        """
        logger.info(f"Getting details for app codes: {app_codes}")
        
        result = {}
        for app_code in app_codes:
            app_details = self.get_app_details(app_code)
            if app_details:
                result[app_code] = app_details
        
        logger.info(f"Found details for {len(result)} out of {len(app_codes)} app codes")
        
        return result
    
    def get_dependent_apps(self, app_code: str) -> List[str]:
        """
        Get the list of applications that depend on the specified application.
        
        Args:
            app_code: The application code to get dependents for.
            
        Returns:
            A list of application codes that depend on the specified application.
        """
        logger.info(f"Getting dependent apps for app code: {app_code}")
        
        dependent_apps = []
        for dep_app_code, app_details in self.app_details.items():
            if app_code in app_details.get("dependencies", []):
                dependent_apps.append(dep_app_code)
        
        logger.info(f"Found {len(dependent_apps)} dependent apps for app code {app_code}")
        
        return dependent_apps
    
    def get_dependencies(self, app_code: str) -> List[str]:
        """
        Get the list of applications that the specified application depends on.
        
        Args:
            app_code: The application code to get dependencies for.
            
        Returns:
            A list of application codes that the specified application depends on.
        """
        logger.info(f"Getting dependencies for app code: {app_code}")
        
        app_details = self.get_app_details(app_code)
        if app_details:
            dependencies = app_details.get("dependencies", [])
            logger.info(f"Found {len(dependencies)} dependencies for app code {app_code}")
            return dependencies
        
        logger.warning(f"App code {app_code} not found")
        
        return []
    
    def get_all_app_codes(self) -> List[str]:
        """
        Get all application codes.
        
        Returns:
            A list of all application codes.
        """
        logger.info(f"Getting all app codes")
        
        return list(self.app_details.keys())
    
    def get_apps_by_business_criticality(self, criticality: str) -> List[str]:
        """
        Get applications by business criticality.
        
        Args:
            criticality: The business criticality level to filter by.
            
        Returns:
            A list of application codes with the specified business criticality.
        """
        logger.info(f"Getting apps with business criticality: {criticality}")
        
        app_codes = []
        for app_code, app_details in self.app_details.items():
            if app_details.get("business_criticality") == criticality:
                app_codes.append(app_code)
        
        logger.info(f"Found {len(app_codes)} apps with business criticality {criticality}")
        
        return app_codes
    
    def get_apps_by_rto(self, max_rto: int) -> List[str]:
        """
        Get applications with RTO less than or equal to the specified value.
        
        Args:
            max_rto: The maximum RTO value in minutes.
            
        Returns:
            A list of application codes with RTO <= max_rto.
        """
        logger.info(f"Getting apps with RTO <= {max_rto}")
        
        app_codes = []
        for app_code, app_details in self.app_details.items():
            if app_details.get("recovery_time_objective", float("inf")) <= max_rto:
                app_codes.append(app_code)
        
        logger.info(f"Found {len(app_codes)} apps with RTO <= {max_rto}")
        
        return app_codes
    
    def get_apps_by_rpo(self, max_rpo: int) -> List[str]:
        """
        Get applications with RPO less than or equal to the specified value.
        
        Args:
            max_rpo: The maximum RPO value in minutes.
            
        Returns:
            A list of application codes with RPO <= max_rpo.
        """
        logger.info(f"Getting apps with RPO <= {max_rpo}")
        
        app_codes = []
        for app_code, app_details in self.app_details.items():
            if app_details.get("recovery_point_objective", float("inf")) <= max_rpo:
                app_codes.append(app_code)
        
        logger.info(f"Found {len(app_codes)} apps with RPO <= {max_rpo}")
        
        return app_codes

mock_iipm_api = MockIIPMAPI()
