"""
Mock IIPM API package.

This package provides a mock implementation of the IIPM (IT Infrastructure and Portfolio Management)
API for fetching application details.
"""

from src.mock_apis.iipm.api import MockIIPMAPI, mock_iipm_api

__all__ = ["MockIIPMAPI", "mock_iipm_api"]
