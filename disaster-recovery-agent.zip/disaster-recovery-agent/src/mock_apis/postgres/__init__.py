"""
Mock Postgres API package.

This package provides a mock implementation of the Postgres database API for fetching
disaster recovery plans.
"""

from src.mock_apis.postgres.api import MockPostgresAPI, mock_postgres_api

__all__ = ["MockPostgresAPI", "mock_postgres_api"]
