"""
Mock Postgres API for the Disaster Recovery Compliance Agent System.

This module provides a mock implementation of the Postgres database API for fetching
disaster recovery plans.
"""

import logging
import random
from datetime import datetime, timedelta
from typing import List, Dict, Any, Optional

from src.models.data_models import DisasterRecoveryPlan, RecoveryTask, Device

logger = logging.getLogger(__name__)

class MockPostgresAPI:
    """
    Mock implementation of the Postgres database API.
    
    This class provides methods for fetching disaster recovery plans from a mock
    Postgres database.
    """
    
    def __init__(self):
        """Initialize the mock Postgres API with sample data."""
        self.plans = self._generate_mock_plans()
        logger.info(f"Initialized MockPostgresAPI with {len(self.plans)} mock plans")
    
    def _generate_mock_plans(self) -> List[DisasterRecoveryPlan]:
        """
        Generate mock disaster recovery plans.
        
        Returns:
            A list of mock disaster recovery plans.
        """
        plans = []
        
        for i in range(1, 11):
            app_code = f"APP{i:03d}"
            
            tasks = []
            for j in range(1, random.randint(5, 10)):
                task = RecoveryTask(
                    id=f"TASK{i}{j:02d}",
                    name=f"Recovery Task {j} for {app_code}",
                    description=f"This is a mock recovery task {j} for application {app_code}.",
                    sequence=j,
                    estimated_duration=random.randint(15, 120),
                    responsible_team=random.choice(["IT Operations", "Database Team", "Network Team", "Application Team"]),
                    dependencies=[f"TASK{i}{k:02d}" for k in range(1, j) if random.random() < 0.3]
                )
                tasks.append(task)
            
            devices = []
            for j in range(1, random.randint(3, 8)):
                device = Device(
                    id=f"DEV{i}{j:02d}",
                    name=f"Device {j} for {app_code}",
                    type=random.choice(["Server", "Database", "Network", "Storage"]),
                    description=f"This is a mock device {j} for application {app_code}.",
                    app_code=app_code
                )
                devices.append(device)
            
            created_at = datetime.now() - timedelta(days=random.randint(30, 365))
            updated_at = created_at + timedelta(days=random.randint(1, 30))
            
            plan = DisasterRecoveryPlan(
                id=f"PLAN{i:03d}",
                app_code=app_code,
                name=f"Disaster Recovery Plan for {app_code}",
                description=f"This is a mock disaster recovery plan for application {app_code}. It includes recovery procedures, contact information, and other details needed for disaster recovery.",
                version=f"1.{random.randint(0, 9)}",
                created_at=created_at,
                updated_at=updated_at,
                recovery_time_objective=random.choice([60, 120, 240, 480, 1440]),  # in minutes
                recovery_point_objective=random.choice([15, 30, 60, 240, 1440]),  # in minutes
                tasks=tasks,
                devices=devices
            )
            
            plans.append(plan)
        
        return plans
    
    def get_plans_for_app_codes(self, app_codes: List[str]) -> List[DisasterRecoveryPlan]:
        """
        Get disaster recovery plans for a list of application codes.
        
        Args:
            app_codes: The list of application codes to get plans for.
            
        Returns:
            A list of disaster recovery plans for the specified application codes.
        """
        logger.info(f"Getting plans for app codes: {app_codes}")
        
        matching_plans = [plan for plan in self.plans if plan.app_code in app_codes]
        
        logger.info(f"Found {len(matching_plans)} plans for {len(app_codes)} app codes")
        
        return matching_plans
    
    def get_plan_by_id(self, plan_id: str) -> Optional[DisasterRecoveryPlan]:
        """
        Get a disaster recovery plan by its ID.
        
        Args:
            plan_id: The ID of the plan to get.
            
        Returns:
            The disaster recovery plan with the specified ID, or None if not found.
        """
        logger.info(f"Getting plan with ID: {plan_id}")
        
        for plan in self.plans:
            if plan.id == plan_id:
                return plan
        
        logger.warning(f"Plan with ID {plan_id} not found")
        
        return None
    
    def get_all_plans(self) -> List[DisasterRecoveryPlan]:
        """
        Get all disaster recovery plans.
        
        Returns:
            A list of all disaster recovery plans.
        """
        logger.info(f"Getting all plans")
        
        return self.plans
    
    def get_plans_with_query(self, query: str) -> List[DisasterRecoveryPlan]:
        """
        Get disaster recovery plans using a custom SQL query.
        
        This is a mock implementation that simulates executing a custom SQL query.
        In a real implementation, this would execute the query against a Postgres database.
        
        Args:
            query: The SQL query to execute.
            
        Returns:
            A list of disaster recovery plans matching the query.
        """
        logger.info(f"Executing query: {query}")
        
        
        return self.plans
    
    def get_actual_devices_for_app(self, app_code: str) -> List[Device]:
        """
        Get the actual devices that belong to an application.
        
        This is a mock implementation that simulates fetching actual devices
        from a Postgres database. In a real implementation, this would execute
        a query against a Postgres database.
        
        Args:
            app_code: The application code to get devices for.
            
        Returns:
            A list of devices that actually belong to the application.
        """
        logger.info(f"Getting actual devices for app code: {app_code}")
        
        actual_devices = []
        
        for plan in self.plans:
            if plan.app_code == app_code:
                for device in plan.devices:
                    if random.random() < 0.7:  # 70% chance of including a device from the plan
                        actual_devices.append(device)
        
        num_additional_devices = random.randint(1, 5)
        for i in range(num_additional_devices):
            device = Device(
                id=f"ACTUAL_DEV_{app_code}_{i:02d}",
                name=f"Actual Device {i} for {app_code}",
                type=random.choice(["Server", "Database", "Network", "Storage"]),
                description=f"This is an actual device {i} for application {app_code} not in the DR plan.",
                app_code=app_code
            )
            actual_devices.append(device)
        
        logger.info(f"Found {len(actual_devices)} actual devices for app code {app_code}")
        
        return actual_devices
    
    def get_actual_devices_for_apps(self, app_codes: List[str]) -> Dict[str, List[Device]]:
        """
        Get the actual devices that belong to multiple applications.
        
        Args:
            app_codes: The list of application codes to get devices for.
            
        Returns:
            A dictionary mapping application codes to lists of devices.
        """
        logger.info(f"Getting actual devices for app codes: {app_codes}")
        
        result = {}
        for app_code in app_codes:
            result[app_code] = self.get_actual_devices_for_app(app_code)
        
        return result

mock_postgres_api = MockPostgresAPI()
