"""
Mock FlowIQ API package.

This package provides a mock implementation of the FlowIQ API for finding
dependencies between application codes.
"""

from src.mock_apis.flowiq.api import MockFlowIQAPI, mock_flowiq_api

__all__ = ["MockFlowIQAPI", "mock_flowiq_api"]
