"""
Mock FlowIQ API for the Disaster Recovery Compliance Agent System.

This module provides a mock implementation of the FlowIQ API for finding
dependencies between application codes.
"""

import logging
import random
from typing import List, Dict, Any, Optional

from src.models.data_models import AppCode, Dependency
from src.config.config import EXTERNAL_API_CONFIG

logger = logging.getLogger(__name__)

class MockFlowIQAPI:
    """
    Mock implementation of the FlowIQ API.
    
    This class provides mock methods for finding dependencies between
    application codes, simulating the behavior of the actual FlowIQ API.
    """
    
    def __init__(self):
        """Initialize the mock FlowIQ API."""
        self.config = EXTERNAL_API_CONFIG["flowiq"]
        self.app_codes = {}
        self.dependencies = {}
        
        self._initialize_mock_data()
        
        logger.info("Initialized mock FlowIQ API")
    
    def _initialize_mock_data(self):
        """Initialize the mock API with some sample data."""
        sample_app_codes = [
            {"code": "APP001", "name": "Customer Portal", "description": "Customer-facing web portal"},
            {"code": "APP002", "name": "Account Service", "description": "Account management service"},
            {"code": "APP003", "name": "Payment Gateway", "description": "Payment processing service"},
            {"code": "APP004", "name": "Inventory System", "description": "Inventory management system"},
            {"code": "APP005", "name": "Order Management", "description": "Order processing system"},
            {"code": "APP006", "name": "Shipping Service", "description": "Shipping and logistics service"},
            {"code": "APP007", "name": "Notification Service", "description": "Email and SMS notification service"},
            {"code": "APP008", "name": "Analytics Platform", "description": "Business intelligence and analytics"},
            {"code": "APP009", "name": "User Authentication", "description": "User authentication and authorization"},
            {"code": "APP010", "name": "Content Management", "description": "Content management system"}
        ]
        
        for app_code_data in sample_app_codes:
            app_code = AppCode(**app_code_data)
            self.app_codes[app_code.code] = app_code
        
        sample_dependencies = [
            {"source_app_code": "APP001", "target_app_code": "APP002", "dependency_type": "API", "description": "Uses account service API"},
            {"source_app_code": "APP001", "target_app_code": "APP009", "dependency_type": "API", "description": "Uses authentication service"},
            {"source_app_code": "APP001", "target_app_code": "APP010", "dependency_type": "API", "description": "Uses content management API"},
            {"source_app_code": "APP002", "target_app_code": "APP003", "dependency_type": "API", "description": "Uses payment gateway for transactions"},
            {"source_app_code": "APP002", "target_app_code": "APP007", "dependency_type": "API", "description": "Uses notification service for alerts"},
            {"source_app_code": "APP005", "target_app_code": "APP004", "dependency_type": "API", "description": "Checks inventory availability"},
            {"source_app_code": "APP005", "target_app_code": "APP006", "dependency_type": "API", "description": "Creates shipping requests"},
            {"source_app_code": "APP005", "target_app_code": "APP007", "dependency_type": "API", "description": "Sends order notifications"},
            {"source_app_code": "APP008", "target_app_code": "APP001", "dependency_type": "Data", "description": "Analyzes customer portal data"},
            {"source_app_code": "APP008", "target_app_code": "APP005", "dependency_type": "Data", "description": "Analyzes order data"}
        ]
        
        for dependency_data in sample_dependencies:
            dependency = Dependency(**dependency_data)
            
            key = f"{dependency.source_app_code}:{dependency.target_app_code}"
            
            self.dependencies[key] = dependency
            
            if dependency.source_app_code not in self.dependencies:
                self.dependencies[dependency.source_app_code] = []
            
            self.dependencies[dependency.source_app_code].append(dependency)
    
    def get_app_code(self, code: str) -> Optional[AppCode]:
        """
        Get information about an application code.
        
        Args:
            code: The application code to get information for.
            
        Returns:
            An AppCode object if found, None otherwise.
        """
        return self.app_codes.get(code)
    
    def get_dependencies(self, app_code: str) -> List[Dependency]:
        """
        Get dependencies for an application code.
        
        Args:
            app_code: The application code to get dependencies for.
            
        Returns:
            A list of Dependency objects representing the dependencies.
        """
        if app_code in self.dependencies and isinstance(self.dependencies[app_code], list):
            return self.dependencies[app_code]
        
        if app_code not in self.app_codes:
            logger.warning(f"App code not found: {app_code}")
            return []
        
        potential_targets = [code for code in self.app_codes.keys() if code != app_code]
        
        if not potential_targets:
            return []
        
        num_dependencies = random.randint(0, min(3, len(potential_targets)))
        
        target_app_codes = random.sample(potential_targets, num_dependencies)
        
        dependencies = []
        for target_app_code in target_app_codes:
            dependency_type = random.choice(["API", "Data", "Infrastructure"])
            
            dependency = Dependency(
                source_app_code=app_code,
                target_app_code=target_app_code,
                dependency_type=dependency_type,
                description=f"Generated mock dependency from {app_code} to {target_app_code}"
            )
            
            dependencies.append(dependency)
        
        self.dependencies[app_code] = dependencies
        
        return dependencies
    
    def get_all_dependencies(self, app_codes: List[str], recursive: bool = True) -> List[Dependency]:
        """
        Get all dependencies for a list of application codes.
        
        Args:
            app_codes: The list of application codes to get dependencies for.
            recursive: Whether to recursively get dependencies of dependencies.
            
        Returns:
            A list of Dependency objects representing all dependencies.
        """
        all_dependencies = []
        processed_app_codes = set()
        app_codes_to_process = list(app_codes)
        
        while app_codes_to_process:
            current_app_code = app_codes_to_process.pop(0)
            
            if current_app_code in processed_app_codes:
                continue
            
            processed_app_codes.add(current_app_code)
            
            dependencies = self.get_dependencies(current_app_code)
            
            all_dependencies.extend(dependencies)
            
            if recursive:
                for dependency in dependencies:
                    if dependency.target_app_code not in processed_app_codes:
                        app_codes_to_process.append(dependency.target_app_code)
        
        return all_dependencies

mock_flowiq_api = MockFlowIQAPI()
