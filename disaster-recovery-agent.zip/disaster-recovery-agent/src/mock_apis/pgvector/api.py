"""
Mock PGVector API for the Disaster Recovery Compliance Agent System.

This module provides a mock implementation of the PGVector API for accessing
standard disaster recovery plans.
"""

import logging
import random
from typing import List, Dict, Any, Optional

from src.models.data_models import StandardPlan, StandardSection

logger = logging.getLogger(__name__)

class MockPGVectorAPI:
    """
    Mock implementation of the PGVector API.
    
    This class provides methods for accessing standard disaster recovery plans
    stored in a mock PGVector collection.
    """
    
    def __init__(self):
        """Initialize the mock PGVector API with sample data."""
        self.standard_plans = self._generate_mock_standard_plans()
        logger.info(f"Initialized MockPGVectorAPI with {len(self.standard_plans)} mock standard plans")
    
    def _generate_mock_standard_plans(self) -> List[StandardPlan]:
        """
        Generate mock standard disaster recovery plans.
        
        Returns:
            A list of mock standard disaster recovery plans.
        """
        plans = []
        
        description_plan = StandardPlan(
            id="STD_DESC_001",
            name="Standard Disaster Recovery Plan Description",
            type="description",
            sections=[
                StandardSection(
                    id="SEC_DESC_001",
                    name="Overview",
                    description="The overview section should provide a high-level summary of the disaster recovery plan, including its purpose, scope, and objectives.",
                    requirements=[
                        "Clear statement of purpose",
                        "Definition of scope (what is covered and what is not)",
                        "Specific recovery objectives",
                        "Alignment with business continuity goals"
                    ],
                    best_practices=[
                        "Keep the overview concise but comprehensive",
                        "Use clear, non-technical language for wider audience understanding",
                        "Include version history and approval information",
                        "Reference related documents and policies"
                    ]
                ),
                StandardSection(
                    id="SEC_DESC_002",
                    name="Risk Assessment",
                    description="The risk assessment section should identify potential threats and vulnerabilities that could cause a disaster or disruption to the application or service.",
                    requirements=[
                        "Identification of potential threats (natural disasters, cyber attacks, hardware failures, etc.)",
                        "Assessment of likelihood and impact for each threat",
                        "Prioritization of risks based on likelihood and impact",
                        "Specific vulnerabilities of the application or service"
                    ],
                    best_practices=[
                        "Use a structured risk assessment methodology",
                        "Include both internal and external threats",
                        "Review and update risk assessments regularly",
                        "Consider dependencies on other systems and services"
                    ]
                ),
                StandardSection(
                    id="SEC_DESC_003",
                    name="Recovery Strategy",
                    description="The recovery strategy section should outline the approach to recovering the application or service in the event of a disaster.",
                    requirements=[
                        "Clear recovery objectives (RTO, RPO)",
                        "Recovery priorities and sequence",
                        "Recovery methods and procedures",
                        "Resource requirements for recovery"
                    ],
                    best_practices=[
                        "Align recovery strategy with business priorities",
                        "Consider multiple recovery scenarios",
                        "Include both technical and non-technical aspects",
                        "Ensure strategy is realistic and achievable"
                    ]
                ),
                StandardSection(
                    id="SEC_DESC_004",
                    name="Roles and Responsibilities",
                    description="The roles and responsibilities section should define who is responsible for executing the disaster recovery plan.",
                    requirements=[
                        "Clear definition of roles and responsibilities",
                        "Contact information for key personnel",
                        "Escalation procedures",
                        "Backup personnel for key roles"
                    ],
                    best_practices=[
                        "Assign specific responsibilities to named individuals",
                        "Include both primary and secondary contacts",
                        "Define decision-making authority",
                        "Ensure 24/7 coverage for critical roles"
                    ]
                ),
                StandardSection(
                    id="SEC_DESC_005",
                    name="Communication Plan",
                    description="The communication plan section should outline how communication will be managed during a disaster recovery situation.",
                    requirements=[
                        "Communication channels and methods",
                        "Notification procedures",
                        "Stakeholder communication",
                        "Status reporting frequency and format"
                    ],
                    best_practices=[
                        "Use multiple communication channels",
                        "Establish clear communication hierarchy",
                        "Include templates for status reports",
                        "Define criteria for different types of notifications"
                    ]
                )
            ]
        )
        
        tasks_plan = StandardPlan(
            id="STD_TASKS_001",
            name="Standard Disaster Recovery Plan Tasks",
            type="tasks",
            sections=[
                StandardSection(
                    id="SEC_TASKS_001",
                    name="Task Structure",
                    description="Each recovery task should have a clear structure with all necessary information for execution.",
                    requirements=[
                        "Unique task identifier",
                        "Clear and descriptive task name",
                        "Detailed task description",
                        "Sequence number or priority",
                        "Estimated duration",
                        "Responsible team or individual",
                        "Dependencies on other tasks"
                    ],
                    best_practices=[
                        "Use consistent naming conventions for tasks",
                        "Break complex tasks into smaller, manageable subtasks",
                        "Include prerequisites for each task",
                        "Document expected outcomes or success criteria"
                    ]
                ),
                StandardSection(
                    id="SEC_TASKS_002",
                    name="Task Dependencies",
                    description="Task dependencies should be clearly defined to ensure proper sequencing during recovery.",
                    requirements=[
                        "Explicit listing of prerequisite tasks",
                        "Clear indication of dependent tasks",
                        "Handling of parallel vs. sequential tasks",
                        "Critical path identification"
                    ],
                    best_practices=[
                        "Minimize unnecessary dependencies",
                        "Group related tasks together",
                        "Consider creating a visual task dependency diagram",
                        "Include estimated wait times between dependent tasks"
                    ]
                ),
                StandardSection(
                    id="SEC_TASKS_003",
                    name="Task Verification",
                    description="Each task should include verification steps to confirm successful completion.",
                    requirements=[
                        "Specific verification steps",
                        "Success criteria",
                        "Troubleshooting guidance for common issues",
                        "Escalation procedures for task failures"
                    ],
                    best_practices=[
                        "Include automated verification where possible",
                        "Document expected outputs or states",
                        "Provide examples of successful completion",
                        "Include rollback procedures if verification fails"
                    ]
                ),
                StandardSection(
                    id="SEC_TASKS_004",
                    name="Resource Requirements",
                    description="Each task should specify the resources required for execution.",
                    requirements=[
                        "Personnel requirements (skills, roles)",
                        "System access requirements",
                        "Tools or software needed",
                        "Documentation or reference materials"
                    ],
                    best_practices=[
                        "Ensure resources are available during disaster scenarios",
                        "Include alternative resources where possible",
                        "Document contact information for specialized resources",
                        "Consider resource contention during large-scale recovery"
                    ]
                ),
                StandardSection(
                    id="SEC_TASKS_005",
                    name="Task Testing",
                    description="Recovery tasks should be regularly tested to ensure they remain effective.",
                    requirements=[
                        "Testing frequency",
                        "Testing methodology",
                        "Documentation of test results",
                        "Process for updating tasks based on test findings"
                    ],
                    best_practices=[
                        "Conduct regular tabletop exercises",
                        "Perform full-scale recovery tests periodically",
                        "Rotate personnel during testing to build broader expertise",
                        "Simulate various failure scenarios during testing"
                    ]
                )
            ]
        )
        
        plans.append(description_plan)
        plans.append(tasks_plan)
        
        return plans
    
    def get_standard_plan_by_type(self, plan_type: str) -> Optional[StandardPlan]:
        """
        Get a standard plan by its type.
        
        Args:
            plan_type: The type of standard plan to get.
            
        Returns:
            The standard plan with the specified type, or None if not found.
        """
        logger.info(f"Getting standard plan with type: {plan_type}")
        
        for plan in self.standard_plans:
            if plan.type == plan_type:
                return plan
        
        logger.warning(f"Standard plan with type {plan_type} not found")
        
        return None
    
    def get_standard_plan_by_id(self, plan_id: str) -> Optional[StandardPlan]:
        """
        Get a standard plan by its ID.
        
        Args:
            plan_id: The ID of the standard plan to get.
            
        Returns:
            The standard plan with the specified ID, or None if not found.
        """
        logger.info(f"Getting standard plan with ID: {plan_id}")
        
        for plan in self.standard_plans:
            if plan.id == plan_id:
                return plan
        
        logger.warning(f"Standard plan with ID {plan_id} not found")
        
        return None
    
    def get_all_standard_plans(self) -> List[StandardPlan]:
        """
        Get all standard plans.
        
        Returns:
            A list of all standard plans.
        """
        logger.info(f"Getting all standard plans")
        
        return self.standard_plans
    
    def search_standard_plans(self, query: str) -> List[StandardPlan]:
        """
        Search standard plans using a vector query.
        
        This is a mock implementation that simulates searching standard plans
        using a vector query. In a real implementation, this would use the
        PGVector extension to perform a vector similarity search.
        
        Args:
            query: The query to search for.
            
        Returns:
            A list of standard plans matching the query.
        """
        logger.info(f"Searching standard plans with query: {query}")
        
        
        return self.standard_plans
    
    def analyze_plan_description(self, description: str) -> Dict[str, Any]:
        """
        Analyze a plan description against standard plans.
        
        This is a mock implementation that simulates analyzing a plan description
        against standard plans. In a real implementation, this would use the
        PGVector extension to perform a vector similarity search and analysis.
        
        Args:
            description: The plan description to analyze.
            
        Returns:
            A dictionary containing the analysis results.
        """
        logger.info(f"Analyzing plan description")
        
        standard_plan = self.get_standard_plan_by_type("description")
        
        if not standard_plan:
            logger.warning("Standard plan for descriptions not found")
            return {
                "status": "error",
                "message": "Standard plan for descriptions not found"
            }
        
        
        sections = standard_plan.sections
        section_analyses = []
        
        for section in sections:
            compliance_score = random.uniform(0.5, 1.0)
            
            gaps = []
            for req in section.requirements:
                if random.random() < 0.3:  # 30% chance of a gap
                    gaps.append(f"Missing or inadequate: {req}")
            
            improvements = []
            for bp in section.best_practices:
                if random.random() < 0.4:  # 40% chance of an improvement
                    improvements.append(f"Consider implementing: {bp}")
            
            section_analysis = {
                "section_id": section.id,
                "section_name": section.name,
                "compliance_score": compliance_score,
                "gaps": gaps,
                "improvements": improvements
            }
            
            section_analyses.append(section_analysis)
        
        overall_compliance_score = sum(sa["compliance_score"] for sa in section_analyses) / len(section_analyses)
        
        summary = f"The plan description has an overall compliance score of {overall_compliance_score:.2f}. "
        
        if overall_compliance_score >= 0.8:
            summary += "The description is generally well-aligned with the standard plan, with some minor improvements possible."
        elif overall_compliance_score >= 0.6:
            summary += "The description meets most requirements but has several areas that need improvement."
        else:
            summary += "The description has significant gaps and requires substantial improvement to meet the standard."
        
        all_gaps = [gap for sa in section_analyses for gap in sa["gaps"]]
        all_improvements = [imp for sa in section_analyses for imp in sa["improvements"]]
        
        result = {
            "status": "success",
            "standard_plan_id": standard_plan.id,
            "standard_plan_name": standard_plan.name,
            "overall_compliance_score": overall_compliance_score,
            "summary": summary,
            "gaps": all_gaps,
            "improvements": all_improvements,
            "section_analyses": section_analyses
        }
        
        return result
    
    def analyze_plan_tasks(self, tasks: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Analyze plan recovery tasks against standard plans.
        
        This is a mock implementation that simulates analyzing plan recovery tasks
        against standard plans. In a real implementation, this would use the
        PGVector extension to perform a vector similarity search and analysis.
        
        Args:
            tasks: The list of recovery tasks to analyze.
            
        Returns:
            A dictionary containing the analysis results.
        """
        logger.info(f"Analyzing {len(tasks)} plan recovery tasks")
        
        standard_plan = self.get_standard_plan_by_type("tasks")
        
        if not standard_plan:
            logger.warning("Standard plan for tasks not found")
            return {
                "status": "error",
                "message": "Standard plan for tasks not found"
            }
        
        sections = standard_plan.sections
        section_analyses = []
        task_analyses = []
        
        for task in tasks:
            task_id = task.get("id", "unknown")
            task_name = task.get("name", "Unnamed Task")
            task_description = task.get("description", "")
            task_sequence = task.get("sequence", 0)
            task_duration = task.get("estimated_duration", 0)
            task_team = task.get("responsible_team", "")
            task_dependencies = task.get("dependencies", [])
            
            logger.info(f"Analyzing task {task_id}: {task_name}")
            
            task_compliance_score = random.uniform(0.5, 1.0)
            
            task_gaps = []
            task_improvements = []
            
            if not task_description or len(task_description) < 20:
                task_gaps.append("Task description is missing or too brief")
                task_improvements.append("Provide a detailed description of the task including its purpose and expected outcome")
            
            if task_duration <= 0:
                task_gaps.append("Estimated duration is missing or invalid")
                task_improvements.append("Specify a realistic estimated duration for the task")
            
            if not task_team:
                task_gaps.append("Responsible team is not specified")
                task_improvements.append("Assign a specific team or individual responsible for this task")
            
            for section in sections:
                if random.random() < 0.3:  # 30% chance of a gap for each section
                    req = random.choice(section.requirements)
                    task_gaps.append(f"[{section.name}] Missing or inadequate: {req}")
                
                if random.random() < 0.4:  # 40% chance of an improvement for each section
                    bp = random.choice(section.best_practices)
                    task_improvements.append(f"[{section.name}] Consider implementing: {bp}")
            
            task_analysis = {
                "task_id": task_id,
                "task_name": task_name,
                "compliance_score": task_compliance_score,
                "gaps": task_gaps,
                "improvements": task_improvements
            }
            
            task_analyses.append(task_analysis)
        
        for section in sections:
            section_compliance_score = random.uniform(0.5, 1.0)
            
            section_gaps = []
            for req in section.requirements:
                if random.random() < 0.3:  # 30% chance of a gap
                    section_gaps.append(f"Missing or inadequate across tasks: {req}")
            
            section_improvements = []
            for bp in section.best_practices:
                if random.random() < 0.4:  # 40% chance of an improvement
                    section_improvements.append(f"Consider implementing across tasks: {bp}")
            
            section_analysis = {
                "section_id": section.id,
                "section_name": section.name,
                "compliance_score": section_compliance_score,
                "gaps": section_gaps,
                "improvements": section_improvements
            }
            
            section_analyses.append(section_analysis)
        
        if task_analyses:
            task_compliance_score = sum(ta["compliance_score"] for ta in task_analyses) / len(task_analyses)
        else:
            task_compliance_score = 0.0
        
        section_compliance_score = sum(sa["compliance_score"] for sa in section_analyses) / len(section_analyses)
        
        overall_compliance_score = (task_compliance_score + section_compliance_score) / 2
        
        summary = f"The plan recovery tasks have an overall compliance score of {overall_compliance_score:.2f}. "
        
        if overall_compliance_score >= 0.8:
            summary += "The recovery tasks are generally well-defined and aligned with the standard plan, with some minor improvements possible."
        elif overall_compliance_score >= 0.6:
            summary += "The recovery tasks meet most requirements but have several areas that need improvement."
        else:
            summary += "The recovery tasks have significant gaps and require substantial improvement to meet the standard."
        
        summary += f"\n\nAnalyzed {len(tasks)} recovery tasks."
        
        if len(tasks) < 3:
            summary += " The plan may not have enough recovery tasks to be comprehensive."
        
        # Collect all gaps and improvements
        all_gaps = []
        all_improvements = []
        
        # Add section-level gaps and improvements
        for sa in section_analyses:
            for gap in sa["gaps"]:
                all_gaps.append(f"[{sa['section_name']}] {gap}")
            
            for imp in sa["improvements"]:
                all_improvements.append(f"[{sa['section_name']}] {imp}")
        
        # Add task-specific gaps and improvements
        for ta in task_analyses:
            for gap in ta["gaps"]:
                if not gap.startswith("["):
                    gap = f"[Task: {ta['task_name']}] {gap}"
                all_gaps.append(gap)
            
            for imp in ta["improvements"]:
                if not imp.startswith("["):
                    imp = f"[Task: {ta['task_name']}] {imp}"
                all_improvements.append(imp)
        
        result = {
            "status": "success",
            "standard_plan_id": standard_plan.id,
            "standard_plan_name": standard_plan.name,
            "overall_compliance_score": overall_compliance_score,
            "task_compliance_score": task_compliance_score,
            "section_compliance_score": section_compliance_score,
            "summary": summary,
            "gaps": all_gaps,
            "improvements": all_improvements,
            "section_analyses": section_analyses,
            "task_analyses": task_analyses
        }
        
        return result

mock_pgvector_api = MockPGVectorAPI()
