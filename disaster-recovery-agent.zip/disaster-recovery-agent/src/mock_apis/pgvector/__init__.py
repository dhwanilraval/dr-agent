"""
Mock PGVector API package.

This package provides a mock implementation of the PGVector API for accessing
standard disaster recovery plans.
"""

from src.mock_apis.pgvector.api import MockPGVectorAPI, mock_pgvector_api

__all__ = ["MockPGVectorAPI", "mock_pgvector_api"]
