"""
Configuration settings for the Disaster Recovery Compliance Agent System.
"""

import os
from typing import Dict, Any

API_CONFIG = {
    "host": os.getenv("API_HOST", "0.0.0.0"),
    "port": int(os.getenv("API_PORT", "8000")),
    "debug": os.getenv("API_DEBUG", "False").lower() == "true",
}

AGENT_CONFIG = {
    "process_dependency_agent": {
        "name": "Process Dependency Agent",
        "description": "Finds underlying dependencies and application codes that the submitted appcodes rely on.",
    },
    "dr_plans_fetcher_agent": {
        "name": "DR Plans Fetcher Agent",
        "description": "Fetches disaster recovery plans from a Postgres database table.",
    },
    "description_analysis_agent": {
        "name": "Description Analysis Agent",
        "description": "Analyzes each plan's description against standard plans stored in PGVector Collection.",
    },
    "tasks_analysis_agent": {
        "name": "Tasks Analysis Agent",
        "description": "Analyzes each plan's recovery tasks against standard plans stored in PGVector Collection.",
    },
    "device_reconciliation_agent": {
        "name": "Device Reconciliation Agent",
        "description": "Matches devices in the plan with devices that actually belong to the application.",
    },
    "iipm_analysis_agent": {
        "name": "IIPM Analysis Agent",
        "description": "Fetches required details for all supporting appcodes for the business process and dependent appcodes.",
    },
    "reasoning_agent": {
        "name": "DR Plan Analysis Reasoning Agent",
        "description": "Analyzes inputs from all agents to judge the overall quality of disaster recovery readiness, identify risks, and evaluate RTO/RPO metrics.",
    },
}

DB_CONFIG = {
    "postgres": {
        "host": os.getenv("POSTGRES_HOST", "localhost"),
        "port": int(os.getenv("POSTGRES_PORT", "5432")),
        "user": os.getenv("POSTGRES_USER", "postgres"),
        "password": os.getenv("POSTGRES_PASSWORD", "postgres"),
        "database": os.getenv("POSTGRES_DB", "disaster_recovery"),
    },
    "pgvector": {
        "host": os.getenv("PGVECTOR_HOST", "localhost"),
        "port": int(os.getenv("PGVECTOR_PORT", "5432")),
        "user": os.getenv("PGVECTOR_USER", "postgres"),
        "password": os.getenv("PGVECTOR_PASSWORD", "postgres"),
        "database": os.getenv("PGVECTOR_DB", "disaster_recovery_vector"),
    },
}

EXTERNAL_API_CONFIG = {
    "flowiq": {
        "base_url": os.getenv("FLOWIQ_API_URL", "https://api.flowiq.example.com"),
        "api_key": os.getenv("FLOWIQ_API_KEY", "mock_api_key"),
    },
    "iipm": {
        "base_url": os.getenv("IIPM_API_URL", "https://api.iipm.example.com"),
        "api_key": os.getenv("IIPM_API_KEY", "mock_api_key"),
    },
}

ELASTICSEARCH_CONFIG = {
    "host": os.getenv("ELASTICSEARCH_HOST", "localhost"),
    "port": int(os.getenv("ELASTICSEARCH_PORT", "9200")),
    "index": os.getenv("ELASTICSEARCH_INDEX", "disaster_recovery_logs"),
    "username": os.getenv("ELASTICSEARCH_USERNAME", "elastic"),
    "password": os.getenv("ELASTICSEARCH_PASSWORD", "elastic"),
}

LLM_CONFIG = {
    "cache_seed": 42  # for reproducibility and testing
}

WEBRTC_CONFIG = {
    "enabled": os.getenv("WEBRTC_ENABLED", "True").lower() == "true",
    "ice_servers": [
        {"urls": ["stun:stun.l.google.com:19302"]},
    ],
}
