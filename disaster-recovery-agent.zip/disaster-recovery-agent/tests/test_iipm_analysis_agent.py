"""
Tests for the IIPM Analysis Agent.

This module contains tests for the IIPM Analysis Agent and its interaction
with the IIPM API.
"""

import unittest
import os
from unittest.mock import patch, MagicMock
from datetime import datetime

from src.agents.iipm_analysis.agent import IIPMAnalysisAgent
from src.mock_apis.iipm.api import MockIIPMAPI

class MockAssistantAgent:
    def __init__(self, name, system_message, llm_config):
        self.name = name
        self.system_message = system_message
        self.llm_config = llm_config
    
    def generate_reply(self, message):
        return {"content": "Mock reply from assistant agent", "role": "assistant"}

class TestIIPMAnalysisAgent(unittest.TestCase):
    """Tests for the IIPM Analysis Agent."""
    
    def setUp(self):
        """Set up the test environment."""
        os.environ["OPENAI_API_KEY"] = "test_api_key"
        
        self.mock_iipm_api = MagicMock(spec=MockIIPMAPI)
        
        with patch("autogen.AssistantAgent", MockAssistantAgent):
            self.agent = IIPMAnalysisAgent()
            self.agent.iipm_api = self.mock_iipm_api
    
    def test_analyze_applications(self):
        """Test analyzing applications using the IIPM API."""
        app_codes = ["APP001", "APP002", "APP003"]
        
        app_details = {
            "APP001": {
                "app_code": "APP001",
                "name": "Application 1",
                "description": "This is a mock application 1 for testing purposes.",
                "recovery_time_objective": 60,
                "recovery_point_objective": 15,
                "business_criticality": "Critical",
                "owner": "John Smith",
                "type": "Web Application",
                "tech_stack": "Java/Spring",
                "environment": "AWS Cloud",
                "data_classification": "Confidential",
                "support_team": "IT Operations",
                "support_hours": "24x7",
                "last_dr_test_date": "2023-10-15",
                "dr_test_result": "Passed",
                "dependencies": ["APP004", "APP005"]
            },
            "APP002": {
                "app_code": "APP002",
                "name": "Application 2",
                "description": "This is a mock application 2 for testing purposes.",
                "recovery_time_objective": 120,
                "recovery_point_objective": 30,
                "business_criticality": "High",
                "owner": "Jane Doe",
                "type": "Database",
                "tech_stack": "Oracle/PL-SQL",
                "environment": "On-premises",
                "data_classification": "Restricted",
                "support_team": "Database Team",
                "support_hours": "16x5",
                "last_dr_test_date": "2023-08-20",
                "dr_test_result": "Failed",
                "dependencies": ["APP006"]
            },
            "APP003": {
                "app_code": "APP003",
                "name": "Application 3",
                "description": "This is a mock application 3 for testing purposes.",
                "recovery_time_objective": 240,
                "recovery_point_objective": 60,
                "business_criticality": "Medium",
                "owner": "Michael Johnson",
                "type": "API Service",
                "tech_stack": "Python/Django",
                "environment": "Azure Cloud",
                "data_classification": "Internal",
                "support_team": "Application Team",
                "support_hours": "8x5",
                "last_dr_test_date": None,
                "dr_test_result": None,
                "dependencies": []
            }
        }
        
        dependency_details = {
            "APP004": {
                "app_code": "APP004",
                "name": "Application 4",
                "description": "This is a mock application 4 for testing purposes.",
                "recovery_time_objective": 30,
                "recovery_point_objective": 5,
                "business_criticality": "Critical",
                "owner": "Emily Williams",
                "type": "Middleware",
                "tech_stack": "Node.js/Express",
                "environment": "AWS Cloud",
                "data_classification": "Confidential",
                "support_team": "Application Team",
                "support_hours": "24x7",
                "last_dr_test_date": "2023-11-10",
                "dr_test_result": "Passed",
                "dependencies": []
            },
            "APP005": {
                "app_code": "APP005",
                "name": "Application 5",
                "description": "This is a mock application 5 for testing purposes.",
                "recovery_time_objective": 480,
                "recovery_point_objective": 240,
                "business_criticality": "Low",
                "owner": "Robert Brown",
                "type": "Batch Processing",
                "tech_stack": "Java/Spring",
                "environment": "On-premises",
                "data_classification": "Internal",
                "support_team": "IT Operations",
                "support_hours": "8x5",
                "last_dr_test_date": "2023-09-05",
                "dr_test_result": "Partial Success",
                "dependencies": []
            },
            "APP006": {
                "app_code": "APP006",
                "name": "Application 6",
                "description": "This is a mock application 6 for testing purposes.",
                "recovery_time_objective": 1440,
                "recovery_point_objective": 1440,
                "business_criticality": "Low",
                "owner": "Sarah Davis",
                "type": "Legacy System",
                "tech_stack": "COBOL/Mainframe",
                "environment": "Mainframe",
                "data_classification": "Internal",
                "support_team": None,
                "support_hours": "8x5",
                "last_dr_test_date": None,
                "dr_test_result": None,
                "dependencies": []
            }
        }
        
        self.mock_iipm_api.get_app_details_batch.side_effect = [
            app_details,  # First call for app_codes
            dependency_details  # Second call for dependencies
        ]
        
        self.mock_iipm_api.get_dependencies.side_effect = [
            ["APP004", "APP005"],  # Dependencies for APP001
            ["APP006"],  # Dependencies for APP002
            []  # Dependencies for APP003
        ]
        
        result = self.agent.analyze_applications(app_codes)
        
        self.assertEqual(result["status"], "success")
        self.assertEqual(result["data"]["app_count"], 3)
        self.assertEqual(result["data"]["dependency_count"], 3)
        self.assertEqual(result["data"]["total_app_count"], 6)
        
        rto_analysis = result["data"]["rto_analysis"]
        self.assertEqual(len(rto_analysis["categories"]["critical"]), 2)  # APP001, APP004
        self.assertEqual(len(rto_analysis["categories"]["high"]), 2)  # APP002 and another app
        self.assertEqual(len(rto_analysis["categories"]["medium"]), 1)  # APP003
        self.assertEqual(len(rto_analysis["categories"]["low"]), 1)  # APP006
        self.assertEqual(rto_analysis["min_rto"], 30)  # APP004
        self.assertEqual(rto_analysis["min_rto_app"], "APP004")
        
        rpo_analysis = result["data"]["rpo_analysis"]
        self.assertEqual(len(rpo_analysis["categories"]["critical"]), 2)  # APP001, APP004
        self.assertEqual(len(rpo_analysis["categories"]["high"]), 2)  # APP002 and another app
        self.assertEqual(len(rpo_analysis["categories"]["medium"]), 1)  # APP003
        self.assertEqual(len(rpo_analysis["categories"]["low"]), 1)  # APP006
        self.assertEqual(rpo_analysis["min_rpo"], 5)  # APP004
        self.assertEqual(rpo_analysis["min_rpo_app"], "APP004")
        
        criticality_analysis = result["data"]["criticality_analysis"]
        self.assertEqual(len(criticality_analysis["categories"]["Critical"]), 2)  # APP001, APP004
        self.assertEqual(len(criticality_analysis["categories"]["High"]), 1)  # APP002
        self.assertEqual(len(criticality_analysis["categories"]["Medium"]), 1)  # APP003
        self.assertEqual(len(criticality_analysis["categories"]["Low"]), 2)  # APP005, APP006
        
        dr_test_analysis = result["data"]["dr_test_analysis"]
        self.assertEqual(len(dr_test_analysis["categories"]["passed"]), 2)  # APP001, APP004
        self.assertEqual(len(dr_test_analysis["categories"]["failed"]), 1)  # APP002
        self.assertEqual(len(dr_test_analysis["categories"]["partial"]), 1)  # APP005
        self.assertEqual(len(dr_test_analysis["categories"]["not_tested"]), 2)  # APP003, APP006
        
        self.assertGreater(len(result["data"]["recommendations"]), 0)
        
        self.mock_iipm_api.get_app_details_batch.assert_any_call(app_codes)
        self.assertEqual(self.mock_iipm_api.get_app_details_batch.call_count, 2)
        # First call should be with app_codes
        self.assertCountEqual(self.mock_iipm_api.get_app_details_batch.call_args_list[0][0][0], app_codes)
        # Second call should be with dependencies
        second_call_args = self.mock_iipm_api.get_app_details_batch.call_args_list[1][0][0]
        self.assertTrue(all(dep in second_call_args for dep in ["APP004", "APP005", "APP006"]))
        self.assertEqual(self.mock_iipm_api.get_dependencies.call_count, 3)
    
    def test_process_message_with_process_dependency_data(self):
        """Test processing a message with process dependency data."""
        message = {
            "process_dependency_data": {
                "data": {
                    "app_codes": ["APP001", "APP002"],
                    "dependent_app_codes": ["APP003", "APP004"]
                }
            }
        }
        
        self.agent.analyze_applications = MagicMock(return_value={
            "status": "success",
            "data": {
                "app_count": 4,
                "dependency_count": 2,
                "total_app_count": 6,
                "app_details": {},
                "rto_analysis": {
                    "categories": {
                        "critical": ["APP001", "APP004"],
                        "high": ["APP002"],
                        "medium": ["APP003"],
                        "low": ["APP005", "APP006"]
                    },
                    "min_rto": 30,
                    "min_rto_app": "APP004"
                },
                "rpo_analysis": {
                    "categories": {
                        "critical": ["APP001", "APP004"],
                        "high": ["APP002"],
                        "medium": ["APP003"],
                        "low": ["APP005", "APP006"]
                    },
                    "min_rpo": 5,
                    "min_rpo_app": "APP004"
                },
                "criticality_analysis": {
                    "categories": {
                        "Critical": ["APP001", "APP004"],
                        "High": ["APP002"],
                        "Medium": ["APP003"],
                        "Low": ["APP005", "APP006"]
                    }
                },
                "dr_test_analysis": {
                    "categories": {
                        "passed": ["APP001", "APP004"],
                        "failed": ["APP002"],
                        "partial": ["APP005"],
                        "not_tested": ["APP003", "APP006"]
                    }
                },
                "recommendations": ["Recommendation 1", "Recommendation 2"]
            }
        })
        
        result = self.agent.process_message(message)
        
        self.assertEqual(result["status"], "success")
        self.assertIn("data", result)
        
        self.assertEqual(self.agent.analyze_applications.call_count, 1)
        call_args = self.agent.analyze_applications.call_args[0][0]
        self.assertCountEqual(call_args, ["APP001", "APP002", "APP003", "APP004"])
    
    def test_process_message_with_plans_data(self):
        """Test processing a message with plans data."""
        message = {
            "plans_data": {
                "data": {
                    "plans": [
                        {"app_code": "APP001"},
                        {"app_code": "APP002"}
                    ]
                }
            }
        }
        
        self.agent.analyze_applications = MagicMock(return_value={
            "status": "success",
            "data": {
                "app_count": 2,
                "dependency_count": 1,
                "total_app_count": 3,
                "app_details": {},
                "rto_analysis": {
                    "categories": {
                        "critical": ["APP001"],
                        "high": ["APP002"],
                        "medium": [],
                        "low": ["APP003"]
                    },
                    "min_rto": 60,
                    "min_rto_app": "APP001"
                },
                "rpo_analysis": {
                    "categories": {
                        "critical": ["APP001"],
                        "high": ["APP002"],
                        "medium": [],
                        "low": ["APP003"]
                    },
                    "min_rpo": 15,
                    "min_rpo_app": "APP001"
                },
                "criticality_analysis": {
                    "categories": {
                        "Critical": ["APP001"],
                        "High": ["APP002"],
                        "Medium": [],
                        "Low": ["APP003"]
                    }
                },
                "dr_test_analysis": {
                    "categories": {
                        "passed": ["APP001"],
                        "failed": [],
                        "partial": [],
                        "not_tested": ["APP002", "APP003"]
                    }
                },
                "recommendations": ["Recommendation 1"]
            }
        })
        
        result = self.agent.process_message(message)
        
        self.assertEqual(result["status"], "success")
        self.assertIn("data", result)
        
        self.assertEqual(self.agent.analyze_applications.call_count, 1)
        call_args = self.agent.analyze_applications.call_args[0][0]
        self.assertCountEqual(call_args, ["APP001", "APP002"])
    
    def test_process_message_no_app_codes(self):
        """Test processing a message with no app codes."""
        message = {}
        
        original_analyze_applications = self.agent.analyze_applications
        self.agent.analyze_applications = MagicMock()
        
        try:
            result = self.agent.process_message(message)
            
            self.assertEqual(result["status"], "error")
            self.assertIn("message", result)
            
            self.agent.analyze_applications.assert_not_called()
        finally:
            self.agent.analyze_applications = original_analyze_applications
    
    def test_process_message_error(self):
        """Test processing a message when an error occurs."""
        message = {
            "process_dependency_data": {
                "data": {
                    "app_codes": ["APP001", "APP002"],
                    "dependent_app_codes": ["APP003", "APP004"]
                }
            }
        }
        
        self.agent.analyze_applications = MagicMock(side_effect=Exception("Test error"))
        
        result = self.agent.process_message(message)
        
        self.assertEqual(result["status"], "error")
        self.assertIn("message", result)
        
        self.agent.analyze_applications.assert_called_once()

if __name__ == "__main__":
    unittest.main()
