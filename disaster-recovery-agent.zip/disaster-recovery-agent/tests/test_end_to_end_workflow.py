"""
End-to-end test for the Disaster Recovery Compliance Agent System.

This module tests the entire agentic workflow from the REST API entrypoint
to the final output from the Reasoning Agent.
"""

import unittest
import json
import asyncio
import uuid
from unittest.mock import patch, MagicMock, Mock
from fastapi.testclient import TestClient
from httpx import AsyncClient

import sys
sys.modules['autogen'] = MagicMock()
sys.modules['autogen.agentchat'] = MagicMock()
sys.modules['autogen.agentchat.assistant_agent'] = MagicMock()
sys.modules['autogen.agentchat.conversable_agent'] = MagicMock()
sys.modules['autogen.agentchat.groupchat'] = MagicMock()

mock_architecture = MagicMock()
sys.modules['src.architecture'] = mock_architecture

class MockDisasterRecoveryAgentSystem:
    """Mock implementation of the DisasterRecoveryAgentSystem class."""
    
    def __init__(self):
        """Initialize the mock system."""
        self.api_app = None
    
    def analyze_business_process(self, business_process, app_codes):
        """Mock implementation of analyze_business_process."""
        return {
            "overall_quality": "Medium",
            "dr_readiness_score": 75,
            "risk_level": "Medium",
            "risks": [
                "[High] Infrastructure: Critical servers not in high-availability configuration",
                "[Medium] Process: Recovery procedures not fully documented"
            ],
            "rto_rpo_analysis": {
                "expected": {
                    "rto": "120 minutes",
                    "rpo": "30 minutes"
                },
                "actual": {
                    "rto": "180 minutes",
                    "rpo": "60 minutes"
                },
                "met": False
            },
            "recommendations": [
                "[High] Infrastructure: Implement high-availability for critical servers",
                "[Medium] Process: Complete documentation of recovery procedures"
            ],
            "detailed_analysis": "Detailed analysis of the disaster recovery readiness...",
            "component_scores": {
                "plan_descriptions": 80,
                "recovery_tasks": 70,
                "device_coverage": 65,
                "dr_testing": 85
            }
        }

from fastapi import FastAPI
from unittest.mock import MagicMock

# Import the rest_api module after mocking architecture
from src.api.rest_api import ongoing_analyses, run_analysis
from src.utils.webrtc_utils import webrtc_manager

def mock_create_api_app(system):
    """Mock implementation of create_api_app."""
    app = FastAPI()
    
    @app.get("/health")
    async def health_check():
        return {"status": "healthy"}
    
    @app.post("/api/analyze")
    async def analyze_business_process(request: dict):
        import uuid
        request_id = str(uuid.uuid4())
        ongoing_analyses[request_id] = {
            "status": "processing",
            "request": request,
            "results": None
        }
        return {"request_id": request_id, "status": "processing"}
    
    @app.get("/api/analyze/{request_id}")
    async def get_analysis_results(request_id: str):
        if request_id not in ongoing_analyses:
            return {"error": "Analysis request not found"}
        analysis = ongoing_analyses[request_id]
        return {
            "request_id": request_id,
            "status": analysis["status"],
            "results": analysis["results"]
        }
    
    return app


class TestEndToEndWorkflow(unittest.TestCase):
    """Test the end-to-end workflow of the Disaster Recovery Compliance Agent System."""

    def setUp(self):
        """Set up the test environment."""
        self.mock_system = MockDisasterRecoveryAgentSystem()
        
        self.original_analyze = self.mock_system.analyze_business_process
        self.mock_system.analyze_business_process = MagicMock(side_effect=self.original_analyze)
        
        self.app = mock_create_api_app(self.mock_system)
        self.client = TestClient(self.app)
        
        self.original_send_update = webrtc_manager.send_update
        webrtc_manager.send_update = MagicMock(return_value=True)
    
    def tearDown(self):
        """Clean up after the test."""
        webrtc_manager.send_update = self.original_send_update
        
        ongoing_analyses.clear()
    
    def test_direct_system_call(self):
        """Test calling the system directly."""
        business_process = "Payment Processing"
        app_codes = ["APP001", "APP002", "APP003"]
        
        result = self.mock_system.analyze_business_process(business_process, app_codes)
        
        self.assertEqual(result["overall_quality"], "Medium")
        self.assertEqual(result["dr_readiness_score"], 75)
        self.assertEqual(result["risk_level"], "Medium")
        self.assertEqual(len(result["risks"]), 2)
        self.assertEqual(len(result["recommendations"]), 2)
        self.assertFalse(result["rto_rpo_analysis"]["met"])
        
        self.mock_system.analyze_business_process.assert_called_once_with(
            business_process=business_process,
            app_codes=app_codes
        )
    
    def test_rest_api_analyze_endpoint(self):
        """Test the REST API analyze endpoint."""
        request_data = {
            "business_process": "Payment Processing",
            "app_codes": ["APP001", "APP002", "APP003"]
        }
        
        response = self.client.post("/api/analyze", json=request_data)
        
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertEqual(data["status"], "processing")
        self.assertTrue("request_id" in data)
        
        request_id = data["request_id"]
        
        ongoing_analyses[request_id] = {
            "status": "completed",
            "request": request_data,
            "results": self.mock_system.analyze_business_process.return_value
        }
        
        response = self.client.get(f"/api/analyze/{request_id}")
        
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertEqual(data["status"], "completed")
        self.assertEqual(data["results"]["overall_quality"], "Medium")
        self.assertEqual(data["results"]["dr_readiness_score"], 75)
        self.assertEqual(data["results"]["risk_level"], "Medium")
    
    @patch('src.api.rest_api.run_analysis')
    def test_webrtc_updates(self, mock_run_analysis):
        """Test that WebRTC updates are sent during analysis."""
        request_id = "test-request-id"
        business_process = "Payment Processing"
        app_codes = ["APP001", "APP002", "APP003"]
        
        async def side_effect(system, req_id, bp, ac):
            webrtc_manager.send_update(req_id, {
                "type": "status_update",
                "status": "processing",
                "message": f"Starting analysis for business process: {bp} with app codes: {', '.join(ac)}"
            })
            
            results = system.analyze_business_process(bp, ac)
            
            ongoing_analyses[req_id] = {
                "status": "completed",
                "request": {"business_process": bp, "app_codes": ac},
                "results": results
            }
            
            webrtc_manager.send_update(req_id, {
                "type": "status_update",
                "status": "completed",
                "message": "Analysis completed successfully",
                "results": {
                    "overall_quality": results.get("overall_quality"),
                    "dr_readiness_score": results.get("dr_readiness_score"),
                    "risk_level": results.get("risk_level"),
                    "risks_count": len(results.get("risks", [])),
                    "recommendations_count": len(results.get("recommendations", []))
                }
            })
        
        mock_run_analysis.side_effect = side_effect
        
        request_data = {
            "business_process": business_process,
            "app_codes": app_codes
        }
        
        with patch('uuid.uuid4', return_value=Mock(return_value=request_id, __str__=lambda _: request_id)):
            response = self.client.post("/api/analyze", json=request_data)
            
            asyncio.run(mock_run_analysis(
                self.mock_system,
                request_id,
                business_process,
                app_codes
            ))
        
        webrtc_manager.send_update.assert_any_call(request_id, {
            "type": "status_update",
            "status": "processing",
            "message": f"Starting analysis for business process: {business_process} with app codes: {', '.join(app_codes)}"
        })
        
        webrtc_manager.send_update.assert_any_call(request_id, {
            "type": "status_update",
            "status": "completed",
            "message": "Analysis completed successfully",
            "results": {
                "overall_quality": "Medium",
                "dr_readiness_score": 75,
                "risk_level": "Medium",
                "risks_count": 2,
                "recommendations_count": 2
            }
        })
    
    @patch("src.utils.logging_utils.ElasticsearchHandler.emit")
    def test_elasticsearch_logging(self, mock_emit):
        """Test that Elasticsearch logging is used during analysis."""
        business_process = "Payment Processing"
        app_codes = ["APP001", "APP002", "APP003"]
        
        self.mock_system.analyze_business_process(business_process, app_codes)
        
        self.assertTrue(mock_emit.called)


if __name__ == "__main__":
    unittest.main()
