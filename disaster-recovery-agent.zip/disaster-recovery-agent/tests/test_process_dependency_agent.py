"""
Tests for the Process Dependency Agent.

This module contains tests for the Process Dependency Agent and its interaction
with the FlowIQ API.
"""

import unittest
import os
from unittest.mock import patch, MagicMock

from src.agents.process_dependency.agent import ProcessDependencyAgent
from src.mock_apis.flowiq.api import MockFlowIQAPI
from src.models.data_models import AppCode, Dependency
from src.config.config import LLM_CONFIG

class MockAssistantAgent:
    def __init__(self, name, system_message, llm_config):
        self.name = name
        self.system_message = system_message
        self.llm_config = llm_config
    
    def generate_reply(self, message):
        return {"content": "Mock reply from assistant agent", "role": "assistant"}

class TestProcessDependencyAgent(unittest.TestCase):
    """Tests for the Process Dependency Agent."""
    
    def setUp(self):
        """Set up the test environment."""
        os.environ["OPENAI_API_KEY"] = "test_api_key"
        
        self.mock_flowiq_api = MagicMock(spec=MockFlowIQAPI)
        
        with patch("autogen.AssistantAgent", MockAssistantAgent):
            self.agent = ProcessDependencyAgent()
            self.agent.flowiq_api = self.mock_flowiq_api
    
    def test_find_dependencies(self):
        """Test finding dependencies for application codes."""
        app_codes = ["APP001", "APP002"]
        
        app_code_1 = AppCode(code="APP001", name="App 1", description="Description 1")
        app_code_2 = AppCode(code="APP002", name="App 2", description="Description 2")
        app_code_3 = AppCode(code="APP003", name="App 3", description="Description 3")
        
        dependency_1 = Dependency(
            source_app_code="APP001",
            target_app_code="APP003",
            dependency_type="API",
            description="Dependency 1"
        )
        
        dependency_2 = Dependency(
            source_app_code="APP002",
            target_app_code="APP003",
            dependency_type="Data",
            description="Dependency 2"
        )
        
        self.mock_flowiq_api.get_all_dependencies.return_value = [dependency_1, dependency_2]
        self.mock_flowiq_api.get_app_code.side_effect = lambda code: {
            "APP001": app_code_1,
            "APP002": app_code_2,
            "APP003": app_code_3
        }.get(code)
        
        result = self.agent.find_dependencies(app_codes)
        
        self.assertEqual(result["original_app_codes"], app_codes)
        self.assertEqual(set(result["all_app_codes"]), {"APP001", "APP002", "APP003"})
        self.assertEqual(len(result["dependencies"]), 2)
        self.assertEqual(len(result["app_code_details"]), 3)
        
        self.mock_flowiq_api.get_all_dependencies.assert_called_once_with(app_codes, recursive=True)
    
    def test_process_message(self):
        """Test processing a message with application codes."""
        message = {
            "app_codes": ["APP001", "APP002"]
        }
        
        self.agent.find_dependencies = MagicMock(return_value={
            "original_app_codes": ["APP001", "APP002"],
            "all_app_codes": ["APP001", "APP002", "APP003"],
            "dependencies": [{"source_app_code": "APP001", "target_app_code": "APP003"}],
            "app_code_details": {"APP001": {}, "APP002": {}, "APP003": {}}
        })
        
        result = self.agent.process_message(message)
        
        self.assertEqual(result["status"], "success")
        self.assertIn("data", result)
        
        self.agent.find_dependencies.assert_called_once_with(["APP001", "APP002"])
    
    def test_process_message_no_app_codes(self):
        """Test processing a message with no application codes."""
        message = {}
        
        original_find_dependencies = self.agent.find_dependencies
        
        self.agent.find_dependencies = MagicMock()
        
        try:
            result = self.agent.process_message(message)
            
            self.assertEqual(result["status"], "error")
            self.assertIn("message", result)
            
            self.agent.find_dependencies.assert_not_called()
        finally:
            self.agent.find_dependencies = original_find_dependencies
    
    def test_process_message_error(self):
        """Test processing a message when an error occurs."""
        message = {
            "app_codes": ["APP001", "APP002"]
        }
        
        self.agent.find_dependencies = MagicMock(side_effect=Exception("Test error"))
        
        result = self.agent.process_message(message)
        
        self.assertEqual(result["status"], "error")
        self.assertIn("message", result)
        
        self.agent.find_dependencies.assert_called_once_with(["APP001", "APP002"])

if __name__ == "__main__":
    unittest.main()
