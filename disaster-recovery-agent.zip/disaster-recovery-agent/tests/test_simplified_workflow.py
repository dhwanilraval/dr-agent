"""
Simplified end-to-end test for the Disaster Recovery Compliance Agent System.

This module tests the core agentic workflow without relying on FastAPI TestClient.
"""

import unittest
from unittest.mock import patch, MagicMock

import sys
sys.modules['autogen'] = MagicMock()
sys.modules['autogen.agentchat'] = MagicMock()
sys.modules['autogen.agentchat.assistant_agent'] = MagicMock()
sys.modules['autogen.agentchat.conversable_agent'] = MagicMock()
sys.modules['autogen.agentchat.groupchat'] = MagicMock()

class MockDisasterRecoveryAgentSystem:
    """Mock implementation of the DisasterRecoveryAgentSystem class."""
    
    def __init__(self):
        """Initialize the mock system."""
        self.process_dependency_agent = MagicMock()
        self.dr_plans_fetcher_agent = MagicMock()
        self.description_analysis_agent = MagicMock()
        self.tasks_analysis_agent = MagicMock()
        self.device_reconciliation_agent = MagicMock()
        self.iipm_analysis_agent = MagicMock()
        self.reasoning_agent = MagicMock()
        
        self.process_dependency_agent.find_dependencies.return_value = ["APP001", "APP002", "APP003"]
        
        self.dr_plans_fetcher_agent.fetch_dr_plans.return_value = [
            {"id": 1, "app_code": "APP001", "description": "Plan for APP001", "recovery_tasks": ["Task 1", "Task 2"]},
            {"id": 2, "app_code": "APP002", "description": "Plan for APP002", "recovery_tasks": ["Task 1", "Task 2"]},
            {"id": 3, "app_code": "APP003", "description": "Plan for APP003", "recovery_tasks": ["Task 1", "Task 2"]}
        ]
        
        self.description_analysis_agent.analyze_descriptions.return_value = {
            "APP001": {"quality": "High", "gaps": [], "improvements": []},
            "APP002": {"quality": "Medium", "gaps": ["Missing details"], "improvements": ["Add more details"]},
            "APP003": {"quality": "Low", "gaps": ["Incomplete"], "improvements": ["Complete the plan"]}
        }
        
        self.tasks_analysis_agent.analyze_tasks.return_value = {
            "APP001": {"quality": "High", "gaps": [], "improvements": []},
            "APP002": {"quality": "Medium", "gaps": ["Missing steps"], "improvements": ["Add more steps"]},
            "APP003": {"quality": "Low", "gaps": ["Incomplete"], "improvements": ["Complete the tasks"]}
        }
        
        self.device_reconciliation_agent.reconcile_devices.return_value = {
            "APP001": {"matched": True, "missing_devices": []},
            "APP002": {"matched": False, "missing_devices": ["Server1"]},
            "APP003": {"matched": False, "missing_devices": ["Server2", "Server3"]}
        }
        
        self.iipm_analysis_agent.analyze_app_details.return_value = {
            "APP001": {"rto": "60 minutes", "rpo": "15 minutes", "criticality": "High"},
            "APP002": {"rto": "120 minutes", "rpo": "30 minutes", "criticality": "Medium"},
            "APP003": {"rto": "240 minutes", "rpo": "60 minutes", "criticality": "Low"}
        }
        
        self.reasoning_agent.analyze_dr_readiness.return_value = {
            "overall_quality": "Medium",
            "dr_readiness_score": 75,
            "risk_level": "Medium",
            "risks": [
                "[High] Infrastructure: Critical servers not in high-availability configuration",
                "[Medium] Process: Recovery procedures not fully documented"
            ],
            "rto_rpo_analysis": {
                "expected": {"rto": "120 minutes", "rpo": "30 minutes"},
                "actual": {"rto": "180 minutes", "rpo": "60 minutes"},
                "met": False
            },
            "recommendations": [
                "[High] Infrastructure: Implement high-availability for critical servers",
                "[Medium] Process: Complete documentation of recovery procedures"
            ],
            "detailed_analysis": "Detailed analysis of the disaster recovery readiness...",
            "component_scores": {
                "plan_descriptions": 80,
                "recovery_tasks": 70,
                "device_coverage": 65,
                "dr_testing": 85
            }
        }
    
    def analyze_business_process(self, business_process, app_codes, request_id=None):
        """Mock implementation of analyze_business_process."""
        from src.utils.webrtc_utils import webrtc_manager
        from src.utils.logging_utils import log_agent_interaction
        
        if request_id:
            log_agent_interaction(
                agent_name="system",
                message=f"Starting analysis for business process: {business_process}",
                request_id=request_id,
                workflow_step="start_analysis"
            )
            
            webrtc_manager.send_update(request_id, {
                "type": "status_update",
                "status": "processing",
                "message": f"Starting analysis for business process: {business_process} with app codes: {', '.join(app_codes)}"
            })
        
        dependencies = self.process_dependency_agent.find_dependencies(app_codes)
        all_app_codes = list(set(app_codes + dependencies))
        
        if request_id:
            log_agent_interaction(
                agent_name="process_dependency",
                message=f"Found dependencies: {', '.join(dependencies)}",
                request_id=request_id,
                workflow_step="dependency_analysis"
            )
        
        dr_plans = self.dr_plans_fetcher_agent.fetch_dr_plans(all_app_codes)
        
        if request_id:
            log_agent_interaction(
                agent_name="dr_plans_fetcher",
                message=f"Fetched {len(dr_plans)} DR plans",
                request_id=request_id,
                workflow_step="plan_retrieval"
            )
        
        description_analysis = self.description_analysis_agent.analyze_descriptions(dr_plans)
        
        if request_id:
            log_agent_interaction(
                agent_name="description_analysis",
                message="Analyzed plan descriptions",
                request_id=request_id,
                workflow_step="description_analysis"
            )
        
        tasks_analysis = self.tasks_analysis_agent.analyze_tasks(dr_plans)
        
        if request_id:
            log_agent_interaction(
                agent_name="tasks_analysis",
                message="Analyzed recovery tasks",
                request_id=request_id,
                workflow_step="tasks_analysis"
            )
        
        device_reconciliation = self.device_reconciliation_agent.reconcile_devices(all_app_codes, dr_plans)
        
        if request_id:
            log_agent_interaction(
                agent_name="device_reconciliation",
                message="Reconciled devices",
                request_id=request_id,
                workflow_step="device_reconciliation"
            )
        
        app_details = self.iipm_analysis_agent.analyze_app_details(all_app_codes)
        
        if request_id:
            log_agent_interaction(
                agent_name="iipm_analysis",
                message="Analyzed application details",
                request_id=request_id,
                workflow_step="iipm_analysis"
            )
        
        analysis_result = self.reasoning_agent.analyze_dr_readiness({
            "business_process": business_process,
            "app_codes": app_codes,
            "dependencies": dependencies,
            "dr_plans": dr_plans,
            "description_analysis": description_analysis,
            "tasks_analysis": tasks_analysis,
            "device_reconciliation": device_reconciliation,
            "app_details": app_details
        })
        
        if request_id:
            log_agent_interaction(
                agent_name="reasoning",
                message="Completed analysis",
                request_id=request_id,
                workflow_step="final_analysis",
                agent_data={
                    "overall_quality": analysis_result.get("overall_quality"),
                    "dr_readiness_score": analysis_result.get("dr_readiness_score"),
                    "risk_level": analysis_result.get("risk_level")
                }
            )
            
            webrtc_manager.send_update(request_id, {
                "type": "status_update",
                "status": "completed",
                "message": "Analysis completed successfully",
                "results": {
                    "overall_quality": analysis_result.get("overall_quality"),
                    "dr_readiness_score": analysis_result.get("dr_readiness_score"),
                    "risk_level": analysis_result.get("risk_level"),
                    "risks_count": len(analysis_result.get("risks", [])),
                    "recommendations_count": len(analysis_result.get("recommendations", []))
                }
            })
        
        return analysis_result

from src.utils.webrtc_utils import webrtc_manager
from src.utils.logging_utils import log_agent_interaction

class TestSimplifiedWorkflow(unittest.TestCase):
    """Test the simplified end-to-end workflow of the Disaster Recovery Compliance Agent System."""
    
    def setUp(self):
        """Set up the test environment."""
        self.mock_system = MockDisasterRecoveryAgentSystem()
        
        self.webrtc_patcher = patch('src.utils.webrtc_utils.webrtc_manager.send_update')
        self.mock_send_update = self.webrtc_patcher.start()
        
        self.log_patcher = patch('src.utils.logging_utils.log_agent_interaction')
        self.mock_log_agent_interaction = self.log_patcher.start()
    
    def tearDown(self):
        """Clean up after the test."""
        self.webrtc_patcher.stop()
        self.log_patcher.stop()
    
    def test_complete_workflow(self):
        """Test the complete workflow from input to output."""
        business_process = "Payment Processing"
        app_codes = ["APP001"]
        request_id = "test-request-id"
        
        result = self.mock_system.analyze_business_process(
            business_process=business_process,
            app_codes=app_codes,
            request_id=request_id
        )
        
        self.mock_system.process_dependency_agent.find_dependencies.assert_called_once_with(app_codes)
        
        all_app_codes = list(set(app_codes + self.mock_system.process_dependency_agent.find_dependencies.return_value))
        self.mock_system.dr_plans_fetcher_agent.fetch_dr_plans.assert_called_once_with(all_app_codes)
        
        dr_plans = self.mock_system.dr_plans_fetcher_agent.fetch_dr_plans.return_value
        self.mock_system.description_analysis_agent.analyze_descriptions.assert_called_once_with(dr_plans)
        self.mock_system.tasks_analysis_agent.analyze_tasks.assert_called_once_with(dr_plans)
        self.mock_system.device_reconciliation_agent.reconcile_devices.assert_called_once_with(all_app_codes, dr_plans)
        self.mock_system.iipm_analysis_agent.analyze_app_details.assert_called_once_with(all_app_codes)
        
        self.mock_system.reasoning_agent.analyze_dr_readiness.assert_called_once()
        reasoning_input = self.mock_system.reasoning_agent.analyze_dr_readiness.call_args[0][0]
        self.assertEqual(reasoning_input["business_process"], business_process)
        self.assertEqual(reasoning_input["app_codes"], app_codes)
        self.assertEqual(reasoning_input["dependencies"], self.mock_system.process_dependency_agent.find_dependencies.return_value)
        self.assertEqual(reasoning_input["dr_plans"], dr_plans)
        
        self.assertEqual(result["overall_quality"], "Medium")
        self.assertEqual(result["dr_readiness_score"], 75)
        self.assertEqual(result["risk_level"], "Medium")
        self.assertEqual(len(result["risks"]), 2)
        self.assertEqual(len(result["recommendations"]), 2)
        self.assertFalse(result["rto_rpo_analysis"]["met"])
    
    @patch("src.utils.logging_utils.ElasticsearchHandler.emit")
    def test_elasticsearch_logging(self, mock_emit):
        """Test that Elasticsearch logging is used during analysis."""
        business_process = "Payment Processing"
        app_codes = ["APP001"]
        request_id = "test-request-id"
        
        with patch("src.utils.logging_utils.log_agent_interaction") as mock_log:
            self.mock_system.analyze_business_process(
                business_process=business_process,
                app_codes=app_codes,
                request_id=request_id
            )
            
            self.assertTrue(mock_log.called)
    
    def test_webrtc_updates(self):
        """Test that WebRTC updates are sent during analysis."""
        business_process = "Payment Processing"
        app_codes = ["APP001"]
        request_id = "test-request-id"
        
        with patch("src.utils.webrtc_utils.webrtc_manager.send_update") as mock_send_update:
            self.mock_system.analyze_business_process(
                business_process=business_process,
                app_codes=app_codes,
                request_id=request_id
            )
            
            self.assertTrue(mock_send_update.called)

if __name__ == "__main__":
    unittest.main()
