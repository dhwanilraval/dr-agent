"""
Tests for the Reasoning Agent.

This module contains tests for the Reasoning Agent and its interaction
with the outputs from all previous agents.
"""

import unittest
import os
from unittest.mock import patch, MagicMock
from datetime import datetime

from src.agents.reasoning.agent import ReasoningAgent
from src.models.data_models import DisasterRecoveryPlan, RecoveryTask, Device

class MockAssistantAgent:
    def __init__(self, name, system_message, llm_config):
        self.name = name
        self.system_message = system_message
        self.llm_config = llm_config
    
    def generate_reply(self, message):
        return {"content": "Mock reply from assistant agent", "role": "assistant"}

class TestReasoningAgent(unittest.TestCase):
    """Tests for the Reasoning Agent."""
    
    def setUp(self):
        """Set up the test environment."""
        os.environ["OPENAI_API_KEY"] = "test_api_key"
        
        with patch("autogen.AssistantAgent", MockAssistantAgent):
            self.agent = ReasoningAgent()
    
    def test_analyze_dr_readiness(self):
        """Test analyzing disaster recovery readiness."""
        process_dependency_data = {
            "data": {
                "app_codes": ["APP001", "APP002"],
                "dependent_app_codes": ["APP003", "APP004", "APP005", "APP006"]
            }
        }
        
        plans_data = {
            "data": {
                "plans": [
                    {
                        "id": "PLAN001",
                        "app_code": "APP001",
                        "name": "DR Plan for APP001",
                        "description": "Description for APP001",
                        "version": "1.0",
                        "created_at": datetime.now().isoformat(),
                        "updated_at": datetime.now().isoformat(),
                        "recovery_time_objective": 60,
                        "recovery_point_objective": 30,
                        "tasks": [
                            {
                                "id": "TASK001",
                                "name": "Task 1",
                                "description": "Task 1 description",
                                "sequence": 1,
                                "estimated_duration": 30,
                                "responsible_team": "IT Operations",
                                "dependencies": []
                            }
                        ],
                        "devices": [
                            {
                                "id": "DEV001",
                                "name": "Device 1",
                                "type": "Server",
                                "description": "Device 1 description",
                                "app_code": "APP001"
                            }
                        ]
                    },
                    {
                        "id": "PLAN002",
                        "app_code": "APP002",
                        "name": "DR Plan for APP002",
                        "description": "Description for APP002",
                        "version": "1.0",
                        "created_at": datetime.now().isoformat(),
                        "updated_at": datetime.now().isoformat(),
                        "recovery_time_objective": 120,
                        "recovery_point_objective": 60,
                        "tasks": [
                            {
                                "id": "TASK002",
                                "name": "Task 2",
                                "description": "Task 2 description",
                                "sequence": 1,
                                "estimated_duration": 45,
                                "responsible_team": "Database Team",
                                "dependencies": []
                            }
                        ],
                        "devices": [
                            {
                                "id": "DEV002",
                                "name": "Device 2",
                                "type": "Database",
                                "description": "Device 2 description",
                                "app_code": "APP002"
                            }
                        ]
                    }
                ]
            }
        }
        
        description_analysis_data = {
            "data": {
                "plan_count": 2,
                "avg_compliance_percentage": 75.0,
                "plan_analyses": {
                    "PLAN001": {
                        "plan_id": "PLAN001",
                        "app_code": "APP001",
                        "plan_name": "DR Plan for APP001",
                        "compliance_percentage": 80.0,
                        "gaps": ["Missing section X", "Incomplete section Y"],
                        "recommendations": ["Add section X", "Complete section Y"]
                    },
                    "PLAN002": {
                        "plan_id": "PLAN002",
                        "app_code": "APP002",
                        "plan_name": "DR Plan for APP002",
                        "compliance_percentage": 70.0,
                        "gaps": ["Missing section Z"],
                        "recommendations": ["Add section Z"]
                    }
                }
            }
        }
        
        tasks_analysis_data = {
            "data": {
                "plan_count": 2,
                "avg_compliance_percentage": 65.0,
                "plan_analyses": {
                    "PLAN001": {
                        "plan_id": "PLAN001",
                        "app_code": "APP001",
                        "plan_name": "DR Plan for APP001",
                        "compliance_percentage": 70.0,
                        "gaps": ["Missing task A", "Incomplete task B"],
                        "recommendations": ["Add task A", "Complete task B"]
                    },
                    "PLAN002": {
                        "plan_id": "PLAN002",
                        "app_code": "APP002",
                        "plan_name": "DR Plan for APP002",
                        "compliance_percentage": 60.0,
                        "gaps": ["Missing task C"],
                        "recommendations": ["Add task C"]
                    }
                }
            }
        }
        
        device_reconciliation_data = {
            "data": {
                "plan_count": 2,
                "total_matched_devices": 3,
                "total_missing_devices": 2,
                "total_extra_devices": 1,
                "avg_coverage_percentage": 60.0,
                "plan_analyses": {
                    "PLAN001": {
                        "plan_id": "PLAN001",
                        "app_code": "APP001",
                        "plan_name": "DR Plan for APP001",
                        "plan_device_count": 2,
                        "actual_device_count": 3,
                        "matched_device_count": 2,
                        "missing_device_count": 1,
                        "extra_device_count": 0,
                        "coverage_percentage": 66.67,
                        "matched_devices": [],
                        "missing_devices": [],
                        "extra_devices": [],
                        "recommendations": []
                    },
                    "PLAN002": {
                        "plan_id": "PLAN002",
                        "app_code": "APP002",
                        "plan_name": "DR Plan for APP002",
                        "plan_device_count": 2,
                        "actual_device_count": 3,
                        "matched_device_count": 1,
                        "missing_device_count": 1,
                        "extra_device_count": 1,
                        "coverage_percentage": 50.0,
                        "matched_devices": [],
                        "missing_devices": [],
                        "extra_devices": [],
                        "recommendations": []
                    }
                }
            }
        }
        
        iipm_analysis_data = {
            "data": {
                "total_app_count": 6,
                "rto_analysis": {
                    "categories": {
                        "critical": ["APP001", "APP004"],
                        "high": ["APP002", "APP005"],
                        "medium": ["APP003"],
                        "low": ["APP006"]
                    },
                    "min_rto": 30,
                    "min_rto_app": "APP004",
                    "max_rto": 1440,
                    "max_rto_app": "APP006"
                },
                "rpo_analysis": {
                    "categories": {
                        "critical": ["APP001", "APP004"],
                        "high": ["APP002", "APP005"],
                        "medium": ["APP003"],
                        "low": ["APP006"]
                    },
                    "min_rpo": 5,
                    "min_rpo_app": "APP004",
                    "max_rpo": 1440,
                    "max_rpo_app": "APP006"
                },
                "criticality_analysis": {
                    "categories": {
                        "Critical": ["APP001", "APP004"],
                        "High": ["APP002", "APP005"],
                        "Medium": ["APP003"],
                        "Low": ["APP006"]
                    }
                },
                "dr_test_analysis": {
                    "categories": {
                        "passed": ["APP001", "APP002"],
                        "partial": ["APP003"],
                        "failed": ["APP004"],
                        "not_tested": ["APP005", "APP006"]
                    },
                    "last_test_date": {
                        "APP001": "2023-12-15",
                        "APP002": "2023-11-20",
                        "APP003": "2023-10-05",
                        "APP004": "2023-09-10"
                    }
                },
                "app_details": {
                    "APP001": {
                        "app_code": "APP001",
                        "name": "Application 1",
                        "description": "This is a mock application 1 for testing purposes.",
                        "recovery_time_objective": 60,
                        "recovery_point_objective": 30,
                        "business_criticality": "Critical",
                        "owner": "John Smith",
                        "type": "Web Application",
                        "tech_stack": "Java/Spring",
                        "environment": "AWS Cloud",
                        "data_classification": "Confidential",
                        "support_team": "Application Team",
                        "support_hours": "24x7",
                        "last_dr_test_date": "2023-12-15",
                        "dr_test_result": "Passed",
                        "dependencies": ["APP003", "APP004"]
                    },
                    "APP002": {
                        "app_code": "APP002",
                        "name": "Application 2",
                        "description": "This is a mock application 2 for testing purposes.",
                        "recovery_time_objective": 120,
                        "recovery_point_objective": 60,
                        "business_criticality": "High",
                        "owner": "Jane Doe",
                        "type": "Database",
                        "tech_stack": "Oracle/PL-SQL",
                        "environment": "On-premises",
                        "data_classification": "Restricted",
                        "support_team": "Database Team",
                        "support_hours": "24x7",
                        "last_dr_test_date": "2023-11-20",
                        "dr_test_result": "Passed",
                        "dependencies": ["APP005"]
                    },
                    "APP003": {
                        "app_code": "APP003",
                        "name": "Application 3",
                        "description": "This is a mock application 3 for testing purposes.",
                        "recovery_time_objective": 240,
                        "recovery_point_objective": 120,
                        "business_criticality": "Medium",
                        "owner": "Michael Johnson",
                        "type": "Middleware",
                        "tech_stack": "Node.js/Express",
                        "environment": "Azure Cloud",
                        "data_classification": "Internal",
                        "support_team": "Middleware Team",
                        "support_hours": "16x7",
                        "last_dr_test_date": "2023-10-05",
                        "dr_test_result": "Partial Success",
                        "dependencies": []
                    },
                    "APP004": {
                        "app_code": "APP004",
                        "name": "Application 4",
                        "description": "This is a mock application 4 for testing purposes.",
                        "recovery_time_objective": 30,
                        "recovery_point_objective": 5,
                        "business_criticality": "Critical",
                        "owner": "Emily Williams",
                        "type": "API Service",
                        "tech_stack": "Python/Django",
                        "environment": "Google Cloud",
                        "data_classification": "Confidential",
                        "support_team": "API Team",
                        "support_hours": "24x7",
                        "last_dr_test_date": "2023-09-10",
                        "dr_test_result": "Failed",
                        "dependencies": []
                    },
                    "APP005": {
                        "app_code": "APP005",
                        "name": "Application 5",
                        "description": "This is a mock application 5 for testing purposes.",
                        "recovery_time_objective": 480,
                        "recovery_point_objective": 240,
                        "business_criticality": "High",
                        "owner": "Robert Brown",
                        "type": "Batch Processing",
                        "tech_stack": ".NET/C#",
                        "environment": "Hybrid Cloud",
                        "data_classification": "Internal",
                        "support_team": "Batch Team",
                        "support_hours": "8x5",
                        "last_dr_test_date": None,
                        "dr_test_result": None,
                        "dependencies": []
                    },
                    "APP006": {
                        "app_code": "APP006",
                        "name": "Application 6",
                        "description": "This is a mock application 6 for testing purposes.",
                        "recovery_time_objective": 1440,
                        "recovery_point_objective": 1440,
                        "business_criticality": "Low",
                        "owner": "Sarah Davis",
                        "type": "Data Warehouse",
                        "tech_stack": "Python/Django",
                        "environment": "AWS Cloud",
                        "data_classification": "Internal",
                        "support_team": "Data Team",
                        "support_hours": "8x5",
                        "last_dr_test_date": None,
                        "dr_test_result": None,
                        "dependencies": []
                    }
                },
                "recommendations": [
                    "Critical: Application APP004 failed its last DR test but has a critical business criticality. Schedule a new DR test as soon as possible.",
                    "Warning: Applications APP005 and APP006 have never been tested for DR. Schedule DR tests for these applications.",
                    "Warning: Application APP001 depends on APP004 which has a failed DR test. This creates a risk for APP001's DR capability."
                ]
            }
        }
        
        message = {
            "process_dependency_data": process_dependency_data,
            "plans_data": plans_data,
            "description_analysis_data": description_analysis_data,
            "tasks_analysis_data": tasks_analysis_data,
            "device_reconciliation_data": device_reconciliation_data,
            "iipm_analysis_data": iipm_analysis_data
        }
        
        result = self.agent.analyze_dr_readiness(message)
        
        self.assertEqual(result["status"], "success")
        self.assertIn("data", result)
        
        data = result["data"]
        self.assertIn("dr_readiness_score", data)
        self.assertIn("risk_assessment", data)
        self.assertIn("rto_rpo_analysis", data)
        self.assertIn("findings_recommendations", data)
        
        dr_readiness_score = data["dr_readiness_score"]
        self.assertIn("overall_score", dr_readiness_score)
        self.assertIn("description_score", dr_readiness_score)
        self.assertIn("tasks_score", dr_readiness_score)
        self.assertIn("device_score", dr_readiness_score)
        self.assertIn("testing_score", dr_readiness_score)
        
        risk_assessment = data["risk_assessment"]
        self.assertIn("overall_risk", risk_assessment)
        self.assertIn("risk_counts", risk_assessment)
        self.assertIn("risks", risk_assessment)
        
        rto_rpo_analysis = data["rto_rpo_analysis"]
        self.assertIn("primary_apps", rto_rpo_analysis)
        self.assertIn("dependent_apps", rto_rpo_analysis)
        self.assertIn("rto_conflicts", rto_rpo_analysis)
        self.assertIn("rpo_conflicts", rto_rpo_analysis)
        self.assertIn("overall_achievable_rto", rto_rpo_analysis)
        self.assertIn("overall_achievable_rpo", rto_rpo_analysis)
        
        findings_recommendations = data["findings_recommendations"]
        self.assertIn("findings", findings_recommendations)
        self.assertIn("recommendations", findings_recommendations)
        
        self.assertGreater(len(findings_recommendations["findings"]), 0)
        self.assertGreater(len(findings_recommendations["recommendations"]), 0)
    
    def test_process_message(self):
        """Test processing a message from another agent."""
        message = {
            "process_dependency_data": {
                "data": {
                    "app_codes": ["APP001", "APP002"],
                    "dependent_app_codes": ["APP003", "APP004"]
                }
            },
            "plans_data": {
                "data": {
                    "plans": [
                        {
                            "id": "PLAN001",
                            "app_code": "APP001",
                            "name": "DR Plan for APP001",
                            "description": "Description for APP001",
                            "version": "1.0",
                            "created_at": datetime.now().isoformat(),
                            "updated_at": datetime.now().isoformat(),
                            "recovery_time_objective": 60,
                            "recovery_point_objective": 30,
                            "tasks": [],
                            "devices": []
                        }
                    ]
                }
            },
            "description_analysis_data": {
                "data": {
                    "plan_count": 1,
                    "avg_compliance_percentage": 75.0,
                    "plan_analyses": {
                        "PLAN001": {
                            "plan_id": "PLAN001",
                            "app_code": "APP001",
                            "plan_name": "DR Plan for APP001",
                            "compliance_percentage": 75.0,
                            "gaps": [],
                            "recommendations": []
                        }
                    }
                }
            }
        }
        
        self.agent.analyze_dr_readiness = MagicMock(return_value={
            "status": "success",
            "data": {
                "dr_readiness_score": {
                    "overall_score": 65.0,
                    "description_score": 18.75,
                    "tasks_score": 16.25,
                    "device_score": 15.0,
                    "testing_score": 15.0
                },
                "risk_assessment": {
                    "overall_risk": "High",
                    "risk_counts": {
                        "Critical": 1,
                        "High": 2,
                        "Medium": 1,
                        "Low": 0
                    },
                    "risks": []
                },
                "rto_rpo_analysis": {
                    "primary_apps": {},
                    "dependent_apps": {},
                    "rto_conflicts": [],
                    "rpo_conflicts": [],
                    "overall_achievable_rto": None,
                    "overall_achievable_rpo": None
                },
                "findings_recommendations": {
                    "findings": [],
                    "recommendations": []
                }
            }
        })
        
        result = self.agent.process_message(message)
        
        self.assertEqual(result["status"], "success")
        self.assertIn("data", result)
        
        self.agent.analyze_dr_readiness.assert_called_once_with(message)
    
    def test_process_message_no_inputs(self):
        """Test processing a message with no agent inputs."""
        message = {}
        
        result = self.agent.process_message(message)
        
        self.assertEqual(result["status"], "error")
        self.assertIn("message", result)
    
    def test_process_message_error(self):
        """Test processing a message when an error occurs."""
        message = {
            "process_dependency_data": {
                "data": {
                    "app_codes": ["APP001", "APP002"],
                    "dependent_app_codes": ["APP003", "APP004"]
                }
            }
        }
        
        self.agent.analyze_dr_readiness = MagicMock(side_effect=Exception("Test error"))
        
        result = self.agent.process_message(message)
        
        self.assertEqual(result["status"], "error")
        self.assertIn("message", result)
        
        self.agent.analyze_dr_readiness.assert_called_once_with(message)
    
    def test_generate_reply(self):
        """Test generating a reply using the AG2 agent."""
        message = {
            "process_dependency_data": {
                "data": {
                    "app_codes": ["APP001", "APP002"],
                    "dependent_app_codes": ["APP003", "APP004"]
                }
            }
        }
        
        self.agent.process_message = MagicMock(return_value={
            "status": "success",
            "message": "Analyzed disaster recovery readiness",
            "data": {
                "dr_readiness_score": {
                    "overall_score": 65.0,
                    "description_score": 18.75,
                    "tasks_score": 16.25,
                    "device_score": 15.0,
                    "testing_score": 15.0
                },
                "risk_assessment": {
                    "overall_risk": "High",
                    "risk_counts": {
                        "Critical": 1,
                        "High": 2,
                        "Medium": 1,
                        "Low": 0
                    },
                    "risks": []
                },
                "rto_rpo_analysis": {
                    "primary_apps": {},
                    "dependent_apps": {},
                    "rto_conflicts": [],
                    "rpo_conflicts": [],
                    "overall_achievable_rto": 240,
                    "overall_achievable_rpo": 120
                },
                "findings_recommendations": {
                    "findings": [],
                    "recommendations": []
                }
            }
        })
        
        result = self.agent.generate_reply(message)
        
        self.assertIn("content", result)
        self.assertIn("reasoning_data", result)
        
        self.agent.process_message.assert_called_once_with(message)

if __name__ == "__main__":
    unittest.main()
