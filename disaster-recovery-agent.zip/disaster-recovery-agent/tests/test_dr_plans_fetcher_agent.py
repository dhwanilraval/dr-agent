"""
Tests for the DR Plans Fetcher Agent.

This module contains tests for the DR Plans Fetcher Agent and its interaction
with the Postgres API.
"""

import unittest
import os
from unittest.mock import patch, MagicMock
from datetime import datetime

from src.agents.dr_plans_fetcher.agent import DRPlansFetcherAgent
from src.mock_apis.postgres.api import MockPostgresAPI
from src.models.data_models import DisasterRecoveryPlan, RecoveryTask, Device

class MockAssistantAgent:
    def __init__(self, name, system_message, llm_config):
        self.name = name
        self.system_message = system_message
        self.llm_config = llm_config
    
    def generate_reply(self, message):
        return {"content": "Mock reply from assistant agent", "role": "assistant"}

class TestDRPlansFetcherAgent(unittest.TestCase):
    """Tests for the DR Plans Fetcher Agent."""
    
    def setUp(self):
        """Set up the test environment."""
        os.environ["OPENAI_API_KEY"] = "test_api_key"
        
        self.mock_postgres_api = MagicMock(spec=MockPostgresAPI)
        
        with patch("autogen.AssistantAgent", MockAssistantAgent):
            self.agent = DRPlansFetcherAgent()
            self.agent.postgres_api = self.mock_postgres_api
    
    def test_fetch_plans(self):
        """Test fetching plans for application codes."""
        app_codes = ["APP001", "APP002"]
        
        plan1 = DisasterRecoveryPlan(
            id="PLAN001",
            app_code="APP001",
            name="DR Plan for APP001",
            description="Description for APP001",
            version="1.0",
            created_at=datetime.now(),
            updated_at=datetime.now(),
            recovery_time_objective=60,
            recovery_point_objective=30,
            tasks=[
                RecoveryTask(
                    id="TASK001",
                    name="Task 1",
                    description="Task 1 description",
                    sequence=1,
                    estimated_duration=30,
                    responsible_team="IT Operations",
                    dependencies=[]
                )
            ],
            devices=[
                Device(
                    id="DEV001",
                    name="Device 1",
                    type="Server",
                    description="Device 1 description",
                    app_code="APP001"
                )
            ]
        )
        
        plan2 = DisasterRecoveryPlan(
            id="PLAN002",
            app_code="APP002",
            name="DR Plan for APP002",
            description="Description for APP002",
            version="1.0",
            created_at=datetime.now(),
            updated_at=datetime.now(),
            recovery_time_objective=120,
            recovery_point_objective=60,
            tasks=[
                RecoveryTask(
                    id="TASK002",
                    name="Task 2",
                    description="Task 2 description",
                    sequence=1,
                    estimated_duration=45,
                    responsible_team="Database Team",
                    dependencies=[]
                )
            ],
            devices=[
                Device(
                    id="DEV002",
                    name="Device 2",
                    type="Database",
                    description="Device 2 description",
                    app_code="APP002"
                )
            ]
        )
        
        self.mock_postgres_api.get_plans_for_app_codes.return_value = [plan1, plan2]
        
        result = self.agent.fetch_plans(app_codes)
        
        self.assertEqual(result["app_codes"], app_codes)
        self.assertEqual(result["plan_count"], 2)
        self.assertEqual(len(result["plans"]), 2)
        
        self.mock_postgres_api.get_plans_for_app_codes.assert_called_once_with(app_codes)
    
    def test_process_message_with_app_codes(self):
        """Test processing a message with application codes."""
        message = {
            "app_codes": ["APP001", "APP002"]
        }
        
        self.agent.fetch_plans = MagicMock(return_value={
            "app_codes": ["APP001", "APP002"],
            "plans": [{"id": "PLAN001"}, {"id": "PLAN002"}],
            "plan_count": 2
        })
        
        result = self.agent.process_message(message)
        
        self.assertEqual(result["status"], "success")
        self.assertIn("data", result)
        
        self.agent.fetch_plans.assert_called_once_with(["APP001", "APP002"])
    
    def test_process_message_with_dependencies_data(self):
        """Test processing a message with dependencies data from the Process Dependency Agent."""
        message = {
            "dependencies_data": {
                "data": {
                    "all_app_codes": ["APP001", "APP002", "APP003"]
                }
            }
        }
        
        self.agent.fetch_plans = MagicMock(return_value={
            "app_codes": ["APP001", "APP002", "APP003"],
            "plans": [{"id": "PLAN001"}, {"id": "PLAN002"}, {"id": "PLAN003"}],
            "plan_count": 3
        })
        
        result = self.agent.process_message(message)
        
        self.assertEqual(result["status"], "success")
        self.assertIn("data", result)
        
        self.agent.fetch_plans.assert_called_once_with(["APP001", "APP002", "APP003"])
    
    def test_process_message_no_app_codes(self):
        """Test processing a message with no application codes."""
        message = {}
        
        original_fetch_plans = self.agent.fetch_plans
        self.agent.fetch_plans = MagicMock()
        
        try:
            result = self.agent.process_message(message)
            
            self.assertEqual(result["status"], "error")
            self.assertIn("message", result)
            
            self.agent.fetch_plans.assert_not_called()
        finally:
            self.agent.fetch_plans = original_fetch_plans
    
    def test_process_message_error(self):
        """Test processing a message when an error occurs."""
        message = {
            "app_codes": ["APP001", "APP002"]
        }
        
        self.agent.fetch_plans = MagicMock(side_effect=Exception("Test error"))
        
        result = self.agent.process_message(message)
        
        self.assertEqual(result["status"], "error")
        self.assertIn("message", result)
        
        self.agent.fetch_plans.assert_called_once_with(["APP001", "APP002"])

if __name__ == "__main__":
    unittest.main()
