"""
Tests for the Device Reconciliation Agent.

This module contains tests for the Device Reconciliation Agent and its interaction
with the Postgres API.
"""

import unittest
import os
from unittest.mock import patch, MagicMock
from datetime import datetime

from src.agents.device_reconciliation.agent import DeviceReconciliationAgent
from src.mock_apis.postgres.api import MockPostgresAPI
from src.models.data_models import DisasterRecoveryPlan, RecoveryTask, Device

class MockAssistantAgent:
    def __init__(self, name, system_message, llm_config):
        self.name = name
        self.system_message = system_message
        self.llm_config = llm_config
    
    def generate_reply(self, message):
        return {"content": "Mock reply from assistant agent", "role": "assistant"}

class TestDeviceReconciliationAgent(unittest.TestCase):
    """Tests for the Device Reconciliation Agent."""
    
    def setUp(self):
        """Set up the test environment."""
        os.environ["OPENAI_API_KEY"] = "test_api_key"
        
        self.mock_postgres_api = MagicMock(spec=MockPostgresAPI)
        
        with patch("autogen.AssistantAgent", MockAssistantAgent):
            self.agent = DeviceReconciliationAgent()
            self.agent.postgres_api = self.mock_postgres_api
    
    def test_reconcile_devices(self):
        """Test reconciling devices in plans with actual devices."""
        plan1_devices = [
            Device(
                id="DEV001",
                name="Device 1",
                type="Server",
                description="Device 1 description",
                app_code="APP001"
            ),
            Device(
                id="DEV002",
                name="Device 2",
                type="Database",
                description="Device 2 description",
                app_code="APP001"
            ),
            Device(
                id="DEV003",
                name="Device 3",
                type="Network",
                description="Device 3 description",
                app_code="APP001"
            )
        ]
        
        plan1 = DisasterRecoveryPlan(
            id="PLAN001",
            app_code="APP001",
            name="DR Plan for APP001",
            description="Description for APP001",
            version="1.0",
            created_at=datetime.now(),
            updated_at=datetime.now(),
            recovery_time_objective=60,
            recovery_point_objective=30,
            tasks=[
                RecoveryTask(
                    id="TASK001",
                    name="Task 1",
                    description="Task 1 description",
                    sequence=1,
                    estimated_duration=30,
                    responsible_team="IT Operations",
                    dependencies=[]
                )
            ],
            devices=plan1_devices
        )
        
        plan2_devices = [
            Device(
                id="DEV004",
                name="Device 4",
                type="Server",
                description="Device 4 description",
                app_code="APP002"
            ),
            Device(
                id="DEV005",
                name="Device 5",
                type="Storage",
                description="Device 5 description",
                app_code="APP002"
            )
        ]
        
        plan2 = DisasterRecoveryPlan(
            id="PLAN002",
            app_code="APP002",
            name="DR Plan for APP002",
            description="Description for APP002",
            version="1.0",
            created_at=datetime.now(),
            updated_at=datetime.now(),
            recovery_time_objective=120,
            recovery_point_objective=60,
            tasks=[
                RecoveryTask(
                    id="TASK002",
                    name="Task 2",
                    description="Task 2 description",
                    sequence=1,
                    estimated_duration=45,
                    responsible_team="Database Team",
                    dependencies=[]
                )
            ],
            devices=plan2_devices
        )
        
        plans = [plan1, plan2]
        
        actual_devices_app1 = [
            Device(
                id="DEV001",  # Matched
                name="Device 1",
                type="Server",
                description="Device 1 description",
                app_code="APP001"
            ),
            Device(
                id="DEV002",  # Matched
                name="Device 2",
                type="Database",
                description="Device 2 description",
                app_code="APP001"
            ),
            Device(
                id="DEV006",  # Missing from plan
                name="Device 6",
                type="Server",
                description="Device 6 description",
                app_code="APP001"
            )
        ]
        
        actual_devices_app2 = [
            Device(
                id="DEV004",  # Matched
                name="Device 4",
                type="Server",
                description="Device 4 description",
                app_code="APP002"
            ),
            Device(
                id="DEV007",  # Missing from plan
                name="Device 7",
                type="Network",
                description="Device 7 description",
                app_code="APP002"
            ),
            Device(
                id="DEV008",  # Missing from plan
                name="Device 8",
                type="Database",
                description="Device 8 description",
                app_code="APP002"
            )
        ]
        
        self.mock_postgres_api.get_actual_devices_for_apps.return_value = {
            "APP001": actual_devices_app1,
            "APP002": actual_devices_app2
        }
        
        result = self.agent.reconcile_devices(plans)
        
        self.assertEqual(result["status"], "success")
        self.assertEqual(result["data"]["plan_count"], 2)
        self.assertEqual(result["data"]["total_matched_devices"], 3)  # 2 from plan1, 1 from plan2
        self.assertEqual(result["data"]["total_missing_devices"], 3)  # 1 from app1, 2 from app2
        self.assertEqual(result["data"]["total_extra_devices"], 2)  # 1 from plan1, 1 from plan2
        
        plan1_analysis = result["data"]["plan_analyses"]["PLAN001"]
        self.assertEqual(plan1_analysis["plan_id"], "PLAN001")
        self.assertEqual(plan1_analysis["app_code"], "APP001")
        self.assertEqual(plan1_analysis["plan_device_count"], 3)
        self.assertEqual(plan1_analysis["actual_device_count"], 3)
        self.assertEqual(plan1_analysis["matched_device_count"], 2)
        self.assertEqual(plan1_analysis["missing_device_count"], 1)
        self.assertEqual(plan1_analysis["extra_device_count"], 1)
        self.assertAlmostEqual(plan1_analysis["coverage_percentage"], 66.67, places=2)
        
        plan2_analysis = result["data"]["plan_analyses"]["PLAN002"]
        self.assertEqual(plan2_analysis["plan_id"], "PLAN002")
        self.assertEqual(plan2_analysis["app_code"], "APP002")
        self.assertEqual(plan2_analysis["plan_device_count"], 2)
        self.assertEqual(plan2_analysis["actual_device_count"], 3)
        self.assertEqual(plan2_analysis["matched_device_count"], 1)
        self.assertEqual(plan2_analysis["missing_device_count"], 2)
        self.assertEqual(plan2_analysis["extra_device_count"], 1)
        self.assertAlmostEqual(plan2_analysis["coverage_percentage"], 33.33, places=2)
        
        self.mock_postgres_api.get_actual_devices_for_apps.assert_called_once_with(["APP001", "APP002"])
    
    def test_process_message_with_plans_data(self):
        """Test processing a message with plans data from the DR Plans Fetcher Agent."""
        plans_data = {
            "plans_data": {
                "data": {
                    "plans": [
                        {
                            "id": "PLAN001",
                            "app_code": "APP001",
                            "name": "DR Plan for APP001",
                            "description": "Description for APP001",
                            "version": "1.0",
                            "created_at": datetime.now().isoformat(),
                            "updated_at": datetime.now().isoformat(),
                            "recovery_time_objective": 60,
                            "recovery_point_objective": 30,
                            "tasks": [
                                {
                                    "id": "TASK001",
                                    "name": "Task 1",
                                    "description": "Task 1 description",
                                    "sequence": 1,
                                    "estimated_duration": 30,
                                    "responsible_team": "IT Operations",
                                    "dependencies": []
                                }
                            ],
                            "devices": [
                                {
                                    "id": "DEV001",
                                    "name": "Device 1",
                                    "type": "Server",
                                    "description": "Device 1 description",
                                    "app_code": "APP001"
                                }
                            ]
                        }
                    ]
                }
            }
        }
        
        self.agent.reconcile_devices = MagicMock(return_value={
            "status": "success",
            "data": {
                "plan_count": 1,
                "total_matched_devices": 1,
                "total_missing_devices": 1,
                "total_extra_devices": 0,
                "avg_coverage_percentage": 50.0,
                "plan_analyses": {
                    "PLAN001": {
                        "plan_id": "PLAN001",
                        "app_code": "APP001",
                        "plan_name": "DR Plan for APP001",
                        "plan_device_count": 1,
                        "actual_device_count": 2,
                        "matched_device_count": 1,
                        "missing_device_count": 1,
                        "extra_device_count": 0,
                        "coverage_percentage": 50.0,
                        "matched_devices": [],
                        "missing_devices": [],
                        "extra_devices": [],
                        "recommendations": []
                    }
                }
            }
        })
        
        result = self.agent.process_message(plans_data)
        
        self.assertEqual(result["status"], "success")
        self.assertIn("data", result)
        
        self.agent.reconcile_devices.assert_called_once()
        self.assertEqual(len(self.agent.reconcile_devices.call_args[0][0]), 1)
    
    def test_process_message_no_plans(self):
        """Test processing a message with no plans."""
        message = {}
        
        original_reconcile_devices = self.agent.reconcile_devices
        self.agent.reconcile_devices = MagicMock()
        
        try:
            result = self.agent.process_message(message)
            
            self.assertEqual(result["status"], "error")
            self.assertIn("message", result)
            
            self.agent.reconcile_devices.assert_not_called()
        finally:
            self.agent.reconcile_devices = original_reconcile_devices
    
    def test_process_message_error(self):
        """Test processing a message when an error occurs."""
        plans_data = {
            "plans_data": {
                "data": {
                    "plans": [
                        {
                            "id": "PLAN001",
                            "app_code": "APP001",
                            "name": "DR Plan for APP001",
                            "description": "Description for APP001",
                            "version": "1.0",
                            "created_at": datetime.now().isoformat(),
                            "updated_at": datetime.now().isoformat(),
                            "recovery_time_objective": 60,
                            "recovery_point_objective": 30,
                            "tasks": [],
                            "devices": []
                        }
                    ]
                }
            }
        }
        
        self.agent.reconcile_devices = MagicMock(side_effect=Exception("Test error"))
        
        result = self.agent.process_message(plans_data)
        
        self.assertEqual(result["status"], "error")
        self.assertIn("message", result)
        
        self.agent.reconcile_devices.assert_called_once()

if __name__ == "__main__":
    unittest.main()
