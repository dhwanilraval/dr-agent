"""
Test for Elasticsearch logging functionality.

This module tests the Elasticsearch logging implementation to ensure
it correctly captures agent interactions.
"""

import unittest
import logging
from unittest.mock import patch, MagicMock

from src.utils.logging_utils import setup_elasticsearch_logging, log_agent_interaction, ElasticsearchHandler


class TestElasticsearchLogging(unittest.TestCase):
    """Test the Elasticsearch logging functionality."""
    
    def setUp(self):
        """Set up the test environment."""
        logging.basicConfig(level=logging.INFO)
        
        self.mock_handler = MagicMock(spec=ElasticsearchHandler)
        self.mock_handler.emit = MagicMock()
        self.mock_handler.level = logging.INFO  # Add the level attribute
        
        self.original_handlers = logging.getLogger().handlers.copy()
        
        logging.getLogger().addHandler(self.mock_handler)
    
    def tearDown(self):
        """Clean up after the test."""
        logging.getLogger().handlers = self.original_handlers
    
    def test_log_agent_interaction(self):
        """Test that agent interactions are properly logged."""
        agent_name = "test_agent"
        message = "Test agent interaction"
        request_id = "test-request-123"
        workflow_step = "test_step"
        agent_data = {"test_key": "test_value"}
        agent_message = {"content": "Test message content"}
        
        agent_logger = logging.getLogger(f"agent.{agent_name}")
        agent_logger.addHandler(self.mock_handler)
        
        log_agent_interaction(
            agent_name=agent_name,
            message=message,
            request_id=request_id,
            workflow_step=workflow_step,
            agent_data=agent_data,
            agent_message=agent_message
        )
        
        self.assertTrue(self.mock_handler.emit.called)
        
        log_record = self.mock_handler.emit.call_args[0][0]
        
        self.assertEqual(log_record.name, f"agent.{agent_name}")
        self.assertEqual(log_record.msg, message)
        self.assertEqual(log_record.request_id, request_id)
        self.assertEqual(log_record.workflow_step, workflow_step)
        self.assertEqual(log_record.agent_data, agent_data)
        self.assertEqual(log_record.agent_message, agent_message)
    
    @patch("src.utils.logging_utils.MockElasticsearchClient")
    def test_elasticsearch_handler(self, MockElasticsearchClient):
        """Test that the ElasticsearchHandler correctly formats and sends log entries."""
        mock_client = MagicMock()
        mock_client.index = MagicMock()
        MockElasticsearchClient.return_value = mock_client
        
        handler = ElasticsearchHandler()
        
        logger = logging.getLogger("test_logger")
        record = logger.makeRecord(
            name="test_logger",
            level=logging.INFO,
            fn="",
            lno=0,
            msg="Test message",
            args=(),
            exc_info=None,
            extra={
                'agent_data': {"test_key": "test_value"},
                'request_id': "test-request-123",
                'workflow_step': "test_step",
                'agent_message': {"content": "Test message content"}
            }
        )
        
        handler.emit(record)
        
        self.assertTrue(mock_client.index.called)
        
        document = mock_client.index.call_args[1]["document"]
        
        self.assertEqual(document["message"], "Test message")
        self.assertEqual(document["level"], "INFO")
        self.assertEqual(document["logger"], "test_logger")
        self.assertEqual(document["agent_data"], {"test_key": "test_value"})
        self.assertEqual(document["request_id"], "test-request-123")
        self.assertEqual(document["workflow_step"], "test_step")
        self.assertEqual(document["agent_message"], {"content": "Test message content"})


if __name__ == "__main__":
    unittest.main()
