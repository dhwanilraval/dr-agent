import markdown2
import os

# Create static directory if it doesn't exist
os.makedirs('static', exist_ok=True)

# Create index.html
with open('static/index.html', 'w') as f:
    f.write('''<!DOCTYPE html>
<html>
<head>
    <title>Disaster Recovery Compliance Agent System Whitepaper</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
            line-height: 1.6;
            color: #333;
            max-width: 900px;
            margin: 0 auto;
            padding: 20px;
        }
        h1, h2, h3, h4, h5, h6 {
            margin-top: 24px;
            margin-bottom: 16px;
            font-weight: 600;
            line-height: 1.25;
        }
        h1 {
            font-size: 2em;
            border-bottom: 1px solid #eaecef;
            padding-bottom: .3em;
        }
        h2 {
            font-size: 1.5em;
            border-bottom: 1px solid #eaecef;
            padding-bottom: .3em;
        }
        pre {
            background-color: #f6f8fa;
            border-radius: 3px;
            padding: 16px;
            overflow: auto;
        }
        code {
            background-color: rgba(27,31,35,.05);
            border-radius: 3px;
            font-family: "SFMono-Regular", Consolas, "Liberation Mono", Menlo, monospace;
            font-size: 85%;
            padding: 0.2em 0.4em;
        }
        pre code {
            background-color: transparent;
            padding: 0;
        }
        blockquote {
            border-left: 4px solid #dfe2e5;
            color: #6a737d;
            padding: 0 1em;
            margin: 0;
        }
        table {
            border-collapse: collapse;
            width: 100%;
            margin: 16px 0;
        }
        table th, table td {
            border: 1px solid #dfe2e5;
            padding: 6px 13px;
        }
        table tr {
            background-color: #fff;
            border-top: 1px solid #c6cbd1;
        }
        table tr:nth-child(2n) {
            background-color: #f6f8fa;
        }
        .version-selector {
            margin-bottom: 30px;
            padding: 10px;
            background-color: #f1f1f1;
            border-radius: 5px;
        }
        .version-selector a {
            margin: 0 10px;
            text-decoration: none;
            color: #0366d6;
            font-weight: bold;
        }
        .version-selector a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="version-selector">
        <a href="original.html">Original Whitepaper</a> | 
        <a href="v2.html">Whitepaper v2 (with Diagrams)</a>
    </div>
    <h1>Disaster Recovery Compliance Agent System Whitepaper</h1>
    <p>Please select a version of the whitepaper from the links above.</p>
</body>
</html>''')

# Convert README.md to original.html
with open('README.md', 'r') as f:
    readme_content = f.read()

html_content = markdown2.markdown(readme_content, extras=['tables', 'fenced-code-blocks'])

with open('static/original.html', 'w') as f:
    f.write('''<!DOCTYPE html>
<html>
<head>
    <title>Disaster Recovery Compliance Agent System Whitepaper</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
            line-height: 1.6;
            color: #333;
            max-width: 900px;
            margin: 0 auto;
            padding: 20px;
        }
        h1, h2, h3, h4, h5, h6 {
            margin-top: 24px;
            margin-bottom: 16px;
            font-weight: 600;
            line-height: 1.25;
        }
        h1 {
            font-size: 2em;
            border-bottom: 1px solid #eaecef;
            padding-bottom: .3em;
        }
        h2 {
            font-size: 1.5em;
            border-bottom: 1px solid #eaecef;
            padding-bottom: .3em;
        }
        pre {
            background-color: #f6f8fa;
            border-radius: 3px;
            padding: 16px;
            overflow: auto;
        }
        code {
            background-color: rgba(27,31,35,.05);
            border-radius: 3px;
            font-family: "SFMono-Regular", Consolas, "Liberation Mono", Menlo, monospace;
            font-size: 85%;
            padding: 0.2em 0.4em;
        }
        pre code {
            background-color: transparent;
            padding: 0;
        }
        blockquote {
            border-left: 4px solid #dfe2e5;
            color: #6a737d;
            padding: 0 1em;
            margin: 0;
        }
        table {
            border-collapse: collapse;
            width: 100%;
            margin: 16px 0;
        }
        table th, table td {
            border: 1px solid #dfe2e5;
            padding: 6px 13px;
        }
        table tr {
            background-color: #fff;
            border-top: 1px solid #c6cbd1;
        }
        table tr:nth-child(2n) {
            background-color: #f6f8fa;
        }
        .version-selector {
            margin-bottom: 30px;
            padding: 10px;
            background-color: #f1f1f1;
            border-radius: 5px;
        }
        .version-selector a {
            margin: 0 10px;
            text-decoration: none;
            color: #0366d6;
            font-weight: bold;
        }
        .version-selector a:hover {
            text-decoration: underline;
        }
        .version-selector .active {
            color: #24292e;
            cursor: default;
        }
        .version-selector .active:hover {
            text-decoration: none;
        }
    </style>
</head>
<body>
    <div class="version-selector">
        <a href="original.html" class="active">Original Whitepaper</a> | 
        <a href="v2.html">Whitepaper v2 (with Diagrams)</a>
    </div>
''' + html_content + '''
</body>
</html>''')

# Convert README_v2.md to v2.html
with open('README_v2.md', 'r') as f:
    readme_v2_content = f.read()

html_v2_content = markdown2.markdown(readme_v2_content, extras=['tables', 'fenced-code-blocks'])

with open('static/v2.html', 'w') as f:
    f.write('''<!DOCTYPE html>
<html>
<head>
    <title>Disaster Recovery Compliance Agent System Whitepaper v2</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
            line-height: 1.6;
            color: #333;
            max-width: 900px;
            margin: 0 auto;
            padding: 20px;
        }
        h1, h2, h3, h4, h5, h6 {
            margin-top: 24px;
            margin-bottom: 16px;
            font-weight: 600;
            line-height: 1.25;
        }
        h1 {
            font-size: 2em;
            border-bottom: 1px solid #eaecef;
            padding-bottom: .3em;
        }
        h2 {
            font-size: 1.5em;
            border-bottom: 1px solid #eaecef;
            padding-bottom: .3em;
        }
        pre {
            background-color: #f6f8fa;
            border-radius: 3px;
            padding: 16px;
            overflow: auto;
        }
        code {
            background-color: rgba(27,31,35,.05);
            border-radius: 3px;
            font-family: "SFMono-Regular", Consolas, "Liberation Mono", Menlo, monospace;
            font-size: 85%;
            padding: 0.2em 0.4em;
        }
        pre code {
            background-color: transparent;
            padding: 0;
        }
        blockquote {
            border-left: 4px solid #dfe2e5;
            color: #6a737d;
            padding: 0 1em;
            margin: 0;
        }
        table {
            border-collapse: collapse;
            width: 100%;
            margin: 16px 0;
        }
        table th, table td {
            border: 1px solid #dfe2e5;
            padding: 6px 13px;
        }
        table tr {
            background-color: #fff;
            border-top: 1px solid #c6cbd1;
        }
        table tr:nth-child(2n) {
            background-color: #f6f8fa;
        }
        .version-selector {
            margin-bottom: 30px;
            padding: 10px;
            background-color: #f1f1f1;
            border-radius: 5px;
        }
        .version-selector a {
            margin: 0 10px;
            text-decoration: none;
            color: #0366d6;
            font-weight: bold;
        }
        .version-selector a:hover {
            text-decoration: underline;
        }
        .version-selector .active {
            color: #24292e;
            cursor: default;
        }
        .version-selector .active:hover {
            text-decoration: none;
        }
    </style>
</head>
<body>
    <div class="version-selector">
        <a href="original.html">Original Whitepaper</a> | 
        <a href="v2.html" class="active">Whitepaper v2 (with Diagrams)</a>
    </div>
''' + html_v2_content + '''
</body>
</html>''')

print('Static HTML files created successfully in the static directory.')
