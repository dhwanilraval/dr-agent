from flask import Flask, send_from_directory, redirect
import os

app = Flask(__name__)

@app.route('/')
def index():
    return send_from_directory('static', 'index.html')

@app.route('/<path:filename>')
def serve_static(filename):
    return send_from_directory('static', filename)

@app.route('/health')
def health():
    return {"status": "healthy"}

if __name__ == '__main__':
    print("Current working directory:", os.getcwd())
    print("Static files:", os.listdir('static'))
    app.run(host='0.0.0.0', port=8080)
