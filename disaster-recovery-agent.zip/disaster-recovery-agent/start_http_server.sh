#!/bin/bash
cd static
http-server -p 8080 --cors
