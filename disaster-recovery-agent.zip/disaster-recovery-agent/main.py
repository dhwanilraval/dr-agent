"""
Main entry point for the Disaster Recovery Compliance Agent System.

This module starts the FastAPI application and serves the REST API.
"""

import logging
import uvicorn
import os

from src.architecture import disaster_recovery_system
from src.config.config import API_CONFIG
from src.utils.logging_utils import setup_elasticsearch_logging

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)

logger = logging.getLogger(__name__)

def main():
    """Start the FastAPI application."""
    setup_elasticsearch_logging()
    
    logger.info("Starting Disaster Recovery Compliance Agent System")
    
    app = disaster_recovery_system.api_app
    
    uvicorn.run(
        app,
        host=API_CONFIG["host"],
        port=API_CONFIG["port"],
        log_level="info" if API_CONFIG["debug"] else "warning"
    )

if __name__ == "__main__":
    main()
