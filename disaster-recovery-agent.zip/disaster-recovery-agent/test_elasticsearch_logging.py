"""
Simple script to demonstrate Elasticsearch logging functionality.

This script sets up Elasticsearch logging and logs some agent interactions
to verify that the logging system works correctly.
"""

import logging
import sys
import time
from src.utils.logging_utils import setup_elasticsearch_logging, log_agent_interaction

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    stream=sys.stdout
)

logger = logging.getLogger(__name__)

def main():
    """Run a simple test of Elasticsearch logging."""
    logger.info("Setting up Elasticsearch logging")
    setup_elasticsearch_logging()
    
    request_id = "test-request-123"
    
    log_agent_interaction(
        agent_name="process_dependency",
        message="Finding dependencies for APP001",
        request_id=request_id,
        workflow_step="dependency_analysis",
        agent_data={
            "app_code": "APP001",
            "dependencies_found": 3
        },
        agent_message={
            "content": "I found 3 dependencies for APP001: APP002, APP003, APP004"
        }
    )
    
    log_agent_interaction(
        agent_name="dr_plans_fetcher",
        message="Fetching DR plans for APP001, APP002, APP003, APP004",
        request_id=request_id,
        workflow_step="plan_retrieval",
        agent_data={
            "app_codes": ["APP001", "APP002", "APP003", "APP004"],
            "plans_found": 4
        }
    )
    
    try:
        raise ValueError("Test error for logging")
    except Exception:
        logger.exception("An error occurred during testing")
    
    log_agent_interaction(
        agent_name="reasoning",
        message="Completed analysis for request",
        request_id=request_id,
        workflow_step="final_analysis",
        agent_data={
            "overall_quality": "Medium",
            "dr_readiness_score": 75,
            "risk_level": "Medium"
        },
        agent_message={
            "content": "The overall DR readiness is Medium with a score of 75/100."
        }
    )
    
    logger.info("Elasticsearch logging test completed successfully")

if __name__ == "__main__":
    main()
