from flask import Flask, send_from_directory
import os

app = Flask(__name__)

@app.route('/')
def index():
    return send_from_directory('static', 'index.html')

@app.route('/original.html')
def original():
    return send_from_directory('static', 'original.html')

@app.route('/v2.html')
def v2():
    return send_from_directory('static', 'v2.html')

@app.route('/health')
def health():
    return {"status": "healthy"}

if __name__ == '__main__':
    print("Current working directory:", os.getcwd())
    print("Static files:", os.listdir('static'))
    app.run(host='0.0.0.0', port=8080)
