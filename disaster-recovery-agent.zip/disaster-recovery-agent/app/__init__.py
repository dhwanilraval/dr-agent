"""
FastAPI application package for serving the Disaster Recovery Compliance Agent System Whitepaper.
"""
