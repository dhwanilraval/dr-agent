"""
FastAPI application for serving the Disaster Recovery Compliance Agent System Whitepaper.
"""

import os
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse
import markdown2

app = FastAPI(
    title="Disaster Recovery Whitepaper API",
    description="API for serving the Disaster Recovery Compliance Agent System Whitepaper",
    version="0.1.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/", response_class=HTMLResponse)
async def read_whitepaper():
    """
    Serve the README.md content as HTML.
    """
    try:
        readme_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), "README.md")
        with open(readme_path, 'r') as f:
            content = f.read()
        
        html_content = markdown2.markdown(content, extras=["tables", "fenced-code-blocks"])
        
        template = """
        <!DOCTYPE html>
        <html>
        <head>
            <title>Disaster Recovery Compliance Agent System Whitepaper</title>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <style>
                body {
                    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
                    line-height: 1.6;
                    color: #333;
                    max-width: 900px;
                    margin: 0 auto;
                    padding: 20px;
                }
                h1, h2, h3, h4, h5, h6 {
                    margin-top: 24px;
                    margin-bottom: 16px;
                    font-weight: 600;
                    line-height: 1.25;
                }
                h1 {
                    font-size: 2em;
                    border-bottom: 1px solid #eaecef;
                    padding-bottom: .3em;
                }
                h2 {
                    font-size: 1.5em;
                    border-bottom: 1px solid #eaecef;
                    padding-bottom: .3em;
                }
                pre {
                    background-color: #f6f8fa;
                    border-radius: 3px;
                    padding: 16px;
                    overflow: auto;
                }
                code {
                    background-color: rgba(27,31,35,.05);
                    border-radius: 3px;
                    font-family: "SFMono-Regular", Consolas, "Liberation Mono", Menlo, monospace;
                    font-size: 85%;
                    padding: 0.2em 0.4em;
                }
                pre code {
                    background-color: transparent;
                    padding: 0;
                }
                blockquote {
                    border-left: 4px solid #dfe2e5;
                    color: #6a737d;
                    padding: 0 1em;
                    margin: 0;
                }
                table {
                    border-collapse: collapse;
                    width: 100%;
                    margin: 16px 0;
                }
                table th, table td {
                    border: 1px solid #dfe2e5;
                    padding: 6px 13px;
                }
                table tr {
                    background-color: #fff;
                    border-top: 1px solid #c6cbd1;
                }
                table tr:nth-child(2n) {
                    background-color: #f6f8fa;
                }
            </style>
        </head>
        <body>
            {content}
        </body>
        </html>
        """
        
        return template.format(content=html_content)
    except FileNotFoundError:
        raise HTTPException(status_code=404, detail="README.md file not found")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error reading README.md: {str(e)}")

@app.get("/health")
async def health_check():
    """
    Health check endpoint.
    """
    return {"status": "healthy"}
